window.TASKS=window.TASKS||{};
const _T13=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H13=(t)=>({text:t,penalty:5});

window.TASKS[13]=[
{
 id:1,difficulty:'легко',title:'Линейный поиск элемента',
 description:'Дан массив из N целых чисел и число X. Найдите X линейным поиском. Выведите его индекс (с нуля) или <code>-1</code> если не найдено.',
 hints:[_H13('Проходите элементы от 0 до N-1, сравнивая каждый с X'),_H13('Как только нашли — выводите индекс и завершайтесь'),_H13('Если прошли весь массив и не нашли — выводите -1')],
 testCases:[
  {input:'5\n3 7 1 9 4\n7',output:'1',hidden:false},
  {input:'4\n1 2 3 4\n5',output:'-1',hidden:false},
  {input:'6\n10 20 30 40 50 60\n40',output:'3',hidden:true},
  {input:'3\n5 5 5\n5',output:'0',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, x, a[100];\n    scanf("%d", &n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // линейный поиск x в a\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Линейный поиск — все вхождения',
 description:'Дан массив из N целых чисел и число X. Выведите индексы всех вхождений X через пробел. Если не найдено — выведите <code>-1</code>.',
 hints:[_H13('Проходите весь массив, выводите индекс при каждом совпадении'),_H13('Используйте флаг found=0, после цикла если !found — выводите -1'),_H13('Пробел между индексами: первый без пробела, остальные с пробелом перед числом')],
 testCases:[
  {input:'6\n1 3 3 2 3 1\n3',output:'1 2 4',hidden:false},
  {input:'4\n1 2 3 4\n5',output:'-1',hidden:false},
  {input:'5\n7 7 7 7 7\n7',output:'0 1 2 3 4',hidden:true},
  {input:'3\n1 2 3\n2',output:'1',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, x, a[100];\n    scanf("%d", &n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // найдите все вхождения x\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Минимум и его индекс',
 description:'Дан массив из N чисел. Найдите минимальный элемент и его первый индекс. Выведите через пробел: <code>значение индекс</code>.',
 hints:[_H13('Инициализируйте min=a[0], idx=0'),_H13('Цикл с i=1: если a[i]<min — обновите min и idx'),_H13('printf("%d %d\\n", min, idx);')],
 testCases:[
  {input:'5\n3 1 4 1 5',output:'1 1',hidden:false},
  {input:'4\n10 20 5 30',output:'5 2',hidden:false},
  {input:'3\n7 7 7',output:'7 0',hidden:true},
  {input:'1\n42',output:'42 0',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, a[100];\n    scanf("%d", &n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // найдите минимум и его первый индекс\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Двоичный поиск (готовый массив)',
 description:'Дан <b>отсортированный по возрастанию</b> массив из N чисел и число X. Найдите X двоичным поиском. Выведите индекс или <code>-1</code>.',
 hints:[_H13('Двоичный поиск: left=0, right=n-1, mid=(left+right)/2'),_H13('Если a[mid]==X — нашли; если X<a[mid] — right=mid-1; иначе left=mid+1'),_H13('Цикл while(left<=right)')],
 testCases:[
  {input:'5\n1 3 5 7 9\n5',output:'2',hidden:false},
  {input:'5\n1 3 5 7 9\n4',output:'-1',hidden:false},
  {input:'6\n2 4 6 8 10 12\n10',output:'4',hidden:true},
  {input:'1\n42\n42',output:'0',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, x, a[100];\n    scanf("%d", &n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // двоичный поиск x в отсортированном массиве\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Количество шагов двоичного поиска',
 description:'Дан отсортированный массив из N чисел и число X. Выведите количество итераций (сравнений), сделанных при двоичном поиске X.',
 hints:[_H13('Добавьте счётчик steps=0 и увеличивайте в каждой итерации цикла'),_H13('Выводите steps после завершения поиска'),_H13('Даже если элемент не найден — шаги тоже считаются')],
 testCases:[
  {input:'8\n1 2 3 4 5 6 7 8\n1',output:'3',hidden:false},
  {input:'4\n1 2 3 4\n3',output:'2',hidden:false},
  {input:'1\n5\n5',output:'1',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, x, a[100];\n    scanf("%d", &n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // двоичный поиск с подсчётом шагов\n    return 0;\n}')
},
{
 id:6,difficulty:'средне',title:'Поиск в строке символов',
 description:'Дан массив из N символов и символ C. Найдите все позиции C в массиве и выведите их через пробел. Если не найдено — выведите <code>-1</code>.',
 hints:[_H13('Считывайте символы через scanf(" %c",&a[i]) — пробел перед %c пропускает whitespace'),_H13('Цикл поиска аналогичен числовому, но сравниваете char'),_H13('Те же правила вывода: индексы через пробел или -1')],
 testCases:[
  {input:'5\na b a c a\na',output:'0 2 4',hidden:false},
  {input:'4\nx y z w\nq',output:'-1',hidden:false},
  {input:'3\nb b b\nb',output:'0 1 2',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n; char a[100], c;\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf(" %c",&a[i]);\n    scanf(" %c",&c);\n    // найдите все позиции символа c\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'Поиск ближайшего элемента',
 description:'Дан отсортированный массив из N чисел и число X. Найдите элемент, ближайший к X по значению. Если два элемента одинаково близки — выведите меньший.',
 hints:[_H13('Двоичный поиск найдёт позицию вставки X'),_H13('Проверьте соседей left и right — сравните расстояния'),_H13('abs(a[i]-x) — модуль разности (нужен #include <stdlib.h>)')],
 testCases:[
  {input:'5\n1 3 6 7 10\n4',output:'3',hidden:false},
  {input:'4\n1 2 3 4\n3',output:'3',hidden:false},
  {input:'4\n1 3 5 7\n4',output:'3',hidden:true},
  {input:'3\n1 5 9\n7',output:'7',hidden:true}
 ],
 initialCode:_T13('#include <stdlib.h>\nint main(){\n    int n, x, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // найдите ближайший к x элемент массива\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'Поиск диапазона (первый и последний)',
 description:'Дан отсортированный массив из N чисел и число X. Найдите индексы первого и последнего вхождения X. Если не найдено — выведите <code>-1 -1</code>.',
 hints:[_H13('Запустите двоичный поиск дважды: первый раз ищите крайний левый элемент, второй — крайний правый'),_H13('Для левого: когда a[mid]==X, запомните и сдвигайте right=mid-1'),_H13('Для правого: когда a[mid]==X, запомните и сдвигайте left=mid+1')],
 testCases:[
  {input:'7\n1 2 2 2 3 4 5\n2',output:'1 3',hidden:false},
  {input:'5\n1 1 1 1 1\n1',output:'0 4',hidden:false},
  {input:'4\n1 2 3 4\n5',output:'-1 -1',hidden:true},
  {input:'3\n1 2 3\n2',output:'1 1',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, x, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // найдите первый и последний индексы x\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'Поиск пика в массиве',
 description:'Найдите <b>пик</b> в массиве из N чисел — элемент, больший обоих соседей. Выведите его значение. Гарантируется, что пик существует и он один.<br><small>Крайние элементы пиками не являются.</small>',
 hints:[_H13('Линейный поиск: проверьте для i от 1 до n-2: a[i]>a[i-1] && a[i]>a[i+1]'),_H13('Бинарный поиск по пику: если a[mid]>a[mid+1] — пик слева или это mid; иначе справа'),_H13('Для простоты линейный поиск подойдёт')],
 testCases:[
  {input:'5\n1 3 2 1 0',output:'3',hidden:false},
  {input:'6\n1 2 3 4 3 2',output:'4',hidden:false},
  {input:'5\n0 1 5 2 1',output:'5',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // найдите пиковый элемент\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'Двоичный поиск — нижняя граница',
 description:'Дан отсортированный массив из N чисел и число X. Найдите нижнюю границу (lower bound) — индекс первого элемента ≥ X. Если все элементы < X — выведите N.',
 hints:[_H13('lower_bound: двоичный поиск с условием a[mid]>=X → right=mid; иначе left=mid+1'),_H13('Начало: left=0, right=n; цикл while(left<right); ответ: left'),_H13('Это позиция, куда X можно вставить, сохранив сортировку')],
 testCases:[
  {input:'5\n1 3 5 7 9\n5',output:'2',hidden:false},
  {input:'5\n1 3 5 7 9\n6',output:'3',hidden:false},
  {input:'5\n1 3 5 7 9\n10',output:'5',hidden:true},
  {input:'5\n1 3 5 7 9\n0',output:'0',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, x, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // найдите lower bound для x\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Поиск по двум критериям',
 description:'Дан список из N студентов: имя и оценка. Выведите имя студента с максимальной оценкой. При равенстве — первого по порядку.',
 hints:[_H13('Структура или два параллельных массива: char names[50][51], int scores[50]'),_H13('Найдите индекс максимальной оценки аналогично поиску максимума'),_H13('printf("%s\\n", names[idx]);')],
 testCases:[
  {input:'3\nAlice 85\nBob 92\nCarol 88',output:'Bob',hidden:false},
  {input:'2\nAnn 95\nMax 95',output:'Ann',hidden:false},
  {input:'4\nA 70\nB 80\nC 90\nD 60',output:'C',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n;\n    scanf("%d",&n);\n    char names[50][51]; int scores[50];\n    for(int i=0;i<n;i++) scanf("%s%d",names[i],&scores[i]);\n    // найдите студента с максимальной оценкой\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'Подсчёт элементов в диапазоне',
 description:'Дан отсортированный массив из N чисел и границы [L, R]. Подсчитайте количество элементов в диапазоне [L, R] с помощью двоичного поиска (lower_bound и upper_bound).',
 hints:[_H13('lower_bound(L) — первый индекс ≥ L'),_H13('upper_bound(R) — первый индекс > R'),_H13('Ответ: upper_bound(R) - lower_bound(L)')],
 testCases:[
  {input:'7\n1 2 3 4 5 6 7\n3 5',output:'3',hidden:false},
  {input:'5\n1 3 5 7 9\n2 8',output:'3',hidden:false},
  {input:'4\n1 2 3 4\n5 10',output:'0',hidden:true},
  {input:'6\n1 1 2 2 3 3\n1 2',output:'4',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, l, r, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d%d",&l,&r);\n    // подсчитайте элементы в диапазоне [l,r]\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'Троичный поиск минимума',
 description:'Дан унимодальный массив из N чисел (сначала убывает, потом возрастает). Найдите минимальный элемент с помощью троичного поиска.',
 hints:[_H13('Троичный поиск: m1=l+(r-l)/3, m2=r-(r-l)/3'),_H13('Если a[m1]<a[m2] — минимум в [l,m2-1], иначе в [m1+1,r]'),_H13('Цикл while(r-l>2), затем линейный поиск по оставшимся 3 элементам')],
 testCases:[
  {input:'7\n9 7 4 2 5 8 10',output:'2',hidden:false},
  {input:'5\n10 5 3 6 8',output:'3',hidden:false},
  {input:'6\n8 6 4 2 3 7',output:'2',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // троичный поиск минимума в унимодальном массиве\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Интерполяционный поиск',
 description:'Реализуйте интерполяционный поиск в отсортированном массиве из N чисел. Формула позиции: <code>pos = lo + (x-a[lo])*(hi-lo)/(a[hi]-a[lo])</code>. Выведите индекс или <code>-1</code>.',
 hints:[_H13('Проверяйте: a[lo]<=x<=a[hi] и a[hi]!=a[lo] (иначе линейный)'),_H13('Если a[pos]==x — нашли; если a[pos]<x — lo=pos+1; иначе hi=pos-1'),_H13('Цикл while(lo<=hi && x>=a[lo] && x<=a[hi])')],
 testCases:[
  {input:'6\n10 20 30 40 50 60\n40',output:'3',hidden:false},
  {input:'5\n1 3 5 7 9\n7',output:'3',hidden:false},
  {input:'4\n2 4 6 8\n5',output:'-1',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, x, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    // интерполяционный поиск\n    return 0;\n}')
},
{
 id:15,difficulty:'сложно',title:'Поиск в матрице',
 description:'Дана матрица N×M, где каждая строка и каждый столбец отсортированы по возрастанию. Найдите элемент X. Выведите <code>row col</code> (с нуля) или <code>-1</code>.',
 hints:[_H13('Алгоритм: начните с правого верхнего угла (row=0, col=M-1)'),_H13('Если a[row][col]==X — нашли; если X<a[row][col] — col--; иначе row++'),_H13('O(N+M) сравнений')],
 testCases:[
  {input:'3 3\n1 4 7\n2 5 8\n3 6 9\n5',output:'1 1',hidden:false},
  {input:'2 3\n1 2 3\n4 5 6\n6',output:'1 2',hidden:false},
  {input:'3 3\n1 4 7\n2 5 8\n3 6 9\n10',output:'-1',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, m, x, a[20][20];\n    scanf("%d%d",&n,&m);\n    for(int i=0;i<n;i++) for(int j=0;j<m;j++) scanf("%d",&a[i][j]);\n    scanf("%d",&x);\n    // поиск x в отсортированной матрице\n    return 0;\n}')
},
{
 id:16,difficulty:'сложно',title:'Медиана двух отсортированных массивов',
 description:'Даны два отсортированных массива длиной N. Найдите медиану их слияния. Для 2N элементов медиана — среднее двух средних.',
 hints:[_H13('Слейте два массива как в merge sort, затем найдите медиану'),_H13('Для чётного числа 2N элементов: (merged[N-1]+merged[N])/2.0'),_H13('printf("%.1f\\n", median);')],
 testCases:[
  {input:'3\n1 3 5\n2 4 6',output:'3.5',hidden:false},
  {input:'2\n1 2\n3 4',output:'2.5',hidden:false},
  {input:'4\n1 3 5 7\n2 4 6 8',output:'4.5',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, a[50], b[50];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    for(int i=0;i<n;i++) scanf("%d",&b[i]);\n    // найдите медиану слияния двух массивов\n    return 0;\n}')
},
{
 id:17,difficulty:'супер',title:'k-й порядковый элемент',
 description:'Дан массив из N чисел (не отсортирован) и число K (1-based). Найдите K-й наименьший элемент <b>без полной сортировки</b> — с помощью алгоритма QuickSelect.',
 hints:[_H13('QuickSelect: выберите опорный элемент, разделите массив (partition)'),_H13('Если индекс опорного == K-1 — нашли; если < K-1 — ищите справа; иначе слева'),_H13('Рекурсия или цикл. Средняя сложность O(N)')],
 testCases:[
  {input:'5\n3 1 4 1 5\n3',output:'3',hidden:false},
  {input:'6\n7 2 5 1 9 3\n4',output:'5',hidden:false},
  {input:'4\n4 3 2 1\n1',output:'1',hidden:true},
  {input:'4\n4 3 2 1\n4',output:'4',hidden:true}
 ],
 initialCode:_T13('int main(){\n    int n, k, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&k);\n    // найдите k-й наименьший элемент (QuickSelect)\n    return 0;\n}')
}
];
