window.TASKS=window.TASKS||{};
const _T17=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H17=(t)=>({text:t,penalty:5});

window.TASKS[17]=[
{
 id:1,difficulty:'легко',title:'Двоичное представление числа',
 description:'Считайте неотрицательное число N (≤255) и выведите его в двоичном представлении (8 бит, с ведущими нулями).',
 hints:[_H17('Проходите биты от 7 до 0: (n >> i) & 1'),_H17('for(int i=7;i>=0;i--) printf("%d",(n>>i)&1);'),_H17('printf("\\n"); в конце')],
 testCases:[
  {input:'10',output:'00001010',hidden:false},
  {input:'255',output:'11111111',hidden:false},
  {input:'0',output:'00000000',hidden:true},
  {input:'128',output:'10000000',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n; scanf("%d",&n);\n    // выведите 8-битное двоичное представление n\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Проверка бита',
 description:'Дано число N и позиция бита K (0 — младший). Выведите <code>1</code> если бит K установлен, иначе <code>0</code>.',
 hints:[_H17('Маска: 1 << k'),_H17('(n >> k) & 1 — значение k-го бита'),_H17('Или: (n & (1<<k)) ? 1 : 0')],
 testCases:[
  {input:'10 1',output:'1',hidden:false},
  {input:'10 0',output:'0',hidden:false},
  {input:'255 7',output:'1',hidden:true},
  {input:'8 3',output:'1',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n, k;\n    scanf("%d%d",&n,&k);\n    // выведите k-й бит числа n\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Установка бита',
 description:'Дано число N и позиция K. Установите бит K в 1 (остальные биты не трогайте). Выведите результат.',
 hints:[_H17('Установить бит: n | (1 << k)'),_H17('Операция OR с маской устанавливает бит в 1 независимо от его текущего значения'),_H17('printf("%d\\n", n | (1 << k));')],
 testCases:[
  {input:'10 0',output:'11',hidden:false},
  {input:'10 2',output:'14',hidden:false},
  {input:'0 5',output:'32',hidden:true},
  {input:'255 3',output:'255',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n, k;\n    scanf("%d%d",&n,&k);\n    // установите бит k и выведите результат\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Сброс бита',
 description:'Дано число N и позиция K. Сбросьте бит K в 0. Выведите результат.',
 hints:[_H17('Сбросить бит: n & ~(1 << k)'),_H17('~(1<<k) — маска с нулём на позиции k и единицами везде'),_H17('printf("%d\\n", n & ~(1<<k));')],
 testCases:[
  {input:'11 0',output:'10',hidden:false},
  {input:'15 1',output:'13',hidden:false},
  {input:'255 7',output:'127',hidden:true},
  {input:'8 3',output:'0',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n, k;\n    scanf("%d%d",&n,&k);\n    // сбросьте бит k и выведите результат\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Переключение бита (toggle)',
 description:'Дано число N и позиция K. Переключите бит K (0→1, 1→0). Выведите результат.',
 hints:[_H17('Переключить бит: n ^ (1 << k)'),_H17('XOR с 1 меняет бит на противоположный'),_H17('printf("%d\\n", n ^ (1<<k));')],
 testCases:[
  {input:'10 1',output:'8',hidden:false},
  {input:'10 0',output:'11',hidden:false},
  {input:'0 4',output:'16',hidden:true},
  {input:'255 3',output:'247',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n, k;\n    scanf("%d%d",&n,&k);\n    // переключите бит k и выведите результат\n    return 0;\n}')
},
{
 id:6,difficulty:'легко',title:'Подсчёт единичных битов (popcount)',
 description:'Дано число N. Подсчитайте количество единичных битов в его двоичном представлении.',
 hints:[_H17('Пока n > 0: cnt += n&1; n >>= 1;'),_H17('Или трюк Брайана Кернигана: while(n){n&=(n-1);cnt++;} — снимает младший единичный бит'),_H17('Или __builtin_popcount(n) в GCC')],
 testCases:[
  {input:'10',output:'2',hidden:false},
  {input:'255',output:'8',hidden:false},
  {input:'0',output:'0',hidden:true},
  {input:'7',output:'3',hidden:true}
 ],
 initialCode:_T17('int main(){\n    unsigned int n; scanf("%u",&n);\n    // подсчитайте количество единичных битов\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'Степень двойки',
 description:'Дано число N (N > 0). Определите, является ли N степенью двойки. Выведите <code>YES</code> или <code>NO</code>.',
 hints:[_H17('Степень двойки: ровно один единичный бит'),_H17('Трюк: n & (n-1) == 0 (и n > 0) — ровно для степеней двойки'),_H17('Например: 8 = 1000, 7 = 0111, 8&7 = 0000')],
 testCases:[
  {input:'8',output:'YES',hidden:false},
  {input:'6',output:'NO',hidden:false},
  {input:'1',output:'YES',hidden:true},
  {input:'1024',output:'YES',hidden:true},
  {input:'100',output:'NO',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n; scanf("%d",&n);\n    // проверьте является ли n степенью двойки\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'Битовая маска — выбор подмножества',
 description:'Дан массив из N чисел (N ≤ 20). Для каждой маски от 0 до 2^N-1 найдите подмножество с максимальной суммой, кратной 3. Выведите эту сумму.',
 hints:[_H17('Перебирайте все маски mask от 1 до (1<<n)-1'),_H17('Для каждой маски: sum=0; for(int i=0;i<n;i++) if(mask>>i&1) sum+=a[i];'),_H17('Если sum%3==0 && sum>best — обновляем best')],
 testCases:[
  {input:'3\n1 2 3',output:'6',hidden:false},
  {input:'4\n1 5 7 3',output:'15',hidden:false},
  {input:'3\n1 1 1',output:'3',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n, a[20];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // перебор подмножеств через битовые маски\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'XOR — найти одиночный элемент',
 description:'Дан массив из 2N+1 числа, где каждое число встречается дважды кроме одного. Найдите это число с помощью XOR.',
 hints:[_H17('XOR одинаковых чисел = 0: a^a = 0'),_H17('XOR всех элементов даст результат 0^0^...^x = x'),_H17('int res=0; for(int i=0;i<n;i++) res^=a[i];')],
 testCases:[
  {input:'5\n2 3 5 3 2',output:'5',hidden:false},
  {input:'3\n1 1 7',output:'7',hidden:false},
  {input:'7\n4 1 2 1 2 4 9',output:'9',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // найдите одиночный элемент через XOR\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'Обмен без временной переменной',
 description:'Считайте два числа A и B. Поменяйте их значения с помощью XOR (без третьей переменной). Выведите <code>A B</code> после обмена.',
 hints:[_H17('a^=b; b^=a; a^=b; — обмен через XOR'),_H17('Это работает только если a и b — разные переменные (не одна и та же)'),_H17('printf("%d %d\\n",a,b); после обмена')],
 testCases:[
  {input:'5 10',output:'10 5',hidden:false},
  {input:'1 2',output:'2 1',hidden:false},
  {input:'0 7',output:'7 0',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int a, b;\n    scanf("%d%d",&a,&b);\n    // обменяйте a и b через XOR без tmp\n    printf("%d %d\\n",a,b);\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Выравнивание вверх до степени двойки',
 description:'Дано число N > 0. Найдите наименьшую степень двойки, которая ≥ N.',
 hints:[_H17('Если n уже степень двойки — ответ n'),_H17('Алгоритм: p=1; while(p<n) p<<=1; — сдвигаем влево'),_H17('Или: n--, затем цепь n|=(n>>1)|=(n>>2)|... n++')],
 testCases:[
  {input:'5',output:'8',hidden:false},
  {input:'8',output:'8',hidden:false},
  {input:'100',output:'128',hidden:true},
  {input:'1',output:'1',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n; scanf("%d",&n);\n    // найдите наименьшую степень двойки >= n\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'Маска для N младших битов',
 description:'Дано число N (1 ≤ N ≤ 30). Создайте маску из N единиц в младших битах и выведите её. Например, N=4 → 15 (0b1111).',
 hints:[_H17('Маска N единиц: (1 << n) - 1'),_H17('Для n=4: (1<<4)-1 = 16-1 = 15 = 0b1111'),_H17('Для n=32 нужен unsigned int или long long')],
 testCases:[
  {input:'4',output:'15',hidden:false},
  {input:'8',output:'255',hidden:false},
  {input:'1',output:'1',hidden:true},
  {input:'16',output:'65535',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n; scanf("%d",&n);\n    // выведите маску из n единиц в младших битах\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'Инверсия битов числа',
 description:'Дано 32-битное беззнаковое число N. Инвертируйте порядок его битов (бит 0 становится битом 31 и т.д.). Выведите результат.',
 hints:[_H17('Для каждого бита i от 0 до 31: если бит i установлен — устанавливаем бит (31-i) в результате'),_H17('result |= ((n>>i)&1) << (31-i);'),_H17('Используйте unsigned int')],
 testCases:[
  {input:'1',output:'2147483648',hidden:false},
  {input:'2147483648',output:'1',hidden:false},
  {input:'43261596',output:'964176192',hidden:true}
 ],
 initialCode:_T17('int main(){\n    unsigned int n; scanf("%u",&n);\n    unsigned int result=0;\n    // инвертируйте порядок битов\n    printf("%u\\n",result);\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Битовое множество (bitset)',
 description:'Реализуйте множество целых чисел [0..63] на основе одного <code>unsigned long long</code>. Обработайте Q запросов: <code>ADD x</code>, <code>DEL x</code>, <code>HAS x</code> (выводит YES/NO), <code>CNT</code> (количество элементов).',
 hints:[_H17('ADD x: set |= (1ULL<<x)'),_H17('DEL x: set &= ~(1ULL<<x)'),_H17('HAS x: (set>>x)&1 ? YES : NO')],
 testCases:[
  {input:'5\nADD 3\nADD 7\nHAS 3\nDEL 3\nHAS 3',output:'YES\nNO',hidden:false},
  {input:'4\nADD 1\nADD 2\nADD 3\nCNT',output:'3',hidden:false}
 ],
 initialCode:_T17('int main(){\n    int q; scanf("%d",&q);\n    unsigned long long set=0;\n    while(q--){\n        char cmd[5]; int x;\n        scanf("%s",cmd);\n        if(cmd[0]==\'A\'){scanf("%d",&x); /* ADD */ }\n        else if(cmd[0]==\'D\'){scanf("%d",&x); /* DEL */ }\n        else if(cmd[0]==\'H\'){scanf("%d",&x); /* HAS */ }\n        else{ /* CNT */ }\n    }\n    return 0;\n}')
},
{
 id:15,difficulty:'сложно',title:'Gray-код',
 description:'Двоичный рефлексивный код Грея: для числа N выведите N первых чисел Грея (0-indexed). Формула: <code>gray(i) = i ^ (i>>1)</code>.',
 hints:[_H17('gray(i) = i XOR (i >> 1) — стандартная формула'),_H17('Два соседних числа Грея отличаются ровно одним битом'),_H17('Для n=4: 0,1,3,2 (в двоичном: 00,01,11,10)')],
 testCases:[
  {input:'4',output:'0\n1\n3\n2',hidden:false},
  {input:'8',output:'0\n1\n3\n2\n6\n7\n5\n4',hidden:false},
  {input:'2',output:'0\n1',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n; scanf("%d",&n);\n    // выведите n чисел Грея начиная с 0\n    return 0;\n}')
},
{
 id:16,difficulty:'сложно',title:'Подсчёт единиц до N (popcount sum)',
 description:'Дано число N. Подсчитайте суммарное количество единичных битов во всех числах от 0 до N включительно.',
 hints:[_H17('Наивно: для каждого i от 0 до N вызвать popcount — O(N log N)'),_H17('Оптимально: dp[i] = dp[i>>1] + (i&1) — O(N)'),_H17('dp[0]=0; for(i=1;i<=n;i++) dp[i]=dp[i>>1]+(i&1); sum=sum(dp)')],
 testCases:[
  {input:'4',output:'5',hidden:false},
  {input:'7',output:'12',hidden:false},
  {input:'0',output:'0',hidden:true},
  {input:'15',output:'32',hidden:true}
 ],
 initialCode:_T17('int main(){\n    int n; scanf("%d",&n);\n    // подсчитайте сумму единичных битов от 0 до n\n    return 0;\n}')
},
{
 id:17,difficulty:'супер',title:'Минимальное XOR-расстояние',
 description:'Дан массив из N чисел. Найдите пару (i,j) с i≠j, у которой XOR минимален. Выведите это минимальное значение XOR.',
 hints:[_H17('Наивно O(N²) — перебрать все пары: может быть медленно для N=1000'),_H17('Оптимально: сортировка + проверка соседей (XOR соседних элементов после сортировки минимален)'),_H17('Отсортируйте массив, найдите min(a[i]^a[i+1]) по всем i')],
 testCases:[
  {input:'4\n3 10 5 25',output:'3',hidden:false},
  {input:'3\n1 2 3',output:'1',hidden:false},
  {input:'5\n4 8 15 16 23',output:'7',hidden:true}
 ],
 initialCode:_T17('#include <stdlib.h>\nint cmp(const void*a,const void*b){return *(int*)a-*(int*)b;}\nint main(){\n    int n, a[1000];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    qsort(a,n,sizeof(int),cmp);\n    // найдите минимальный XOR среди пар соседних элементов\n    return 0;\n}')
}
];
