window.TASKS=window.TASKS||{};
const _T4=(c)=>`#include <stdio.h>\n\nint main(void) {\n    ${c||'// ваш код здесь'}\n    return 0;\n}\n`;
const _H4=(t)=>({text:t,penalty:5});

window.TASKS[4]=[
/* ============ ЛЁГКО (1-10) ============ */
{
 id:1,difficulty:'легко',title:'Сумма от 1 до N',
 description:'Дано натуральное число N. Вычислите и выведите сумму всех целых чисел от 1 до N включительно.',
 hints:[_H4('Используйте цикл for от 1 до N и накапливайте сумму в переменной.'),_H4('Не забудьте инициализировать переменную суммы нулём перед циклом.'),_H4('for (int i = 1; i <= n; i++) sum += i;')],
 testCases:[{input:'5',output:'15',hidden:false},{input:'10',output:'55',hidden:true},{input:'1',output:'1',hidden:true}],
 initialCode:_T4('int n, sum = 0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", sum);')
},
{
 id:2,difficulty:'легко',title:'Числа от 1 до N',
 description:'Дано натуральное число N. Выведите все числа от 1 до N через пробел.',
 hints:[_H4('Используйте цикл for от 1 до N.'),_H4('Печатайте пробел перед каждым числом, кроме первого.'),_H4('if (i > 1) printf(\" \"); printf(\"%d\", i);')],
 testCases:[{input:'5',output:'1 2 3 4 5',hidden:false},{input:'1',output:'1',hidden:true},{input:'3',output:'1 2 3',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:3,difficulty:'легко',title:'Обратный отсчёт',
 description:'Дано натуральное число N. Выведите все числа от N до 1 через пробел.',
 hints:[_H4('Используйте цикл for, начиная с N и уменьшая счётчик до 1.'),_H4('for (int i = n; i >= 1; i--)'),_H4('Печатайте пробел перед каждым числом, кроме первого.')],
 testCases:[{input:'5',output:'5 4 3 2 1',hidden:false},{input:'1',output:'1',hidden:true},{input:'3',output:'3 2 1',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:4,difficulty:'легко',title:'Сумма чётных',
 description:'Дано натуральное число N. Вычислите сумму всех чётных чисел от 1 до N включительно.',
 hints:[_H4('Чётное число — это число, которое делится на 2 без остатка (i % 2 == 0).'),_H4('Переберите все числа от 1 до N и прибавляйте только чётные.'),_H4('if (i % 2 == 0) sum += i;')],
 testCases:[{input:'6',output:'12',hidden:false},{input:'10',output:'30',hidden:true},{input:'1',output:'0',hidden:true}],
 initialCode:_T4('int n, sum = 0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", sum);')
},
{
 id:5,difficulty:'легко',title:'Факториал',
 description:'Дано целое неотрицательное число N (N ≤ 12). Вычислите и выведите N! (факториал числа N). Напоминание: 0! = 1.',
 hints:[_H4('Факториал — это произведение всех чисел от 1 до N.'),_H4('Начните с fact = 1 и умножайте на каждой итерации цикла.'),_H4('for (int i = 1; i <= n; i++) fact *= i;')],
 testCases:[{input:'5',output:'120',hidden:false},{input:'0',output:'1',hidden:true},{input:'12',output:'479001600',hidden:true}],
 initialCode:_T4('int n, fact = 1;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", fact);')
},
{
 id:6,difficulty:'легко',title:'Степень двойки',
 description:'Дано целое неотрицательное число N. Вычислите и выведите 2 в степени N (2^N).',
 hints:[_H4('Начните с result = 1 и умножайте на 2 в цикле N раз.'),_H4('for (int i = 0; i < n; i++) result *= 2;'),_H4('При N = 0 результат равен 1 (цикл не выполнится).')],
 testCases:[{input:'10',output:'1024',hidden:false},{input:'0',output:'1',hidden:true},{input:'5',output:'32',hidden:true}],
 initialCode:_T4('int n, result = 1;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", result);')
},
{
 id:7,difficulty:'легко',title:'Таблица умножения',
 description:'Дано натуральное число N. Выведите результаты умножения N на числа от 1 до 10 через пробел.',
 hints:[_H4('Используйте цикл for от 1 до 10.'),_H4('На каждой итерации выводите N * i.'),_H4('Не забудьте про пробелы между числами.')],
 testCases:[{input:'3',output:'3 6 9 12 15 18 21 24 27 30',hidden:false},{input:'5',output:'5 10 15 20 25 30 35 40 45 50',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:8,difficulty:'легко',title:'Количество цифр',
 description:'Дано целое неотрицательное число N. Определите количество цифр в числе N. Считайте, что число 0 содержит одну цифру.',
 hints:[_H4('Делите число на 10, пока оно не станет нулём, и считайте итерации.'),_H4('Не забудьте обработать случай N = 0 отдельно (ответ — 1).'),_H4('while (n > 0) { count++; n /= 10; }')],
 testCases:[{input:'12345',output:'5',hidden:false},{input:'0',output:'1',hidden:true},{input:'100',output:'3',hidden:true}],
 initialCode:_T4('int n, count = 0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", count);')
},
{
 id:9,difficulty:'легко',title:'Сумма цифр',
 description:'Дано целое неотрицательное число N. Вычислите сумму всех его цифр.',
 hints:[_H4('Последняя цифра числа — это остаток от деления на 10 (n % 10).'),_H4('После извлечения цифры удалите её: n = n / 10.'),_H4('Повторяйте в цикле while (n > 0).')],
 testCases:[{input:'123',output:'6',hidden:false},{input:'9999',output:'36',hidden:true},{input:'0',output:'0',hidden:true}],
 initialCode:_T4('int n, sum = 0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", sum);')
},
{
 id:10,difficulty:'легко',title:'Звёздочки',
 description:'Дано натуральное число N. Выведите строку из N символов «*» (звёздочка) подряд, без пробелов.',
 hints:[_H4('Используйте цикл for от 1 до N.'),_H4('На каждой итерации печатайте один символ *.'),_H4('printf(\"*\"); внутри цикла.')],
 testCases:[{input:'5',output:'*****',hidden:false},{input:'1',output:'*',hidden:true},{input:'10',output:'**********',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
/* ============ СРЕДНЕ (11-17) ============ */
{
 id:11,difficulty:'средне',title:'Числа Фибоначчи',
 description:'Дано натуральное число N. Выведите N-е число Фибоначчи. Последовательность: F(1) = 1, F(2) = 1, F(3) = 2, F(4) = 3, F(5) = 5, …',
 hints:[_H4('Каждое число Фибоначчи — сумма двух предыдущих: F(n) = F(n−1) + F(n−2).'),_H4('Используйте две переменные a и b для хранения двух последних чисел.'),_H4('На каждом шаге цикла: c = a + b; a = b; b = c;')],
 testCases:[{input:'7',output:'13',hidden:false},{input:'1',output:'1',hidden:true},{input:'10',output:'55',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:12,difficulty:'средне',title:'Реверс числа',
 description:'Дано натуральное число N. Выведите число, полученное записью цифр N в обратном порядке. Ведущие нули отбрасываются (100 → 1).',
 hints:[_H4('Извлекайте последнюю цифру с помощью n % 10.'),_H4('Стройте новое число: rev = rev * 10 + digit.'),_H4('Повторяйте в цикле, пока n > 0.')],
 testCases:[{input:'12345',output:'54321',hidden:false},{input:'100',output:'1',hidden:true},{input:'7',output:'7',hidden:true}],
 initialCode:_T4('int n, rev = 0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", rev);')
},
{
 id:13,difficulty:'средне',title:'Палиндром-число',
 description:'Дано натуральное число N. Определите, является ли оно палиндромом (читается одинаково слева направо и справа налево). Выведите YES или NO.',
 hints:[_H4('Палиндром — число, которое совпадает со своим реверсом.'),_H4('Сохраните исходное число в отдельной переменной перед построением реверса.'),_H4('Сравните оригинал с реверсом: if (orig == rev) printf(\"YES\");')],
 testCases:[{input:'12321',output:'YES',hidden:false},{input:'12345',output:'NO',hidden:true},{input:'7',output:'YES',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:14,difficulty:'средне',title:'НОД (алгоритм Евклида)',
 description:'Даны два натуральных числа A и B. Найдите их наибольший общий делитель (НОД) с помощью алгоритма Евклида.',
 hints:[_H4('Алгоритм Евклида: пока b ≠ 0, заменяйте (a, b) на (b, a % b).'),_H4('while (b != 0) { int t = b; b = a % b; a = t; }'),_H4('Ответ — значение a после завершения цикла.')],
 testCases:[{input:'12 8',output:'4',hidden:false},{input:'7 3',output:'1',hidden:true},{input:'100 25',output:'25',hidden:true}],
 initialCode:_T4('int a, b;\n    scanf(\"%d %d\", &a, &b);\n    // ваш код здесь\n    printf(\"%d\", a);')
},
{
 id:15,difficulty:'средне',title:'Гармонический ряд',
 description:'Дано натуральное число N. Вычислите сумму ряда 1 + 1/2 + 1/3 + … + 1/N и выведите результат с 4 знаками после запятой.',
 hints:[_H4('Используйте переменную типа double для суммы.'),_H4('На каждой итерации прибавляйте 1.0 / i (важно: 1.0, а не 1!).'),_H4('Для вывода: printf(\"%.4f\", sum);')],
 testCases:[{input:'1',output:'1.0000',hidden:false},{input:'3',output:'1.8333',hidden:true},{input:'5',output:'2.2833',hidden:true}],
 initialCode:_T4('int n;\n    double sum = 0.0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%.4f\", sum);')
},
{
 id:16,difficulty:'средне',title:'НОК двух чисел',
 description:'Даны два натуральных числа A и B. Найдите их наименьшее общее кратное (НОК).',
 hints:[_H4('НОК(a, b) = a / НОД(a, b) * b.'),_H4('Сначала найдите НОД с помощью алгоритма Евклида.'),_H4('Делите a на НОД перед умножением на b, чтобы избежать переполнения.')],
 testCases:[{input:'4 6',output:'12',hidden:false},{input:'3 7',output:'21',hidden:true},{input:'12 18',output:'36',hidden:true}],
 initialCode:_T4('int a, b;\n    scanf(\"%d %d\", &a, &b);\n    // ваш код здесь')
},
{
 id:17,difficulty:'средне',title:'Треугольник из звёздочек',
 description:'Дано натуральное число N. Выведите треугольник из звёздочек: в первой строке 1 звёздочка, во второй — 2, и так далее до N. Каждая строка на отдельной строке.',
 hints:[_H4('Используйте два вложенных цикла: внешний — по строкам, внутренний — по звёздочкам.'),_H4('Внешний цикл: for (int i = 1; i <= n; i++)'),_H4('Внутренний цикл печатает i звёздочек, затем printf(\"\\n\");')],
 testCases:[{input:'3',output:'*\n**\n***',hidden:false},{input:'1',output:'*',hidden:true},{input:'4',output:'*\n**\n***\n****',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
/* ============ СЛОЖНО (18-22) ============ */
{
 id:18,difficulty:'сложно',title:'Простое число',
 description:'Дано натуральное число N (N ≥ 1). Определите, является ли оно простым. Выведите YES, если число простое, и NO в противном случае. Число 1 не является простым.',
 hints:[_H4('Простое число делится только на 1 и на само себя, и оно больше 1.'),_H4('Достаточно проверять делители от 2 до √N: for (int i = 2; i * i <= n; i++)'),_H4('Если нашёлся делитель (n % i == 0), число не простое.')],
 testCases:[{input:'7',output:'YES',hidden:false},{input:'4',output:'NO',hidden:true},{input:'1',output:'NO',hidden:true},{input:'2',output:'YES',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:19,difficulty:'сложно',title:'Количество простых до N',
 description:'Дано натуральное число N. Подсчитайте, сколько простых чисел содержится среди чисел от 2 до N включительно.',
 hints:[_H4('Для каждого числа от 2 до N проверяйте, является ли оно простым.'),_H4('Число простое, если не делится ни на одно число от 2 до его квадратного корня.'),_H4('Используйте вложенные циклы: внешний — по числам, внутренний — по делителям.')],
 testCases:[{input:'10',output:'4',hidden:false},{input:'2',output:'1',hidden:true},{input:'20',output:'8',hidden:true}],
 initialCode:_T4('int n, count = 0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", count);')
},
{
 id:20,difficulty:'сложно',title:'Цифровой корень',
 description:'Дано целое неотрицательное число N. Найдите его цифровой корень — результат многократного сложения цифр числа, пока не останется одна цифра. Пример: 9875 → 29 → 11 → 2.',
 hints:[_H4('Используйте внешний цикл while (n >= 10), внутри которого суммируйте цифры.'),_H4('Внутренний цикл: извлекайте цифры через n % 10 и n /= 10.'),_H4('После внутреннего цикла замените n на полученную сумму.')],
 testCases:[{input:'9875',output:'2',hidden:false},{input:'0',output:'0',hidden:true},{input:'39',output:'3',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%d\", n);')
},
{
 id:21,difficulty:'сложно',title:'Совершенное число',
 description:'Дано натуральное число N (N ≥ 2). Определите, является ли оно совершенным — равным сумме всех своих делителей, кроме самого числа. Выведите YES или NO. Пример: 6 = 1 + 2 + 3.',
 hints:[_H4('Переберите все числа от 1 до N/2 и проверяйте, делится ли N на них.'),_H4('Если n % i == 0, прибавьте i к сумме делителей.'),_H4('if (sum == n) printf(\"YES\"); else printf(\"NO\");')],
 testCases:[{input:'6',output:'YES',hidden:false},{input:'28',output:'YES',hidden:true},{input:'12',output:'NO',hidden:true}],
 initialCode:_T4('int n, sum = 0;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:22,difficulty:'сложно',title:'Простые множители',
 description:'Дано натуральное число N (N ≥ 2). Разложите его на простые множители и выведите их через пробел в порядке возрастания. Если множитель повторяется, выведите его столько раз, сколько он входит. Пример: 12 → 2 2 3.',
 hints:[_H4('Начните делить N на 2, пока делится. Затем пробуйте 3, 4, 5 и т.д.'),_H4('Составные делители не дадут результата, так как число уже разделено на их простые компоненты.'),_H4('Если после цикла n > 1, выведите оставшееся n — это простой множитель.')],
 testCases:[{input:'12',output:'2 2 3',hidden:false},{input:'60',output:'2 2 3 5',hidden:true},{input:'7',output:'7',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
/* ============ СУПЕР (23-24) ============ */
{
 id:23,difficulty:'супер',title:'Числа Армстронга',
 description:'Дано натуральное число N. Выведите через пробел все числа Армстронга от 1 до N включительно. Число Армстронга — число, равное сумме своих цифр, возведённых в степень количества цифр числа. Пример: 153 = 1³ + 5³ + 3³.',
 hints:[_H4('Для каждого числа от 1 до N: подсчитайте количество цифр, затем вычислите сумму цифр в этой степени.'),_H4('Возведение в степень реализуйте циклом: p = 1; for (j = 0; j < digits; j++) p *= d;'),_H4('Все однозначные числа (1–9) являются числами Армстронга (d¹ = d).')],
 testCases:[{input:'500',output:'1 2 3 4 5 6 7 8 9 153 370 371 407',hidden:false},{input:'10',output:'1 2 3 4 5 6 7 8 9',hidden:true}],
 initialCode:_T4('int n;\n    scanf(\"%d\", &n);\n    // ваш код здесь')
},
{
 id:24,difficulty:'супер',title:'Приближение числа e',
 description:'Дано целое неотрицательное число N. Вычислите приближённое значение числа Эйлера e по формуле: e ≈ Σ(1/k!) для k от 0 до N. Выведите результат с 4 знаками после запятой.',
 hints:[_H4('Вычисляйте факториал итеративно: fact = fact * k на каждом шаге цикла.'),_H4('Используйте тип double для факториала и суммы.'),_H4('Начните с fact = 1.0, sum = 1.0 (k=0), затем цикл от k=1: fact *= k; sum += 1.0 / fact;')],
 testCases:[{input:'0',output:'1.0000',hidden:false},{input:'5',output:'2.7167',hidden:true},{input:'10',output:'2.7183',hidden:true}],
 initialCode:_T4('int n;\n    double sum = 0.0, fact = 1.0;\n    scanf(\"%d\", &n);\n    // ваш код здесь\n    printf(\"%.4f\", sum);')
}
];
