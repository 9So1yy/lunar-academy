window.TASKS=window.TASKS||{};
const _T8=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H8=(t)=>({text:t,penalty:5});

window.TASKS[8]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'Структура Point',
 description:'Объявите <code>struct Point { int x, y; }</code>. Считайте 2 числа в поля структуры и выведите через пробел.',
 hints:[_H8('struct Point { int x, y; };'),_H8('struct Point p; scanf("%d %d", &p.x, &p.y);'),_H8('printf("%d %d", p.x, p.y);')],
 testCases:[
  {input:'3 4',output:'3 4',hidden:false},
  {input:'10 20',output:'10 20',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\n\nint main(void) {\n    struct Point p;\n    scanf("%d %d", &p.x, &p.y);\n    printf("%d %d", p.x, p.y);\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Структура Person',
 description:'Объявите <code>struct Person { int age; int height; }</code>. Считайте возраст и рост. Вычислите и выведите age + height.',
 hints:[_H8('struct Person p;'),_H8('scanf("%d %d", &p.age, &p.height);'),_H8('printf("%d", p.age + p.height);')],
 testCases:[
  {input:'25 180',output:'205',hidden:false},
  {input:'18 175',output:'193',hidden:true}
 ],
 initialCode:_T8('struct Person { int age; int height; };\n\nint main(void) {\n    struct Person p;\n    // считайте и выведите сумму\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Инициализация структуры',
 description:'Объявите <code>struct Rect { int w, h; }</code>. Инициализируйте через <code>= {10, 5}</code>. Выведите площадь.',
 hints:[_H8('struct Rect r = {10, 5};'),_H8('printf("%d", r.w * r.h);')],
 testCases:[{input:'',output:'50',hidden:false}],
 initialCode:_T8('struct Rect { int w, h; };\n\nint main(void) {\n    struct Rect r = {10, 5};\n    // вывести площадь\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'typedef struct',
 description:'Объявите <code>typedef struct { int x, y; } Point</code>. Считайте координаты и выведите их сумму.',
 hints:[_H8('typedef struct { int x, y; } Point;'),_H8('Point p; scanf("%d %d", &p.x, &p.y);'),_H8('printf("%d", p.x + p.y);')],
 testCases:[
  {input:'3 7',output:'10',hidden:false},
  {input:'-1 5',output:'4',hidden:true}
 ],
 initialCode:_T8('typedef struct { int x, y; } Point;\n\nint main(void) {\n    Point p;\n    // считайте и выведите p.x + p.y\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Копирование структуры',
 description:'Объявите <code>struct Point</code>. Считайте в p1. Скопируйте: <code>p2 = p1</code>. Увеличьте p2.x на 1. Выведите p1.x и p2.x через пробел.',
 hints:[_H8('struct Point p2 = p1;'),_H8('p2.x++;'),_H8('printf("%d %d", p1.x, p2.x);')],
 testCases:[
  {input:'5 3',output:'5 6',hidden:false},
  {input:'10 0',output:'10 11',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\n\nint main(void) {\n    struct Point p1, p2;\n    scanf("%d %d", &p1.x, &p1.y);\n    p2 = p1;\n    p2.x++;\n    printf("%d %d", p1.x, p2.x);\n    return 0;\n}')
},
{
 id:6,difficulty:'легко',title:'enum — дни недели',
 description:'Объявите <code>enum Day { SUN=0, MON, TUE, WED, THU, FRI, SAT }</code>. Считайте число (0–6) и выведите название: Sun Mon Tue Wed Thu Fri Sat.',
 hints:[_H8('switch(n) { case 0: printf("Sun"); break; ... }'),_H8('Или массив строк: char* names[] = {"Sun",...}')],
 testCases:[
  {input:'0',output:'Sun',hidden:false},
  {input:'3',output:'Wed',hidden:true},
  {input:'6',output:'Sat',hidden:true}
 ],
 initialCode:_T8('enum Day { SUN=0, MON, TUE, WED, THU, FRI, SAT };\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // switch или массив имён\n    return 0;\n}')
},
{
 id:7,difficulty:'легко',title:'Массив структур',
 description:'Объявите <code>struct Point pts[3]</code>. Считайте 3 пары x y. Выведите сумму всех x и всех y через пробел.',
 hints:[_H8('for(int i=0;i<3;i++) scanf("%d %d",&pts[i].x,&pts[i].y);'),_H8('Суммируй pts[i].x в цикле'),_H8('printf("%d %d", sumx, sumy);')],
 testCases:[
  {input:'1 2 3 4 5 6',output:'9 12',hidden:false},
  {input:'0 0 0 0 0 0',output:'0 0',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\n\nint main(void) {\n    struct Point pts[3];\n    int i, sx=0, sy=0;\n    for(i=0;i<3;i++) scanf("%d %d",&pts[i].x,&pts[i].y);\n    // посчитать суммы\n    printf("%d %d", sx, sy);\n    return 0;\n}')
},
{
 id:8,difficulty:'легко',title:'Структура с тремя полями',
 description:'Объявите <code>struct Color { int r, g, b; }</code>. Считайте три значения (0–255). Выведите их сумму.',
 hints:[_H8('scanf("%d %d %d", &c.r, &c.g, &c.b);'),_H8('printf("%d", c.r + c.g + c.b);')],
 testCases:[
  {input:'255 128 0',output:'383',hidden:false},
  {input:'0 0 0',output:'0',hidden:true},
  {input:'100 100 100',output:'300',hidden:true}
 ],
 initialCode:_T8('struct Color { int r, g, b; };\n\nint main(void) {\n    struct Color c;\n    scanf("%d %d %d", &c.r, &c.g, &c.b);\n    // вывести сумму\n    return 0;\n}')
},
{
 id:9,difficulty:'легко',title:'Площадь прямоугольника',
 description:'Объявите <code>struct Rect { int w, h; }</code>. Считайте w и h. Выведите площадь (w×h) и периметр (2×(w+h)) через пробел.',
 hints:[_H8('printf("%d %d", r.w*r.h, 2*(r.w+r.h));')],
 testCases:[
  {input:'4 5',output:'20 18',hidden:false},
  {input:'3 3',output:'9 12',hidden:true},
  {input:'10 2',output:'20 24',hidden:true}
 ],
 initialCode:_T8('struct Rect { int w, h; };\n\nint main(void) {\n    struct Rect r;\n    scanf("%d %d", &r.w, &r.h);\n    // вывести площадь и периметр\n    return 0;\n}')
},
{
 id:10,difficulty:'легко',title:'Квадрат расстояния',
 description:'Считайте координаты двух точек. Используя <code>struct Point</code>, выведите квадрат расстояния: (x2−x1)² + (y2−y1)².',
 hints:[_H8('int dx = b.x-a.x, dy = b.y-a.y;'),_H8('printf("%d", dx*dx + dy*dy);')],
 testCases:[
  {input:'0 0 3 4',output:'25',hidden:false},
  {input:'1 1 4 5',output:'25',hidden:true},
  {input:'0 0 0 0',output:'0',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\n\nint main(void) {\n    struct Point a, b;\n    scanf("%d %d %d %d", &a.x, &a.y, &b.x, &b.y);\n    // вывести квадрат расстояния\n    return 0;\n}')
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'Функция, принимающая структуру',
 description:'Напишите <code>int area(struct Rect r)</code>. Считайте w, h, вызовите area, выведите результат.',
 hints:[_H8('int area(struct Rect r) { return r.w * r.h; }'),_H8('printf("%d", area(r));')],
 testCases:[
  {input:'6 7',output:'42',hidden:false},
  {input:'10 10',output:'100',hidden:true},
  {input:'1 100',output:'100',hidden:true}
 ],
 initialCode:_T8('struct Rect { int w, h; };\n\nint area(struct Rect r) {\n    // вернуть площадь\n}\n\nint main(void) {\n    struct Rect r;\n    scanf("%d %d", &r.w, &r.h);\n    printf("%d", area(r));\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'Функция, возвращающая структуру',
 description:'Напишите <code>struct Point make_point(int x, int y)</code>. Считайте x, y. Создайте точку через функцию, выведите p.x и p.y через пробел.',
 hints:[_H8('struct Point make_point(int x, int y) { struct Point p={x,y}; return p; }')],
 testCases:[
  {input:'5 10',output:'5 10',hidden:false},
  {input:'-1 3',output:'-1 3',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\n\nstruct Point make_point(int x, int y) {\n    // создай и верни Point\n}\n\nint main(void) {\n    int x, y;\n    scanf("%d %d", &x, &y);\n    struct Point p = make_point(x, y);\n    printf("%d %d", p.x, p.y);\n    return 0;\n}')
},
{
 id:13,difficulty:'средне',title:'Нахождение максимума в массиве структур',
 description:'Массив из 4 структур <code>struct Item { int id, val; }</code>. Считайте 4 пары (id, val). Выведите id элемента с наибольшим val.',
 hints:[_H8('int maxIdx = 0;'),_H8('for(i=1;i<4;i++) if(items[i].val > items[maxIdx].val) maxIdx=i;'),_H8('printf("%d", items[maxIdx].id);')],
 testCases:[
  {input:'1 10 2 30 3 20 4 5',output:'2',hidden:false},
  {input:'1 1 2 1 3 1 4 2',output:'4',hidden:true}
 ],
 initialCode:_T8('struct Item { int id, val; };\n\nint main(void) {\n    struct Item items[4];\n    int i;\n    for(i=0;i<4;i++) scanf("%d %d",&items[i].id,&items[i].val);\n    // найди максимум по val\n    return 0;\n}')
},
{
 id:14,difficulty:'средне',title:'Вложенная структура',
 description:'Объявите <code>struct Segment { struct Point a, b; }</code>. Считайте 4 числа (x1 y1 x2 y2). Выведите сумму всех координат.',
 hints:[_H8('struct Segment { struct Point a, b; };'),_H8('scanf("%d %d %d %d",&seg.a.x,&seg.a.y,&seg.b.x,&seg.b.y);'),_H8('printf("%d",seg.a.x+seg.a.y+seg.b.x+seg.b.y);')],
 testCases:[
  {input:'1 2 3 4',output:'10',hidden:false},
  {input:'0 0 0 0',output:'0',hidden:true},
  {input:'5 5 5 5',output:'20',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\nstruct Segment { struct Point a, b; };\n\nint main(void) {\n    struct Segment seg;\n    scanf("%d %d %d %d",&seg.a.x,&seg.a.y,&seg.b.x,&seg.b.y);\n    // вывести сумму координат\n    return 0;\n}')
},
{
 id:15,difficulty:'средне',title:'Сортировка двух структур',
 description:'Считайте два Item (id, val). Выведите их в порядке возрастания val (id1 val1 id2 val2). При равных val — не менять порядок.',
 hints:[_H8('if (a.val > b.val) { struct Item t=a; a=b; b=t; }'),_H8('printf("%d %d %d %d",a.id,a.val,b.id,b.val);')],
 testCases:[
  {input:'1 10 2 5',output:'2 5 1 10',hidden:false},
  {input:'1 3 2 7',output:'1 3 2 7',hidden:true},
  {input:'1 9 2 9',output:'1 9 2 9',hidden:true}
 ],
 initialCode:_T8('struct Item { int id, val; };\n\nint main(void) {\n    struct Item a, b;\n    scanf("%d %d %d %d",&a.id,&a.val,&b.id,&b.val);\n    // поменять если нужно\n    printf("%d %d %d %d",a.id,a.val,b.id,b.val);\n    return 0;\n}')
},
{
 id:16,difficulty:'средне',title:'Центр масс',
 description:'Считайте 3 точки (x y каждая). Выведите координаты центра масс: (x1+x2+x3)/3 и (y1+y2+y3)/3 (целочисленно).',
 hints:[_H8('int cx = (p[0].x+p[1].x+p[2].x)/3;'),_H8('printf("%d %d", cx, cy);')],
 testCases:[
  {input:'0 0 3 0 0 3',output:'1 1',hidden:false},
  {input:'0 0 6 0 3 9',output:'3 3',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\n\nint main(void) {\n    struct Point p[3];\n    int i;\n    for(i=0;i<3;i++) scanf("%d %d",&p[i].x,&p[i].y);\n    printf("%d %d",(p[0].x+p[1].x+p[2].x)/3,(p[0].y+p[1].y+p[2].y)/3);\n    return 0;\n}')
},
{
 id:17,difficulty:'средне',title:'enum Season',
 description:'Объявите <code>enum Season { SPRING=1, SUMMER, AUTUMN, WINTER }</code>. Считайте номер сезона (1–4) и выведите его название. При другом вводе — <code>?</code>.',
 hints:[_H8('switch(s) { case SPRING: printf("Spring"); break; ... }')],
 testCases:[
  {input:'1',output:'Spring',hidden:false},
  {input:'3',output:'Autumn',hidden:true},
  {input:'5',output:'?',hidden:true}
 ],
 initialCode:_T8('enum Season { SPRING=1, SUMMER, AUTUMN, WINTER };\n\nint main(void) {\n    int s;\n    scanf("%d", &s);\n    switch(s) {\n        // case SPRING: ...\n    }\n    return 0;\n}')
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'enum день недели',
 description:'<code>enum Day { SUN=0, MON, ..., SAT }</code>. Считайте число. Выведите: название дня, <b>и</b> является ли выходным (Sun/Sat → 1, иначе → 0). Формат: <code>Wed 0</code>.',
 hints:[_H8('Для имени — массив строк char* names[] = {"Sun","Mon",...}'),_H8('Для выходных: d==SUN || d==SAT'),_H8('printf("%s %d", names[n], n==0||n==6);')],
 testCases:[
  {input:'0',output:'Sun 1',hidden:false},
  {input:'3',output:'Wed 0',hidden:true},
  {input:'6',output:'Sat 1',hidden:true}
 ],
 initialCode:_T8('enum Day { SUN=0, MON, TUE, WED, THU, FRI, SAT };\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    char* names[] = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};\n    printf("%s %d", names[n], n==0||n==6);\n    return 0;\n}')
},
{
 id:19,difficulty:'сложно',title:'Функция изменения через указатель на структуру',
 description:'Напишите <code>void scale(struct Point* p, int k)</code> — умножает x и y на k. Считайте x, y, k. Вызовите scale, выведите результат.',
 hints:[_H8('void scale(struct Point* p, int k) { p->x *= k; p->y *= k; }'),_H8('Вызов: scale(&p, k);'),_H8('printf("%d %d", p.x, p.y);')],
 testCases:[
  {input:'3 4 2',output:'6 8',hidden:false},
  {input:'5 10 3',output:'15 30',hidden:true},
  {input:'7 3 0',output:'0 0',hidden:true}
 ],
 initialCode:_T8('struct Point { int x, y; };\n\nvoid scale(struct Point* p, int k) {\n    // умножить p->x и p->y на k\n}\n\nint main(void) {\n    struct Point p;\n    int k;\n    scanf("%d %d %d", &p.x, &p.y, &k);\n    scale(&p, k);\n    printf("%d %d", p.x, p.y);\n    return 0;\n}')
},
{
 id:20,difficulty:'сложно',title:'Прямоугольник — пересечение',
 description:'Два прямоугольника задаются координатами левого верхнего угла (x, y), шириной w и высотой h. Выведите <code>1</code> если они пересекаются (перекрываются) — иначе <code>0</code>.',
 hints:[_H8('Не пересекаются если: a.x+a.w<=b.x || b.x+b.w<=a.x || a.y+a.h<=b.y || b.y+b.h<=a.y'),_H8('Пересечение = НЕ (не пересекаются)')],
 testCases:[
  {input:'0 0 4 4 2 2 4 4',output:'1',hidden:false},
  {input:'0 0 2 2 3 3 2 2',output:'0',hidden:true},
  {input:'0 0 5 5 3 3 2 2',output:'1',hidden:true}
 ],
 initialCode:_T8('struct Rect { int x, y, w, h; };\n\nint main(void) {\n    struct Rect a, b;\n    scanf("%d %d %d %d",&a.x,&a.y,&a.w,&a.h);\n    scanf("%d %d %d %d",&b.x,&b.y,&b.w,&b.h);\n    // вычисли пересечение\n    return 0;\n}')
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'Стек через структуру',
 description:'Реализуйте простой стек: <code>struct Stack { int data[10]; int top; }</code>. Функции <code>push(s,x)</code> и <code>pop(s)</code> (через указатель). Считайте n команд: <code>+ x</code> (push x) или <code>-</code> (pop и вывести). Команды через пробел.',
 hints:[_H8('void push(struct Stack* s, int x) { s->data[s->top++] = x; }'),_H8('int pop(struct Stack* s) { return s->data[--s->top]; }'),_H8('char op; scanf(" %c",&op); if(op==\'+\') {scanf("%d",&x);push(&s,x);} else printf("%d ",pop(&s));')],
 testCases:[
  {input:'4 + 1 + 2 - -',output:'2 1',hidden:false},
  {input:'2 + 5 -',output:'5',hidden:true}
 ],
 initialCode:_T8('struct Stack { int data[10]; int top; };\n\nvoid push(struct Stack* s, int x) { s->data[s->top++] = x; }\nint pop(struct Stack* s) { return s->data[--s->top]; }\n\nint main(void) {\n    struct Stack s = {{0},0};\n    int n, x; char op;\n    scanf("%d",&n);\n    while(n--) {\n        scanf(" %c",&op);\n        if(op==\'+\'){scanf("%d",&x);push(&s,x);}\n        else printf("%d ",pop(&s));\n    }\n    return 0;\n}')
},
{
 id:24,difficulty:'супер',title:'Полиморфизм через union + enum',
 description:'<code>enum Type { INT_T, FLOAT_T }</code>. <code>union Val { int i; float f; }</code>. <code>struct Variant { enum Type t; union Val v; }</code>. Считайте тип (0=int,1=float) и значение. Выведите удвоенное: для int — <code>%d</code>, для float — <code>%.1f</code>.',
 hints:[_H8('if(v.t==INT_T) { scanf("%d",&v.v.i); printf("%d",v.v.i*2); }'),_H8('else { scanf("%f",&v.v.f); printf("%.1f",v.v.f*2); }')],
 testCases:[
  {input:'0 5',output:'10',hidden:false},
  {input:'1 3.5',output:'7.0',hidden:true}
 ],
 initialCode:_T8('enum Type { INT_T=0, FLOAT_T };\nunion Val { int i; float f; };\nstruct Variant { enum Type t; union Val v; };\n\nint main(void) {\n    struct Variant var;\n    scanf("%d", (int*)&var.t);\n    if(var.t==INT_T) { scanf("%d",&var.v.i); printf("%d",var.v.i*2); }\n    else { scanf("%f",&var.v.f); printf("%.1f",var.v.f*2); }\n    return 0;\n}')
}
];
