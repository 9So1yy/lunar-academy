window.TASKS=window.TASKS||{};
const _T18=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H18=(t)=>({text:t,penalty:5});

window.TASKS[18]=[
{
 id:1,difficulty:'легко',title:'#define константа',
 description:'Определите константу <code>PI</code> равную 3.14159 с помощью <code>#define</code>. Считайте радиус R и выведите площадь круга (PI * R * R) с 2 знаками после запятой.',
 hints:[_H18('#define PI 3.14159 — константа препроцессора (без точки с запятой!)'),_H18('PI заменяется на 3.14159 до компиляции — это текстовая подстановка'),_H18('printf("%.2f\\n", PI * r * r);')],
 testCases:[
  {input:'5',output:'78.54',hidden:false},
  {input:'1',output:'3.14',hidden:false},
  {input:'10',output:'314.16',hidden:true}
 ],
 initialCode:_T18('#define PI 3.14159\nint main(){\n    double r;\n    scanf("%lf", &r);\n    // выведите площадь круга\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'#define макрос с параметром',
 description:'Определите макрос <code>MAX(a,b)</code> который возвращает максимум двух значений. Считайте два числа и выведите максимум.',
 hints:[_H18('#define MAX(a,b) ((a)>(b)?(a):(b))'),_H18('Скобки вокруг параметров важны: без них MAX(1+2,3) сработает неверно'),_H18('Макрос раскрывается препроцессором, а не вызывается как функция')],
 testCases:[
  {input:'3 7',output:'7',hidden:false},
  {input:'10 2',output:'10',hidden:false},
  {input:'-5 -3',output:'-3',hidden:true}
 ],
 initialCode:_T18('#define MAX(a,b) /* ваш макрос */\nint main(){\n    int a, b;\n    scanf("%d%d",&a,&b);\n    printf("%d\\n", MAX(a,b));\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'#define SQUARE и CUBE',
 description:'Определите макросы <code>SQUARE(x)</code> и <code>CUBE(x)</code> для возведения в квадрат и куб. Выведите квадрат и куб введённого числа через пробел.',
 hints:[_H18('#define SQUARE(x) ((x)*(x))'),_H18('#define CUBE(x) ((x)*(x)*(x))'),_H18('Всегда оборачивайте параметры в скобки!')],
 testCases:[
  {input:'3',output:'9 27',hidden:false},
  {input:'5',output:'25 125',hidden:false},
  {input:'2',output:'4 8',hidden:true}
 ],
 initialCode:_T18('#define SQUARE(x) /* квадрат */\n#define CUBE(x) /* куб */\nint main(){\n    int x;\n    scanf("%d",&x);\n    printf("%d %d\\n", SQUARE(x), CUBE(x));\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'#ifdef условная компиляция',
 description:'Напишите программу: если определён макрос <code>DEBUG</code> — выводите <code>DEBUG MODE</code>, иначе <code>RELEASE MODE</code>. Определите DEBUG перед запуском.',
 hints:[_H18('#define DEBUG — определить макрос (без значения)'),_H18('#ifdef DEBUG ... #else ... #endif — условная компиляция'),_H18('Вставьте #define DEBUG в начало программы')],
 testCases:[
  {input:'',output:'DEBUG MODE',hidden:false}
 ],
 initialCode:_T18('#define DEBUG\nint main(){\n#ifdef DEBUG\n    puts("DEBUG MODE");\n#else\n    puts("RELEASE MODE");\n#endif\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Макрос ABS',
 description:'Определите макрос <code>ABS(x)</code> для вычисления модуля числа. Считайте число и выведите его абсолютное значение.',
 hints:[_H18('#define ABS(x) ((x)<0?-(x):(x))'),_H18('Проверьте отрицательные и нулевые значения'),_H18('Не используйте abs() из stdlib.h — реализуйте через #define')],
 testCases:[
  {input:'-5',output:'5',hidden:false},
  {input:'3',output:'3',hidden:false},
  {input:'0',output:'0',hidden:true},
  {input:'-100',output:'100',hidden:true}
 ],
 initialCode:_T18('#define ABS(x) /* модуль */\nint main(){\n    int x;\n    scanf("%d",&x);\n    printf("%d\\n", ABS(x));\n    return 0;\n}')
},
{
 id:6,difficulty:'средне',title:'Макрос SWAP',
 description:'Определите макрос <code>SWAP(a,b,type)</code> который меняет два значения местами через временную переменную. Считайте два числа, поменяйте и выведите.',
 hints:[_H18('#define SWAP(a,b,type) do{type _t=a;a=b;b=_t;}while(0)'),_H18('do{...}while(0) — идиома для безопасного многострочного макроса'),_H18('Параметр type нужен для объявления временной переменной')],
 testCases:[
  {input:'5 10',output:'10 5',hidden:false},
  {input:'1 2',output:'2 1',hidden:false},
  {input:'-3 7',output:'7 -3',hidden:true}
 ],
 initialCode:_T18('#define SWAP(a,b,type) do{type _t=(a);(a)=(b);(b)=_t;}while(0)\nint main(){\n    int a, b;\n    scanf("%d%d",&a,&b);\n    SWAP(a,b,int);\n    printf("%d %d\\n",a,b);\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'#define для отладки (LOG)',
 description:'Определите макрос <code>LOG(fmt,...)</code> который выводит сообщение с префиксом <code>[LOG] </code>. Если определён <code>NDEBUG</code> — макрос ничего не делает.',
 hints:[_H18('#define LOG(fmt,...) printf("[LOG] " fmt, ##__VA_ARGS__)'),_H18('##__VA_ARGS__ — переменное число аргументов в макросе (variadic macro)'),_H18('#ifdef NDEBUG\n#define LOG(fmt,...) /*nothing*/\n#endif')],
 testCases:[
  {input:'',output:'[LOG] Starting\n[LOG] x = 42',hidden:false}
 ],
 initialCode:_T18('#ifndef NDEBUG\n#define LOG(fmt,...) printf("[LOG] " fmt, ##__VA_ARGS__)\n#else\n#define LOG(fmt,...)\n#endif\nint main(){\n    LOG("Starting\\n");\n    int x = 42;\n    LOG("x = %d\\n", x);\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'Макрос ASSERT',
 description:'Реализуйте макрос <code>MY_ASSERT(cond)</code>: если условие ложно — выводит <code>Assertion failed: cond</code> и завершает программу через <code>exit(1)</code>.',
 hints:[_H18('#define MY_ASSERT(c) if(!(c)){printf("Assertion failed: " #c "\\n");exit(1);}'),_H18('#c — оператор # в макросе превращает аргумент в строку (stringification)'),_H18('#include <stdlib.h> для exit()')],
 testCases:[
  {input:'5',output:'OK',hidden:false},
  {input:'0',output:'Assertion failed: x > 0',hidden:false}
 ],
 initialCode:_T18('#include <stdlib.h>\n#define MY_ASSERT(c) if(!(c)){printf("Assertion failed: " #c "\\n");exit(1);}\nint main(){\n    int x; scanf("%d",&x);\n    MY_ASSERT(x > 0);\n    puts("OK");\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'Константы через enum vs #define',
 description:'Определите коды направлений через <code>enum</code>: UP=0, DOWN=1, LEFT=2, RIGHT=3. Считайте число (0-3) и выведите название направления.',
 hints:[_H18('enum Direction {UP=0, DOWN=1, LEFT=2, RIGHT=3};'),_H18('switch(d){ case UP: puts("UP"); break; ... }'),_H18('enum создаёт именованные целочисленные константы с проверкой типов')],
 testCases:[
  {input:'0',output:'UP',hidden:false},
  {input:'2',output:'LEFT',hidden:false},
  {input:'3',output:'RIGHT',hidden:true},
  {input:'1',output:'DOWN',hidden:true}
 ],
 initialCode:_T18('typedef enum{UP=0,DOWN=1,LEFT=2,RIGHT=3}Direction;\nint main(){\n    int d; scanf("%d",&d);\n    // выведите название направления\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'Макрос MIN3',
 description:'Определите макрос <code>MIN3(a,b,c)</code> для нахождения минимума из трёх чисел через уже существующий макрос MIN(a,b). Считайте три числа и выведите наименьшее.',
 hints:[_H18('#define MIN(a,b) ((a)<(b)?(a):(b))'),_H18('#define MIN3(a,b,c) MIN(MIN(a,b),c)'),_H18('Вложенные макросы раскрываются рекурсивно')],
 testCases:[
  {input:'3 1 2',output:'1',hidden:false},
  {input:'-5 0 5',output:'-5',hidden:false},
  {input:'10 10 10',output:'10',hidden:true}
 ],
 initialCode:_T18('#define MIN(a,b) ((a)<(b)?(a):(b))\n#define MIN3(a,b,c) /* используйте MIN */\nint main(){\n    int a,b,c;\n    scanf("%d%d%d",&a,&b,&c);\n    printf("%d\\n",MIN3(a,b,c));\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Версионирование через препроцессор',
 description:'Определите макросы <code>VERSION_MAJOR 1</code>, <code>VERSION_MINOR 2</code>, <code>VERSION_PATCH 3</code> и выведите версию в формате <code>v1.2.3</code>. Также выведите дату компиляции (<code>__DATE__</code>).',
 hints:[_H18('__DATE__ — встроенный макрос, строка с датой компиляции'),_H18('printf("v%d.%d.%d\\n", VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH);'),_H18('printf("Built: %s\\n", __DATE__);')],
 testCases:[
  {input:'',output:'v1.2.3',hidden:false}
 ],
 initialCode:_T18('#define VERSION_MAJOR 1\n#define VERSION_MINOR 2\n#define VERSION_PATCH 3\nint main(){\n    printf("v%d.%d.%d\\n",VERSION_MAJOR,VERSION_MINOR,VERSION_PATCH);\n    return 0;\n}')
},
{
 id:12,difficulty:'сложно',title:'X-макрос для таблицы данных',
 description:'Используйте технику X-macro для генерации массива имён и значений цветов. Определите список цветов через <code>#define COLORS</code> и автоматически создайте массивы.',
 hints:[_H18('#define COLORS X(RED,0xFF0000) X(GREEN,0x00FF00) X(BLUE,0x0000FF)'),_H18('#define X(name,val) #name, — для массива строк'),_H18('#undef X перед повторным использованием')],
 testCases:[
  {input:'',output:'RED: 16711680\nGREEN: 65280\nBLUE: 255',hidden:false}
 ],
 initialCode:_T18('#define COLORS X(RED,0xFF0000) X(GREEN,0x00FF00) X(BLUE,0x0000FF)\n#define X(name,val) #name,\nconst char *names[]={COLORS};\n#undef X\n#define X(name,val) val,\nconst int vals[]={COLORS};\n#undef X\nint main(){\n    int n=sizeof(names)/sizeof(names[0]);\n    for(int i=0;i<n;i++) printf("%s: %d\\n",names[i],vals[i]);\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'Stringify и конкатенация токенов',
 description:'Используйте <code>#</code> (stringify) и <code>##</code> (token paste) в макросах. Создайте макрос <code>PRINT_VAR(x)</code> который выводит имя переменной и её значение: <code>x = 42</code>.',
 hints:[_H18('#define PRINT_VAR(x) printf(#x " = %d\\n", x)'),_H18('# перед параметром превращает его в строковый литерал'),_H18('PRINT_VAR(myVar) → printf("myVar" " = %d\\n", myVar)')],
 testCases:[
  {input:'',output:'count = 10\nresult = 25',hidden:false}
 ],
 initialCode:_T18('#define PRINT_VAR(x) printf(#x " = %d\\n", (x))\nint main(){\n    int count=10, result=25;\n    PRINT_VAR(count);\n    PRINT_VAR(result);\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Inline функции vs макросы',
 description:'Реализуйте функцию <code>clamp(x, lo, hi)</code> двумя способами: как макрос и как <code>static inline</code> функцию. Считайте x, lo, hi и выведите результат обоими способами (должен совпасть).',
 hints:[_H18('#define CLAMP_M(x,lo,hi) ((x)<(lo)?(lo):((x)>(hi)?(hi):(x)))'),_H18('static inline int clamp_f(int x,int lo,int hi){...}'),_H18('inline — подсказка компилятору подставить тело функции вместо вызова')],
 testCases:[
  {input:'5 1 10',output:'5\n5',hidden:false},
  {input:'-3 0 100',output:'0\n0',hidden:false},
  {input:'150 0 100',output:'100\n100',hidden:true}
 ],
 initialCode:_T18('#define CLAMP_M(x,lo,hi) ((x)<(lo)?(lo):((x)>(hi)?(hi):(x)))\nstatic inline int clamp_f(int x,int lo,int hi){\n    return x<lo?lo:(x>hi?hi:x);\n}\nint main(){\n    int x,lo,hi;\n    scanf("%d%d%d",&x,&lo,&hi);\n    printf("%d\\n",CLAMP_M(x,lo,hi));\n    printf("%d\\n",clamp_f(x,lo,hi));\n    return 0;\n}')
},
{
 id:15,difficulty:'супер',title:'Универсальный макрос FOREACH',
 description:'Реализуйте макрос <code>FOREACH(item, arr, n)</code> для итерации по массиву. Используйте его для вычисления суммы и поиска максимума массива.',
 hints:[_H18('#define FOREACH(item,arr,n) for(int _i=0;_i<(n);_i++){int item=arr[_i];'),_H18('Заканчивайте блок FOREACH_END или добавьте } в макрос'),_H18('Либо: #define FOREACH(item,arr,n) for(int item,_i=0;_i<n&&(item=arr[_i],1);_i++)')],
 testCases:[
  {input:'5\n3 1 4 1 5',output:'14\n5',hidden:false},
  {input:'3\n10 20 30',output:'60\n30',hidden:false}
 ],
 initialCode:_T18('#define FOREACH(item,arr,n) for(int _i=0,item;_i<(n)&&(item=(arr)[_i],1);_i++)\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    int sum=0;\n    FOREACH(x,a,n) sum+=x;\n    printf("%d\\n",sum);\n    int mx=a[0];\n    FOREACH(x,a,n) if(x>mx) mx=x;\n    printf("%d\\n",mx);\n    return 0;\n}')
}
];
