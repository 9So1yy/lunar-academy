window.TASKS=window.TASKS||{};
const _T6=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H6=(t)=>({text:t,penalty:5});
const _M6=(fn,body)=>`${fn}\n\nint main(void) {\n    ${body}\n    return 0;\n}`;

window.TASKS[6]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'Квадрат числа',
 description:'Напишите функцию <code>int square(int x)</code>, возвращающую x². Считайте число и выведите результат.',
 hints:[_H6('int square(int x) { return x * x; }'),_H6('В main: scanf + printf("%d", square(n));')],
 testCases:[
  {input:'5',output:'25',hidden:false},
  {input:'10',output:'100',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T6(_M6('int square(int x) {\n    // ваш код\n}','int n;\n    scanf("%d", &n);\n    printf("%d", square(n));'))
},
{
 id:2,difficulty:'легко',title:'Куб числа',
 description:'Напишите функцию <code>int cube(int x)</code>, возвращающую x³.',
 hints:[_H6('return x * x * x;')],
 testCases:[
  {input:'3',output:'27',hidden:false},
  {input:'4',output:'64',hidden:true},
  {input:'-2',output:'-8',hidden:true}
 ],
 initialCode:_T6(_M6('int cube(int x) {\n    // ваш код\n}','int n;\n    scanf("%d", &n);\n    printf("%d", cube(n));'))
},
{
 id:3,difficulty:'легко',title:'Сумма двух',
 description:'Напишите функцию <code>int add(int a, int b)</code>, возвращающую сумму.',
 hints:[_H6('return a + b;')],
 testCases:[
  {input:'3 4',output:'7',hidden:false},
  {input:'-5 5',output:'0',hidden:true},
  {input:'100 200',output:'300',hidden:true}
 ],
 initialCode:_T6(_M6('int add(int a, int b) {\n    // ваш код\n}','int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d", add(a, b));'))
},
{
 id:4,difficulty:'легко',title:'Максимум двух',
 description:'Напишите функцию <code>int max2(int a, int b)</code>, возвращающую наибольшее.',
 hints:[_H6('return a > b ? a : b;'),_H6('Или через if/else')],
 testCases:[
  {input:'5 8',output:'8',hidden:false},
  {input:'3 1',output:'3',hidden:true},
  {input:'7 7',output:'7',hidden:true}
 ],
 initialCode:_T6(_M6('int max2(int a, int b) {\n    // ваш код\n}','int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d", max2(a, b));'))
},
{
 id:5,difficulty:'легко',title:'Чётность',
 description:'Напишите функцию <code>int is_even(int n)</code>, возвращающую <code>1</code> если чётное, <code>0</code> если нечётное.',
 hints:[_H6('return n % 2 == 0;')],
 testCases:[
  {input:'4',output:'1',hidden:false},
  {input:'7',output:'0',hidden:true},
  {input:'0',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('int is_even(int n) {\n    // ваш код\n}','int n;\n    scanf("%d", &n);\n    printf("%d", is_even(n));'))
},
{
 id:6,difficulty:'легко',title:'Celsius в Fahrenheit',
 description:'Напишите функцию <code>int c_to_f(int c)</code>, переводящую °C в °F. Формула: F = C × 9 / 5 + 32 (целочисленно).',
 hints:[_H6('return c * 9 / 5 + 32;')],
 testCases:[
  {input:'0',output:'32',hidden:false},
  {input:'100',output:'212',hidden:true},
  {input:'20',output:'68',hidden:true}
 ],
 initialCode:_T6(_M6('int c_to_f(int c) {\n    // ваш код\n}','int c;\n    scanf("%d", &c);\n    printf("%d", c_to_f(c));'))
},
{
 id:7,difficulty:'легко',title:'Знак числа — функция',
 description:'Напишите <code>int sign(int n)</code>, возвращающую <code>1</code>, <code>-1</code> или <code>0</code>.',
 hints:[_H6('if (n > 0) return 1; if (n < 0) return -1; return 0;')],
 testCases:[
  {input:'5',output:'1',hidden:false},
  {input:'-8',output:'-1',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T6(_M6('int sign(int n) {\n    // ваш код\n}','int n;\n    scanf("%d", &n);\n    printf("%d", sign(n));'))
},
{
 id:8,difficulty:'легко',title:'Сумма квадратов',
 description:'Напишите <code>int sum_sq(int a, int b)</code>, возвращающую a² + b².',
 hints:[_H6('return a*a + b*b;')],
 testCases:[
  {input:'3 4',output:'25',hidden:false},
  {input:'1 1',output:'2',hidden:true},
  {input:'5 0',output:'25',hidden:true}
 ],
 initialCode:_T6(_M6('int sum_sq(int a, int b) {\n    // ваш код\n}','int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d", sum_sq(a, b));'))
},
{
 id:9,difficulty:'легко',title:'Минимум двух',
 description:'Напишите <code>int min2(int a, int b)</code>, возвращающую наименьшее.',
 hints:[_H6('return a < b ? a : b;')],
 testCases:[
  {input:'5 8',output:'5',hidden:false},
  {input:'3 1',output:'1',hidden:true},
  {input:'7 7',output:'7',hidden:true}
 ],
 initialCode:_T6(_M6('int min2(int a, int b) {\n    // ваш код\n}','int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d", min2(a, b));'))
},
{
 id:10,difficulty:'легко',title:'Диапазон — функция',
 description:'Напишите <code>int in_range(int n, int lo, int hi)</code>, возвращающую <code>1</code> если lo≤n≤hi, иначе <code>0</code>.',
 hints:[_H6('return n >= lo && n <= hi;')],
 testCases:[
  {input:'5 1 10',output:'1',hidden:false},
  {input:'15 1 10',output:'0',hidden:true},
  {input:'1 1 10',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('int in_range(int n, int lo, int hi) {\n    // ваш код\n}','int n, lo, hi;\n    scanf("%d %d %d", &n, &lo, &hi);\n    printf("%d", in_range(n, lo, hi));'))
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'Максимум трёх через max2',
 description:'Напишите <code>int max2(int a, int b)</code> и <code>int max3(int a, int b, int c)</code>. <code>max3</code> должна использовать <code>max2</code> внутри.',
 hints:[_H6('int max3(int a, int b, int c) { return max2(max2(a, b), c); }')],
 testCases:[
  {input:'5 3 8',output:'8',hidden:false},
  {input:'10 20 15',output:'20',hidden:true},
  {input:'7 7 7',output:'7',hidden:true}
 ],
 initialCode:_T6('int max2(int a, int b) {\n    return a > b ? a : b;\n}\n\nint max3(int a, int b, int c) {\n    // используй max2\n}\n\nint main(void) {\n    int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    printf("%d", max3(a, b, c));\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'Простое число',
 description:'Напишите <code>int is_prime(int n)</code>, возвращающую <code>1</code> если простое, <code>0</code> иначе.',
 hints:[_H6('Перебирай делители от 2 до n-1 (или до i*i <= n)'),_H6('if (n < 2) return 0;'),_H6('for (int i=2; i*i<=n; i++) if (n%i==0) return 0; return 1;')],
 testCases:[
  {input:'7',output:'1',hidden:false},
  {input:'4',output:'0',hidden:true},
  {input:'1',output:'0',hidden:true}
 ],
 initialCode:_T6(_M6('int is_prime(int n) {\n    // ваш код\n}','int n;\n    scanf("%d", &n);\n    printf("%d", is_prime(n));'))
},
{
 id:13,difficulty:'средне',title:'Сумма цифр',
 description:'Напишите <code>int digit_sum(int n)</code>, возвращающую сумму цифр числа n (n &gt; 0).',
 hints:[_H6('while (n > 0) { sum += n % 10; n /= 10; }'),_H6('return sum;')],
 testCases:[
  {input:'123',output:'6',hidden:false},
  {input:'456',output:'15',hidden:true},
  {input:'1000',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('int digit_sum(int n) {\n    int sum = 0;\n    // ваш код\n    return sum;\n}','int n;\n    scanf("%d", &n);\n    printf("%d", digit_sum(n));'))
},
{
 id:14,difficulty:'средне',title:'Степень числа',
 description:'Напишите <code>int power(int base, int exp)</code>, вычисляющую base^exp (exp ≥ 0).',
 hints:[_H6('int res = 1; for (int i = 0; i < exp; i++) res *= base; return res;')],
 testCases:[
  {input:'2 10',output:'1024',hidden:false},
  {input:'3 4',output:'81',hidden:true},
  {input:'5 0',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('int power(int base, int exp) {\n    // ваш код\n}','int b, e;\n    scanf("%d %d", &b, &e);\n    printf("%d", power(b, e));'))
},
{
 id:15,difficulty:'средне',title:'НОД двух чисел',
 description:'Напишите <code>int gcd(int a, int b)</code> — наибольший общий делитель (алгоритм Евклида).',
 hints:[_H6('while (b != 0) { int t = b; b = a % b; a = t; } return a;')],
 testCases:[
  {input:'12 8',output:'4',hidden:false},
  {input:'48 18',output:'6',hidden:true},
  {input:'7 3',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('int gcd(int a, int b) {\n    // ваш код\n}','int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d", gcd(a, b));'))
},
{
 id:16,difficulty:'средне',title:'НОК через НОД',
 description:'Напишите <code>gcd()</code> и <code>int lcm(int a, int b)</code>. lcm использует gcd: lcm = a / gcd * b.',
 hints:[_H6('int lcm(int a, int b) { return a / gcd(a, b) * b; }'),_H6('Сначала делим, потом умножаем — чтобы избежать переполнения')],
 testCases:[
  {input:'12 8',output:'24',hidden:false},
  {input:'4 6',output:'12',hidden:true},
  {input:'7 3',output:'21',hidden:true}
 ],
 initialCode:_T6('int gcd(int a, int b) {\n    while (b) { int t=b; b=a%b; a=t; }\n    return a;\n}\n\nint lcm(int a, int b) {\n    // используй gcd\n}\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d", lcm(a, b));\n    return 0;\n}')
},
{
 id:17,difficulty:'средне',title:'Количество цифр',
 description:'Напишите <code>int count_digits(int n)</code>, считающую количество цифр в числе n (n &gt; 0).',
 hints:[_H6('while (n > 0) { count++; n /= 10; }'),_H6('return count;')],
 testCases:[
  {input:'123',output:'3',hidden:false},
  {input:'1000',output:'4',hidden:true},
  {input:'7',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('int count_digits(int n) {\n    int count = 0;\n    // ваш код\n    return count;\n}','int n;\n    scanf("%d", &n);\n    printf("%d", count_digits(n));'))
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'Рекурсивный факториал',
 description:'Напишите рекурсивную функцию <code>long fact(int n)</code>. Считайте N (≤12) и выведите N!.',
 hints:[_H6('База: if (n <= 1) return 1;'),_H6('Шаг: return n * fact(n-1);'),_H6('printf("%ld", fact(n));')],
 testCases:[
  {input:'5',output:'120',hidden:false},
  {input:'1',output:'1',hidden:true},
  {input:'10',output:'3628800',hidden:true}
 ],
 initialCode:_T6(_M6('long fact(int n) {\n    // рекурсия\n}','int n;\n    scanf("%d", &n);\n    printf("%ld", fact(n));'))
},
{
 id:19,difficulty:'сложно',title:'Рекурсивный Фибоначчи',
 description:'Напишите рекурсивную <code>int fib(int n)</code>: fib(1)=1, fib(2)=1, fib(n)=fib(n-1)+fib(n-2).',
 hints:[_H6('if (n <= 2) return 1;'),_H6('return fib(n-1) + fib(n-2);'),_H6('Медленно для n>30 — для теста n≤15')],
 testCases:[
  {input:'6',output:'8',hidden:false},
  {input:'1',output:'1',hidden:true},
  {input:'10',output:'55',hidden:true}
 ],
 initialCode:_T6(_M6('int fib(int n) {\n    // рекурсия\n}','int n;\n    scanf("%d", &n);\n    printf("%d", fib(n));'))
},
{
 id:20,difficulty:'сложно',title:'Рекурсивная степень',
 description:'Напишите рекурсивную <code>int power(int base, int exp)</code>: base^exp (exp ≥ 0).',
 hints:[_H6('if (exp == 0) return 1;'),_H6('return base * power(base, exp - 1);')],
 testCases:[
  {input:'2 8',output:'256',hidden:false},
  {input:'3 3',output:'27',hidden:true},
  {input:'5 1',output:'5',hidden:true}
 ],
 initialCode:_T6(_M6('int power(int base, int exp) {\n    // рекурсия\n}','int b, e;\n    scanf("%d %d", &b, &e);\n    printf("%d", power(b, e));'))
},
{
 id:21,difficulty:'сложно',title:'Рекурсивный НОД',
 description:'Напишите рекурсивную <code>int gcd(int a, int b)</code>.',
 hints:[_H6('if (b == 0) return a;'),_H6('return gcd(b, a % b);')],
 testCases:[
  {input:'48 18',output:'6',hidden:false},
  {input:'100 75',output:'25',hidden:true},
  {input:'13 7',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('int gcd(int a, int b) {\n    // рекурсия\n}','int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d", gcd(a, b));'))
},
{
 id:22,difficulty:'сложно',title:'Рекурсивная сумма цифр',
 description:'Напишите рекурсивную <code>int digit_sum(int n)</code> для n &gt; 0.',
 hints:[_H6('if (n < 10) return n;'),_H6('return n % 10 + digit_sum(n / 10);')],
 testCases:[
  {input:'9875',output:'29',hidden:false},
  {input:'100',output:'1',hidden:true},
  {input:'55',output:'10',hidden:true}
 ],
 initialCode:_T6(_M6('int digit_sum(int n) {\n    // рекурсия\n}','int n;\n    scanf("%d", &n);\n    printf("%d", digit_sum(n));'))
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'Быстрое возведение в степень',
 description:'Напишите рекурсивную <code>long fast_power(long base, int exp)</code> с O(log n): если exp чётное → (base²)^(exp/2), иначе → base × base^(exp-1).',
 hints:[_H6('if (exp == 0) return 1;'),_H6('if (exp % 2 == 0) { long h = fast_power(base, exp/2); return h*h; }'),_H6('return base * fast_power(base, exp-1);')],
 testCases:[
  {input:'2 20',output:'1048576',hidden:false},
  {input:'3 10',output:'59049',hidden:true},
  {input:'7 0',output:'1',hidden:true}
 ],
 initialCode:_T6(_M6('long fast_power(long base, int exp) {\n    // быстрое возведение\n}','long b; int e;\n    scanf("%ld %d", &b, &e);\n    printf("%ld", fast_power(b, e));'))
},
{
 id:24,difficulty:'супер',title:'Числа Фибоначчи — итерация vs рекурсия',
 description:'Напишите <b>итерационную</b> <code>long fib_iter(int n)</code>. Считайте N и выведите fib(N). fib(1)=1, fib(2)=1.',
 hints:[_H6('long a=1, b=1; for(int i=2; i<n; i++) { long t=a+b; a=b; b=t; }'),_H6('printf("%ld", b);')],
 testCases:[
  {input:'10',output:'55',hidden:false},
  {input:'1',output:'1',hidden:true},
  {input:'15',output:'610',hidden:true}
 ],
 initialCode:_T6(_M6('long fib_iter(int n) {\n    // итерация — без рекурсии\n}','int n;\n    scanf("%d", &n);\n    printf("%ld", fib_iter(n));'))
}
];
