window.TASKS=window.TASKS||{};
const _T12=(c)=>`#include <stdio.h>\n#include <string.h>\n#include <ctype.h>\n\n${c}\n`;
const _H12=(t)=>({text:t,penalty:5});

window.TASKS[12]=[
{
 id:1,difficulty:'легко',title:'Длина строки (strlen)',
 description:'Считайте строку (без пробелов, до 100 символов) и выведите её длину с помощью <code>strlen()</code>.',
 hints:[_H12('strlen возвращает size_t — количество символов без нулевого терминатора'),_H12('char s[101]; scanf("%s",s);'),_H12('printf("%zu\\n", strlen(s));')],
 testCases:[
  {input:'hello',output:'5',hidden:false},
  {input:'a',output:'1',hidden:false},
  {input:'programming',output:'11',hidden:true},
  {input:'C',output:'1',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[101];\n    scanf("%s", s);\n    // выведите длину строки\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Копирование строки (strcpy)',
 description:'Считайте строку и скопируйте её в другой массив с помощью <code>strcpy()</code>, затем выведите копию.',
 hints:[_H12('strcpy(dst, src) — копирует src в dst вместе с нулевым терминатором'),_H12('char a[101], b[101];'),_H12('scanf("%s",a); strcpy(b,a); puts(b);')],
 testCases:[
  {input:'world',output:'world',hidden:false},
  {input:'lunar',output:'lunar',hidden:false},
  {input:'academy',output:'academy',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char a[101], b[101];\n    scanf("%s", a);\n    // скопируйте a в b и выведите b\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Сравнение строк (strcmp)',
 description:'Считайте две строки и выведите <code>EQUAL</code> если они одинаковы, иначе <code>NOT EQUAL</code>.',
 hints:[_H12('strcmp возвращает 0 если строки одинаковы'),_H12('if(strcmp(a,b)==0) puts("EQUAL");'),_H12('Сравнение чувствительно к регистру: "Hello" != "hello"')],
 testCases:[
  {input:'apple\napple',output:'EQUAL',hidden:false},
  {input:'cat\ndog',output:'NOT EQUAL',hidden:false},
  {input:'Hello\nhello',output:'NOT EQUAL',hidden:true},
  {input:'abc\nabc',output:'EQUAL',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char a[101], b[101];\n    scanf("%s%s", a, b);\n    // сравните строки и выведите результат\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Конкатенация (strcat)',
 description:'Считайте две строки и выведите их конкатенацию (соединение) с помощью <code>strcat()</code>.',
 hints:[_H12('strcat(dst, src) добавляет src в конец dst — dst должен быть достаточно большим'),_H12('char a[201]; — запас для двух строк'),_H12('scanf("%s%s",a,b); strcat(a,b); puts(a);')],
 testCases:[
  {input:'Hello\nWorld',output:'HelloWorld',hidden:false},
  {input:'foo\nbar',output:'foobar',hidden:false},
  {input:'lunar\nacademy',output:'lunaracademy',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char a[201], b[101];\n    scanf("%s%s", a, b);\n    // соедините строки и выведите результат\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Поиск символа (strchr)',
 description:'Считайте строку и символ. Если символ есть в строке — выведите <code>FOUND</code>, иначе <code>NOT FOUND</code>.',
 hints:[_H12('strchr(s, c) возвращает указатель на первое вхождение c в s, или NULL'),_H12('char c; scanf(" %c",&c);'),_H12('if(strchr(s,c)) puts("FOUND");')],
 testCases:[
  {input:'hello\nl',output:'FOUND',hidden:false},
  {input:'world\nz',output:'NOT FOUND',hidden:false},
  {input:'programming\nm',output:'FOUND',hidden:true},
  {input:'abc\nd',output:'NOT FOUND',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[101], c;\n    scanf("%s %c", s, &c);\n    // найдите символ c в строке s\n    return 0;\n}')
},
{
 id:6,difficulty:'легко',title:'Поиск подстроки (strstr)',
 description:'Считайте строку и подстроку. Если подстрока найдена — выведите <code>FOUND</code>, иначе <code>NOT FOUND</code>.',
 hints:[_H12('strstr(haystack, needle) — ищет needle в haystack, возвращает указатель или NULL'),_H12('if(strstr(s, sub)!=NULL) puts("FOUND");'),_H12('Поиск чувствителен к регистру')],
 testCases:[
  {input:'hello world\nworld',output:'FOUND',hidden:false},
  {input:'programming\nxyz',output:'NOT FOUND',hidden:false},
  {input:'lunar academy\nacad',output:'FOUND',hidden:true},
  {input:'abcdef\ngh',output:'NOT FOUND',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[101], sub[51];\n    scanf("%s%s", s, sub);\n    // найдите подстроку sub в строке s\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'sprintf — форматирование в строку',
 description:'Считайте имя (строку) и возраст (int). С помощью <code>sprintf()</code> создайте строку вида <code>Name: Ivan, Age: 20</code> и выведите её.',
 hints:[_H12('sprintf(buf, format, ...) работает как printf, но пишет в строку'),_H12('char buf[200]; sprintf(buf,"Name: %s, Age: %d", name, age);'),_H12('puts(buf); — вывод готовой строки')],
 testCases:[
  {input:'Ivan\n20',output:'Name: Ivan, Age: 20',hidden:false},
  {input:'Alice\n25',output:'Name: Alice, Age: 25',hidden:false},
  {input:'Bob\n30',output:'Name: Bob, Age: 30',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char name[51], buf[200];\n    int age;\n    scanf("%s%d", name, &age);\n    // создайте строку вида "Name: ..., Age: ..." и выведите её\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'sscanf — чтение из строки',
 description:'Дана строка вида <code>42 3.14</code>. С помощью <code>sscanf()</code> извлеките целое и вещественное число, выведите их сумму с 2 знаками после запятой.',
 hints:[_H12('sscanf(str, format, ...) — чтение из строки как из stdin'),_H12('char line[101]; fgets(line,101,stdin);'),_H12('int a; float b; sscanf(line,"%d %f",&a,&b);')],
 testCases:[
  {input:'42 3.14',output:'45.14',hidden:false},
  {input:'10 0.5',output:'10.50',hidden:false},
  {input:'100 2.71',output:'102.71',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char line[101];\n    fgets(line, 101, stdin);\n    // извлеките числа из строки и выведите сумму\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'strncpy — безопасное копирование',
 description:'Считайте строку длиной до 100 символов. Скопируйте первые <b>N</b> символов в новый буфер с помощью <code>strncpy()</code> и выведите результат. N вводится отдельно.',
 hints:[_H12('strncpy(dst, src, n) — копирует не более n символов'),_H12('Если src короче n — остаток заполняется нулями. Если длиннее — нулевой терминатор НЕ добавляется!'),_H12('buf[n]=\'\\0\'; — добавьте вручную')],
 testCases:[
  {input:'hello\n3',output:'hel',hidden:false},
  {input:'programming\n7',output:'program',hidden:false},
  {input:'lunar\n4',output:'luna',hidden:true},
  {input:'abc\n5',output:'abc',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[101], buf[101];\n    int n;\n    scanf("%s%d", s, &n);\n    // скопируйте первые n символов s в buf и выведите\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'strncat — ограниченная конкатенация',
 description:'Считайте две строки и число N. Добавьте к первой строке не более N символов второй строки с помощью <code>strncat()</code>.',
 hints:[_H12('strncat(dst, src, n) — добавляет не более n символов src к dst'),_H12('strncat автоматически добавляет нулевой терминатор'),_H12('char a[201]; — достаточно места')],
 testCases:[
  {input:'Hello\nWorld\n3',output:'HelloWor',hidden:false},
  {input:'foo\nbar\n2',output:'fooba',hidden:false},
  {input:'abc\ndefgh\n4',output:'abcdefg',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char a[201], b[101];\n    int n;\n    scanf("%s%s%d", a, b, &n);\n    // добавьте n символов b к a и выведите a\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Перевод строки в верхний регистр',
 description:'Считайте строку и выведите её в верхнем регистре. Используйте <code>toupper()</code> из <code>&lt;ctype.h&gt;</code>.',
 hints:[_H12('toupper(c) — возвращает верхний регистр символа c (из ctype.h)'),_H12('Цикл по символам: for(int i=0;s[i];i++) s[i]=toupper(s[i]);'),_H12('Неалфавитные символы toupper оставляет без изменений')],
 testCases:[
  {input:'hello',output:'HELLO',hidden:false},
  {input:'World',output:'WORLD',hidden:false},
  {input:'lunar123',output:'LUNAR123',hidden:true},
  {input:'abc',output:'ABC',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[101];\n    scanf("%s", s);\n    // переведите строку в верхний регистр и выведите\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'Перевод строки в нижний регистр',
 description:'Считайте строку и выведите её в нижнем регистре. Используйте <code>tolower()</code> из <code>&lt;ctype.h&gt;</code>.',
 hints:[_H12('tolower(c) — возвращает нижний регистр символа c'),_H12('for(int i=0;s[i];i++) s[i]=tolower(s[i]);'),_H12('Работает только с латиницей — кириллицу не затрагивает')],
 testCases:[
  {input:'HELLO',output:'hello',hidden:false},
  {input:'WORLD',output:'world',hidden:false},
  {input:'LUNAR123',output:'lunar123',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[101];\n    scanf("%s", s);\n    // переведите строку в нижний регистр и выведите\n    return 0;\n}')
},
{
 id:13,difficulty:'средне',title:'Подсчёт вхождений подстроки',
 description:'Считайте строку S и подстроку P. Выведите количество вхождений P в S (непересекающихся).',
 hints:[_H12('strstr возвращает указатель на найденную подстроку'),_H12('После нахождения сдвигайся на длину подстроки: pos = strstr(pos+strlen(p), p)'),_H12('int cnt=0; char *pos=s; while((pos=strstr(pos,p))!=NULL){cnt++;pos+=strlen(p);}')],
 testCases:[
  {input:'abababab\nab',output:'4',hidden:false},
  {input:'hello world\nllo',output:'1',hidden:false},
  {input:'aaaaaa\naa',output:'3',hidden:true},
  {input:'abc\nxyz',output:'0',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[201], p[51];\n    scanf("%s%s", s, p);\n    // подсчитайте непересекающиеся вхождения p в s\n    return 0;\n}')
},
{
 id:14,difficulty:'средне',title:'Позиция подстроки',
 description:'Считайте строку S и подстроку P. Выведите <b>индекс (с нуля)</b> первого вхождения P в S, или <code>-1</code> если не найдено.',
 hints:[_H12('strstr возвращает указатель — вычти адрес начала строки для индекса'),_H12('char *p = strstr(s, sub); if(p) printf("%d\\n",(int)(p-s));'),_H12('else printf("-1\\n");')],
 testCases:[
  {input:'hello\nell',output:'1',hidden:false},
  {input:'abcdef\ncd',output:'2',hidden:false},
  {input:'world\nxyz',output:'-1',hidden:true},
  {input:'programming\ngram',output:'3',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[101], sub[51];\n    scanf("%s%s", s, sub);\n    // выведите индекс первого вхождения sub в s или -1\n    return 0;\n}')
},
{
 id:15,difficulty:'сложно',title:'Замена подстроки',
 description:'Считайте строку S, подстроку OLD и подстроку NEW. Замените первое вхождение OLD на NEW в строке S и выведите результат.<br><small>Гарантируется: |S| ≤ 100, |NEW| ≤ |OLD|+20, результат поместится в буфер.</small>',
 hints:[_H12('Найдите позицию: char *pos = strstr(s, old);'),_H12('Скопируйте часть до pos, затем new, затем pos+strlen(old)'),_H12('Используйте sprintf или ручное копирование через strncpy+strcat')],
 testCases:[
  {input:'hello world\nworld\nearth',output:'hello earth',hidden:false},
  {input:'foo bar foo\nfoo\nbaz',output:'baz bar foo',hidden:false},
  {input:'abcdef\ncd\nXX',output:'abXXef',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[200], old[51], nw[71], res[300];\n    scanf("%s%s%s", s, old, nw);\n    // замените первое вхождение old на nw в s\n    return 0;\n}')
},
{
 id:16,difficulty:'сложно',title:'Разбивка строки по разделителю (strtok)',
 description:'Считайте строку слов, разделённых запятой. Выведите каждое слово на отдельной строке, используя <code>strtok()</code>.',
 hints:[_H12('strtok(s, delim) — первый вызов передаёт строку, следующие — NULL'),_H12('char *tok = strtok(s, ","); while(tok){puts(tok); tok=strtok(NULL,",");}'),_H12('strtok модифицирует строку — работайте с копией если нужен оригинал')],
 testCases:[
  {input:'one,two,three',output:'one\ntwo\nthree',hidden:false},
  {input:'a,b,c,d',output:'a\nb\nc\nd',hidden:false},
  {input:'hello,world,foo',output:'hello\nworld\nfoo',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[201];\n    scanf("%s", s);\n    // разбейте строку по запятой и выведите каждый токен\n    return 0;\n}')
},
{
 id:17,difficulty:'сложно',title:'Является ли строка палиндромом (с нормализацией)',
 description:'Считайте строку (может содержать разный регистр и пробелы). Приведите к нижнему регистру, уберите пробелы, затем проверьте: палиндром ли. Выведите <code>YES</code> или <code>NO</code>.',
 hints:[_H12('Сначала фильтруйте только буквы, приводя к нижнему регистру'),_H12('Затем сравните строку с её обратной версией'),_H12('strcmp(clean, rev) == 0 — палиндром')],
 testCases:[
  {input:'A man a plan a canal Panama',output:'YES',hidden:false},
  {input:'racecar',output:'YES',hidden:false},
  {input:'hello',output:'NO',hidden:true},
  {input:'Was it a car or a cat I saw',output:'YES',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char line[201], clean[201], rev[201];\n    fgets(line, 201, stdin);\n    // нормализуйте строку и проверьте палиндром\n    return 0;\n}')
},
{
 id:18,difficulty:'супер',title:'Сжатие строки (RLE)',
 description:'Реализуйте кодирование повторяющихся символов (Run-Length Encoding). Для строки <code>aaabbc</code> выведите <code>a3b2c1</code>. Если сжатая версия длиннее — выведите оригинал.',
 hints:[_H12('Проходите по строке, считая подряд идущие одинаковые символы'),_H12('sprintf в буфер результата: sprintf(res+pos,"%c%d",s[i],cnt)'),_H12('Если strlen(res)>=strlen(s) — puts(s), иначе puts(res)')],
 testCases:[
  {input:'aaabbc',output:'a3b2c1',hidden:false},
  {input:'aabbcc',output:'a2b2c2',hidden:false},
  {input:'abcde',output:'abcde',hidden:true},
  {input:'aaaa',output:'a4',hidden:true},
  {input:'aabbaabb',output:'a2b2a2b2',hidden:true}
 ],
 initialCode:_T12('int main(){\n    char s[201], res[401];\n    scanf("%s", s);\n    // реализуйте RLE-кодирование\n    return 0;\n}')
}
];
