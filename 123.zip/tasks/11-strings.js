window.TASKS=window.TASKS||{};
const _T11=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H11=(t)=>({text:t,penalty:5});

window.TASKS[11]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'ASCII символа',
 description:'Считайте один символ через <code>scanf(" %c", &c)</code> и выведите его ASCII-код.',
 hints:[_H11('scanf(" %c", &c);'),_H11('printf("%d", c);')],
 testCases:[
  {input:'A',output:'65',hidden:false},
  {input:'a',output:'97',hidden:true},
  {input:'0',output:'48',hidden:true}
 ],
 initialCode:_T11('int main(void) {\n    char c;\n    scanf(" %c", &c);\n    printf("%d", c);\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Заглавная буква',
 description:'Считайте строчную букву a–z. Выведите соответствующую заглавную (без ctype.h).',
 hints:[_H11('Заглавная = строчная - 32'),_H11('printf("%c", c - 32);')],
 testCases:[
  {input:'a',output:'A',hidden:false},
  {input:'z',output:'Z',hidden:true},
  {input:'m',output:'M',hidden:true}
 ],
 initialCode:_T11('int main(void) {\n    char c;\n    scanf(" %c", &c);\n    printf("%c", c - 32);\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Цифра или нет',
 description:'Считайте символ. Выведите <code>1</code> если цифра (0–9), иначе <code>0</code>.',
 hints:[_H11("c >= '0' && c <= '9'"),_H11('printf("%d", c>=\'0\' && c<=\'9\');')],
 testCases:[
  {input:'5',output:'1',hidden:false},
  {input:'A',output:'0',hidden:true},
  {input:'9',output:'1',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char c;\n    scanf(\" %c\", &c);\n    printf(\"%d\", c>='0' && c<='9');\n    return 0;\n}")
},
{
 id:4,difficulty:'легко',title:'Первый символ строки',
 description:'Считайте слово (без пробелов). Выведите его первый символ.',
 hints:[_H11('char s[101]; scanf("%s", s);'),_H11('printf("%c", s[0]);')],
 testCases:[
  {input:'hello',output:'h',hidden:false},
  {input:'World',output:'W',hidden:true},
  {input:'C',output:'C',hidden:true}
 ],
 initialCode:_T11('int main(void) {\n    char s[101];\n    scanf("%s", s);\n    printf("%c", s[0]);\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Посимвольный вывод строки',
 description:'Считайте слово. Выведите каждый символ на отдельной строке.',
 hints:[_H11('char s[101]; scanf("%s", s);'),_H11('for(int i=0; s[i]!=\'\\0\'; i++) printf("%c\\n", s[i]);')],
 testCases:[
  {input:'abc',output:'a\nb\nc',hidden:false},
  {input:'hi',output:'h\ni',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i;\n    scanf(\"%s\", s);\n    for(i=0; s[i]!='\\0'; i++) printf(\"%c\\n\", s[i]);\n    return 0;\n}")
},
{
 id:6,difficulty:'легко',title:'Длина строки вручную',
 description:'Считайте слово. Найдите и выведите его длину — вручную, через цикл до <code>\'\\0\'</code> (без <code>strlen</code>).',
 hints:[_H11("int len=0; while(s[len]!='\\0') len++;"),_H11('printf("%d", len);')],
 testCases:[
  {input:'hello',output:'5',hidden:false},
  {input:'C',output:'1',hidden:true},
  {input:'test123',output:'7',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int len=0;\n    scanf(\"%s\", s);\n    while(s[len]!='\\0') len++;\n    printf(\"%d\", len);\n    return 0;\n}")
},
{
 id:7,difficulty:'легко',title:'Последний символ',
 description:'Считайте слово. Найдите длину вручную, выведите последний символ.',
 hints:[_H11("int len=0; while(s[len]!='\\0') len++;"),_H11('printf("%c", s[len-1]);')],
 testCases:[
  {input:'hello',output:'o',hidden:false},
  {input:'abc',output:'c',hidden:true},
  {input:'X',output:'X',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int len=0;\n    scanf(\"%s\",s);\n    while(s[len]) len++;\n    printf(\"%c\",s[len-1]);\n    return 0;\n}")
},
{
 id:8,difficulty:'легко',title:'Заглавность буквы',
 description:'Считайте английскую букву. Выведите <code>upper</code> или <code>lower</code>.',
 hints:[_H11("if (c >= 'A' && c <= 'Z') printf(\"upper\");"),_H11('else printf("lower");')],
 testCases:[
  {input:'A',output:'upper',hidden:false},
  {input:'h',output:'lower',hidden:true},
  {input:'Z',output:'upper',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char c;\n    scanf(\" %c\",&c);\n    if(c>='A'&&c<='Z') printf(\"upper\");\n    else printf(\"lower\");\n    return 0;\n}")
},
{
 id:9,difficulty:'легко',title:'Подсчёт гласных',
 description:'Считайте слово (только латинские буквы). Выведите количество гласных (a,e,i,o,u — и заглавные).',
 hints:[_H11("Гласные: 'a','e','i','o','u' — и их заглавные аналоги"),_H11('char vowels[] = "aeiouAEIOU"; используй strchr или ручной перебор')],
 testCases:[
  {input:'hello',output:'2',hidden:false},
  {input:'AEIOU',output:'5',hidden:true},
  {input:'bcdf',output:'0',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i, cnt=0;\n    scanf(\"%s\",s);\n    for(i=0;s[i];i++) {\n        char c=s[i];\n        if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||\n           c=='A'||c=='E'||c=='I'||c=='O'||c=='U') cnt++;\n    }\n    printf(\"%d\",cnt);\n    return 0;\n}")
},
{
 id:10,difficulty:'легко',title:'Скопировать строку вручную',
 description:'Считайте слово. Скопируйте в другой массив вручную (без strcpy). Выведите копию.',
 hints:[_H11("char dst[101]; int i=0; while((dst[i]=src[i])!='\\0') i++;"),_H11('printf("%s", dst);')],
 testCases:[
  {input:'hello',output:'hello',hidden:false},
  {input:'abc',output:'abc',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char src[101], dst[101];\n    int i=0;\n    scanf(\"%s\",src);\n    while((dst[i]=src[i])!='\\0') i++;\n    printf(\"%s\",dst);\n    return 0;\n}")
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'Регистр буквы',
 description:'Считайте символ (английскую букву). Выведите <code>upper</code> (заглавная) или <code>lower</code> (строчная).',
 hints:[_H11("if (c >= 'A' && c <= 'Z') printf(\"upper\"); else printf(\"lower\");")],
 testCases:[
  {input:'A',output:'upper',hidden:false},
  {input:'h',output:'lower',hidden:true},
  {input:'q',output:'lower',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char c;\n    scanf(\" %c\",&c);\n    // определите регистр\n    return 0;\n}")
},
{
 id:12,difficulty:'средне',title:'Строку в верхний регистр',
 description:'Считайте слово. Переведите каждую строчную букву в заглавную (без ctype.h). Выведите результат.',
 hints:[_H11("if(s[i]>='a' && s[i]<='z') s[i]-=32;")],
 testCases:[
  {input:'hello',output:'HELLO',hidden:false},
  {input:'World',output:'WORLD',hidden:true},
  {input:'abc123',output:'ABC123',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i;\n    scanf(\"%s\",s);\n    for(i=0;s[i];i++) if(s[i]>='a'&&s[i]<='z') s[i]-=32;\n    printf(\"%s\",s);\n    return 0;\n}")
},
{
 id:13,difficulty:'средне',title:'Обращение строки',
 description:'Считайте слово. Выведите его в обратном порядке (без strrev).',
 hints:[_H11("int len=0; while(s[len]) len++;"),_H11('for(i=len-1;i>=0;i--) printf("%c",s[i]);'),_H11('Или: поменять местами символы с двух концов')],
 testCases:[
  {input:'hello',output:'olleh',hidden:false},
  {input:'abcde',output:'edcba',hidden:true},
  {input:'a',output:'a',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i, len=0;\n    scanf(\"%s\",s);\n    while(s[len]) len++;\n    for(i=len-1;i>=0;i--) printf(\"%c\",s[i]);\n    return 0;\n}")
},
{
 id:14,difficulty:'средне',title:'Подсчёт символа в строке',
 description:'Считайте слово и символ. Выведите, сколько раз этот символ встречается в слове.',
 hints:[_H11('int cnt=0; for(i=0;s[i];i++) if(s[i]==c) cnt++;'),_H11('printf("%d",cnt);')],
 testCases:[
  {input:'hello l',output:'2',hidden:false},
  {input:'banana a',output:'3',hidden:true},
  {input:'abc x',output:'0',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101], c;\n    int i, cnt=0;\n    scanf(\"%s %c\",s,&c);\n    for(i=0;s[i];i++) if(s[i]==c) cnt++;\n    printf(\"%d\",cnt);\n    return 0;\n}")
},
{
 id:15,difficulty:'средне',title:'Содержит цифру?',
 description:'Считайте слово. Выведите <code>1</code> если содержит хотя бы одну цифру (0–9), иначе <code>0</code>.',
 hints:[_H11("for(i=0;s[i];i++) if(s[i]>='0'&&s[i]<='9') { printf(\"1\"); return 0; }"),_H11('printf("0");')],
 testCases:[
  {input:'abc1',output:'1',hidden:false},
  {input:'hello',output:'0',hidden:true},
  {input:'12345',output:'1',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i, found=0;\n    scanf(\"%s\",s);\n    for(i=0;s[i];i++) if(s[i]>='0'&&s[i]<='9') { found=1; break; }\n    printf(\"%d\",found);\n    return 0;\n}")
},
{
 id:16,difficulty:'средне',title:'Сравнение строк вручную',
 description:'Считайте два слова. Выведите <code>0</code> если равны, <code>1</code> если первое лексически больше, <code>-1</code> если меньше.',
 hints:[_H11("while(*a && *a==*b) { a++; b++; }"),_H11('if(*a == *b) 0; else *a > *b ? 1 : -1')],
 testCases:[
  {input:'abc abc',output:'0',hidden:false},
  {input:'b a',output:'1',hidden:true},
  {input:'apple banana',output:'-1',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char a[101], b[101];\n    int i=0;\n    scanf(\"%s %s\",a,b);\n    while(a[i]&&a[i]==b[i]) i++;\n    if(a[i]==b[i]) printf(\"0\");\n    else printf(\"%d\", a[i]>b[i] ? 1 : -1);\n    return 0;\n}")
},
{
 id:17,difficulty:'средне',title:'Проверка палиндрома',
 description:'Считайте слово. Выведите <code>1</code> если оно является палиндромом (читается одинаково в обоих направлениях), иначе <code>0</code>.',
 hints:[_H11("int len=0; while(s[len]) len++;"),_H11('int i=0, j=len-1; while(i<j) if(s[i++]!=s[j--]) { printf("0"); return 0; }'),_H11('printf("1");')],
 testCases:[
  {input:'madam',output:'1',hidden:false},
  {input:'hello',output:'0',hidden:true},
  {input:'a',output:'1',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i, j, len=0;\n    scanf(\"%s\",s);\n    while(s[len]) len++;\n    i=0; j=len-1;\n    while(i<j) if(s[i++]!=s[j--]) { printf(\"0\"); return 0; }\n    printf(\"1\");\n    return 0;\n}")
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'Разница букв',
 description:'Считайте два символа (буквы одного регистра). Выведите их разницу в алфавите (b - a).',
 hints:[_H11('scanf(" %c %c", &a, &b);'),_H11('printf("%d", b - a);')],
 testCases:[
  {input:'A C',output:'2',hidden:false},
  {input:'a z',output:'25',hidden:true},
  {input:'M D',output:'-9',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char a, b;\n    scanf(\" %c %c\",&a,&b);\n    printf(\"%d\",b-a);\n    return 0;\n}")
},
{
 id:19,difficulty:'сложно',title:'Шифр Цезаря',
 description:'Считайте слово (только латинские строчные буквы) и сдвиг k (0–25). Выведите зашифрованное слово (сдвиг по кругу).',
 hints:[_H11("s[i] = 'a' + (s[i] - 'a' + k) % 26;")],
 testCases:[
  {input:'hello 3',output:'khoor',hidden:false},
  {input:'abc 1',output:'bcd',hidden:true},
  {input:'xyz 3',output:'abc',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101]; int k, i;\n    scanf(\"%s %d\",s,&k);\n    for(i=0;s[i];i++) s[i]='a'+(s[i]-'a'+k)%26;\n    printf(\"%s\",s);\n    return 0;\n}")
},
{
 id:20,difficulty:'сложно',title:'Удаление пробелов',
 description:'Считайте строку (до 100 символов, с пробелами) через <code>fgets</code>. Удалите все пробелы. Выведите результат.',
 hints:[_H11('fgets(s, 101, stdin); // читает строку с пробелами'),_H11("int j=0; for(i=0;s[i]&&s[i]!='\\n';i++) if(s[i]!=' ') dst[j++]=s[i]; dst[j]=0;")],
 testCases:[
  {input:'hello world',output:'helloworld',hidden:false},
  {input:'a b c',output:'abc',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101], dst[101];\n    int i, j=0;\n    fgets(s,101,stdin);\n    for(i=0;s[i]&&s[i]!='\\n';i++) if(s[i]!=' ') dst[j++]=s[i];\n    dst[j]=0;\n    printf(\"%s\",dst);\n    return 0;\n}")
},
{
 id:21,difficulty:'сложно',title:'Подсчёт слов',
 description:'Считайте строку (до 100 символов). Выведите количество слов (слова разделяются пробелами).',
 hints:[_H11('int words=0, in_word=0;'),_H11("for(i=0;s[i]&&s[i]!='\\n';i++) if(s[i]!=' ') { if(!in_word) {words++;in_word=1;} } else in_word=0;")],
 testCases:[
  {input:'hello world',output:'2',hidden:false},
  {input:'one two three four',output:'4',hidden:true},
  {input:'single',output:'1',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i, words=0, in_word=0;\n    fgets(s,101,stdin);\n    for(i=0;s[i]&&s[i]!='\\n';i++) {\n        if(s[i]!=' ') { if(!in_word){words++;in_word=1;} }\n        else in_word=0;\n    }\n    printf(\"%d\",words);\n    return 0;\n}")
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'Наибольшая серия одинаковых символов',
 description:'Считайте слово. Найдите наибольшую серию одинаковых символов подряд. Выведите символ и длину серии через пробел.',
 hints:[_H11('int maxlen=1, curlen=1; char maxc=s[0];'),_H11('Если s[i]==s[i-1]: curlen++; если curlen>maxlen: maxlen=curlen; maxc=s[i];'),_H11('printf("%c %d", maxc, maxlen);')],
 testCases:[
  {input:'aabbbcc',output:'b 3',hidden:false},
  {input:'aaaa',output:'a 4',hidden:true},
  {input:'abc',output:'a 1',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101];\n    int i, curlen=1, maxlen=1; char maxc;\n    scanf(\"%s\",s);\n    maxc=s[0];\n    for(i=1;s[i];i++) {\n        if(s[i]==s[i-1]) curlen++; else curlen=1;\n        if(curlen>maxlen) { maxlen=curlen; maxc=s[i]; }\n    }\n    printf(\"%c %d\",maxc,maxlen);\n    return 0;\n}")
},
{
 id:24,difficulty:'супер',title:'Шифрование XOR',
 description:'Считайте слово и ключ k (1–127). XOR каждого символа с k. Если результат печатаемый (ASCII 32–126) — вывести, иначе заменить на <code>?</code>.',
 hints:[_H11('for(i=0;s[i];i++) { int r = s[i]^k; printf("%c", (r>=32&&r<=126)? r : \'?\'); }')],
 testCases:[
  {input:'ABC 1',output:'@CB',hidden:false},
  {input:'hello 0',output:'hello',hidden:true}
 ],
 initialCode:_T11("int main(void) {\n    char s[101]; int k, i;\n    scanf(\"%s %d\",s,&k);\n    for(i=0;s[i];i++) {\n        int r=s[i]^k;\n        printf(\"%c\",(r>=32&&r<=126)?r:'?');\n    }\n    return 0;\n}")
}
];
