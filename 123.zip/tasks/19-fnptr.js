window.TASKS=window.TASKS||{};
const _T19=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H19=(t)=>({text:t,penalty:5});

window.TASKS[19]=[
{
 id:1,difficulty:'легко',title:'Первый указатель на функцию',
 description:'Создайте функцию <code>square(int x)</code>, возвращающую x². Объявите указатель на неё и вызовите через указатель.',
 hints:[_H19('Тип указателя на int(*)(int): int (*fp)(int);'),_H19('fp = square; — присвоение (без скобок и &)'),_H19('printf("%d\\n", fp(5)); — вызов через указатель')],
 testCases:[
  {input:'5',output:'25',hidden:false},
  {input:'3',output:'9',hidden:false},
  {input:'7',output:'49',hidden:true}
 ],
 initialCode:_T19('int square(int x){ return x*x; }\nint main(){\n    int (*fp)(int);\n    // присвойте fp = square и вызовите через fp\n    int n; scanf("%d",&n);\n    // выведите результат\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Калькулятор через указатели',
 description:'Реализуйте функции add, sub, mul, div_int. Считайте операцию (+,-,*,/) и два числа. Выберите нужную функцию через указатель и выведите результат.',
 hints:[_H19('int (*op)(int,int) — указатель на функцию двух int'),_H19('switch(c){ case \'+\': op=add; break; ... }'),_H19('printf("%d\\n", op(a,b));')],
 testCases:[
  {input:'+ 3 4',output:'7',hidden:false},
  {input:'* 5 6',output:'30',hidden:false},
  {input:'- 10 3',output:'7',hidden:true},
  {input:'/ 15 3',output:'5',hidden:true}
 ],
 initialCode:_T19('int add(int a,int b){return a+b;}\nint sub(int a,int b){return a-b;}\nint mul(int a,int b){return a*b;}\nint div_int(int a,int b){return a/b;}\nint main(){\n    char op; int a,b;\n    scanf(" %c%d%d",&op,&a,&b);\n    int (*fn)(int,int);\n    // выберите функцию по символу операции\n    printf("%d\\n",fn(a,b));\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Массив указателей на функции',
 description:'Создайте массив из 4 функций (add, sub, mul, div_int). Считайте индекс (0-3) и два числа. Вызовите функцию по индексу.',
 hints:[_H19('int (*ops[4])(int,int) = {add, sub, mul, div_int};'),_H19('ops[idx](a,b) — вызов по индексу'),_H19('Можно инициализировать при объявлении')],
 testCases:[
  {input:'0 8 3',output:'11',hidden:false},
  {input:'2 4 5',output:'20',hidden:false},
  {input:'1 10 4',output:'6',hidden:true}
 ],
 initialCode:_T19('int add(int a,int b){return a+b;}\nint sub(int a,int b){return a-b;}\nint mul(int a,int b){return a*b;}\nint dv(int a,int b){return a/b;}\nint main(){\n    int (*ops[4])(int,int)={add,sub,mul,dv};\n    int idx,a,b;\n    scanf("%d%d%d",&idx,&a,&b);\n    printf("%d\\n",ops[idx](a,b));\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Передача функции в функцию',
 description:'Напишите функцию <code>apply(int*a, int n, int(*f)(int))</code>, которая применяет f к каждому элементу массива на месте. Применить <code>square</code> и вывести результат.',
 hints:[_H19('void apply(int*a, int n, int(*f)(int)){for(int i=0;i<n;i++) a[i]=f(a[i]);}'),_H19('Передача: apply(a, n, square);'),_H19('Указатель на функцию — обычный параметр')],
 testCases:[
  {input:'4\n1 2 3 4',output:'1 4 9 16',hidden:false},
  {input:'3\n3 4 5',output:'9 16 25',hidden:false}
 ],
 initialCode:_T19('int square(int x){return x*x;}\nvoid apply(int*a,int n,int(*f)(int)){\n    for(int i=0;i<n;i++) a[i]=f(a[i]);\n}\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    apply(a,n,square);\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:5,difficulty:'средне',title:'Функция high-order: map',
 description:'Реализуйте <code>map(src, dst, n, f)</code> — создаёт новый массив применяя f к каждому элементу. Считайте массив и выведите результат применения <code>abs_val(x) = |x|</code>.',
 hints:[_H19('void map(int*src,int*dst,int n,int(*f)(int)){for(int i=0;i<n;i++) dst[i]=f(src[i]);}'),_H19('int abs_val(int x){return x<0?-x:x;}'),_H19('map не изменяет src, пишет результат в dst')],
 testCases:[
  {input:'5\n-3 1 -5 2 -4',output:'3 1 5 2 4',hidden:false},
  {input:'3\n-1 0 1',output:'1 0 1',hidden:false}
 ],
 initialCode:_T19('int abs_val(int x){return x<0?-x:x;}\nvoid map(int*src,int*dst,int n,int(*f)(int)){\n    // применяйте f к каждому элементу\n}\nint main(){\n    int n,a[100],b[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    map(a,b,n,abs_val);\n    for(int i=0;i<n;i++) printf("%d%c",b[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:6,difficulty:'средне',title:'Функция high-order: filter',
 description:'Реализуйте <code>filter(src, dst, n, pred)</code> — копирует в dst только элементы, для которых pred(x) != 0. Выведите элементы > 0.',
 hints:[_H19('int filter(int*src,int*dst,int n,int(*p)(int)){int k=0; for(int i=0;i<n;i++) if(p(src[i])) dst[k++]=src[i]; return k;}'),_H19('Функция возвращает количество отобранных элементов'),_H19('int positive(int x){return x>0;}')],
 testCases:[
  {input:'6\n-1 2 -3 4 0 5',output:'2 4 5',hidden:false},
  {input:'3\n-1 -2 -3',output:'',hidden:false},
  {input:'4\n1 2 3 4',output:'1 2 3 4',hidden:true}
 ],
 initialCode:_T19('int positive(int x){return x>0;}\nint filter(int*src,int*dst,int n,int(*p)(int)){\n    int k=0;\n    // скопируйте в dst элементы, для которых p(x)!=0\n    return k;\n}\nint main(){\n    int n,a[100],b[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    int k=filter(a,b,n,positive);\n    for(int i=0;i<k;i++) printf("%d%c",b[i]," \\n"[i==k-1]);\n    if(k==0) printf("\\n");\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'Функция high-order: reduce',
 description:'Реализуйте <code>reduce(a, n, init, f)</code> — свёртка массива: накапливает результат через f(acc, x). Посчитайте сумму и произведение.',
 hints:[_H19('int reduce(int*a,int n,int init,int(*f)(int,int)){int acc=init; for(int i=0;i<n;i++) acc=f(acc,a[i]); return acc;}'),_H19('int sum2(int a,int b){return a+b;}'),_H19('reduce(a,n,0,sum2) — сумма; reduce(a,n,1,mul) — произведение')],
 testCases:[
  {input:'4\n1 2 3 4',output:'10\n24',hidden:false},
  {input:'3\n2 3 5',output:'10\n30',hidden:false}
 ],
 initialCode:_T19('int add2(int a,int b){return a+b;}\nint mul2(int a,int b){return a*b;}\nint reduce(int*a,int n,int init,int(*f)(int,int)){\n    int acc=init;\n    for(int i=0;i<n;i++) acc=f(acc,a[i]);\n    return acc;\n}\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    printf("%d\\n",reduce(a,n,0,add2));\n    printf("%d\\n",reduce(a,n,1,mul2));\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'qsort с пользовательским компаратором',
 description:'Считайте N чисел. Отсортируйте их по убыванию абсолютного значения (при равенстве — по убыванию исходного). Используйте <code>qsort</code>.',
 hints:[_H19('#include <stdlib.h>'),_H19('int cmp(const void*a,const void*b){int x=*(int*)a,y=*(int*)b; int ax=abs(x),ay=abs(y); if(ax!=ay) return ay-ax; return y-x;}'),_H19('abs() из stdlib.h')],
 testCases:[
  {input:'5\n-3 1 4 -1 5',output:'5 4 -3 -1 1',hidden:false},
  {input:'4\n2 -2 1 -1',output:'2 -2 1 -1',hidden:false}
 ],
 initialCode:_T19('#include <stdlib.h>\nint cmp(const void*a,const void*b){\n    int x=*(int*)a, y=*(int*)b;\n    int ax=abs(x), ay=abs(y);\n    if(ax!=ay) return ay-ax;\n    return y-x;\n}\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    qsort(a,n,sizeof(int),cmp);\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'Диспетчер команд',
 description:'Реализуйте диспетчер: массив пар (имя команды, функция). Считывайте команды из stdin и вызывайте соответствующую функцию. Команды: <code>hello</code>, <code>bye</code>, <code>time</code>.',
 hints:[_H19('struct Command{char name[20]; void(*fn)();};'),_H19('for(int i=0;i<N;i++) if(!strcmp(cmd,cmds[i].name)){cmds[i].fn();break;}'),_H19('#include <time.h> для time(NULL)')],
 testCases:[
  {input:'hello',output:'Hello, World!',hidden:false},
  {input:'bye',output:'Goodbye!',hidden:false}
 ],
 initialCode:_T19('#include <string.h>\nvoid cmd_hello(){puts("Hello, World!");}\nvoid cmd_bye(){puts("Goodbye!");}\nvoid cmd_time(){printf("Time: %lu\\n",(unsigned long)0);}\ntypedef struct{char name[20];void(*fn)();}Command;\nCommand cmds[]={{"hello",cmd_hello},{"bye",cmd_bye},{"time",cmd_time}};\nint main(){\n    char input[20]; scanf("%s",input);\n    int found=0;\n    for(int i=0;i<3;i++){\n        if(!strcmp(input,cmds[i].name)){cmds[i].fn();found=1;break;}\n    }\n    if(!found) puts("Unknown command");\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'Функция, возвращающая указатель на функцию',
 description:'Напишите функцию <code>get_op(char c)</code>, которая по символу операции (+,-,*,/) возвращает указатель на соответствующую функцию.',
 hints:[_H19('Тип возврата: int(*)(int,int)'),_H19('int(*get_op(char c))(int,int){ switch(c){...} }'),_H19('Или через typedef: typedef int(*OpFn)(int,int); OpFn get_op(char c){...}')],
 testCases:[
  {input:'+ 10 3',output:'13',hidden:false},
  {input:'- 10 3',output:'7',hidden:false},
  {input:'* 10 3',output:'30',hidden:true},
  {input:'/ 10 3',output:'3',hidden:true}
 ],
 initialCode:_T19('typedef int(*OpFn)(int,int);\nint add(int a,int b){return a+b;}\nint sub(int a,int b){return a-b;}\nint mul(int a,int b){return a*b;}\nint dv(int a,int b){return a/b;}\nOpFn get_op(char c){\n    // верните нужную функцию по символу c\n    return add;\n}\nint main(){\n    char c; int a,b;\n    scanf(" %c%d%d",&c,&a,&b);\n    printf("%d\\n",get_op(c)(a,b));\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Сортировка по нескольким критериям',
 description:'Считайте N точек (x,y). Реализуйте три компаратора: по X, по Y, по расстоянию от начала координат. Считайте режим (0,1,2) и отсортируйте соответственно.',
 hints:[_H19('typedef struct{int x,y;}Point;'),_H19('int(*cmps[3])(const void*,const void*)={cmp_x,cmp_y,cmp_dist};'),_H19('qsort(pts,n,sizeof(Point),cmps[mode]);')],
 testCases:[
  {input:'3 0\n3 1\n1 2\n2 0',output:'1 2\n2 0\n3 1',hidden:false},
  {input:'3 1\n3 1\n1 2\n2 0',output:'3 1\n2 0\n1 2',hidden:false}
 ],
 initialCode:_T19('#include <stdlib.h>\ntypedef struct{int x,y;}Point;\nint cmp_x(const void*a,const void*b){return ((Point*)a)->x-((Point*)b)->x;}\nint cmp_y(const void*a,const void*b){return ((Point*)a)->y-((Point*)b)->y;}\nint cmp_dist(const void*a,const void*b){\n    Point*p=(Point*)a; Point*q=(Point*)b;\n    return (p->x*p->x+p->y*p->y)-(q->x*q->x+q->y*q->y);\n}\nint main(){\n    int n,mode; scanf("%d%d",&n,&mode);\n    Point pts[100];\n    for(int i=0;i<n;i++) scanf("%d%d",&pts[i].x,&pts[i].y);\n    int(*cmps[3])(const void*,const void*)={cmp_x,cmp_y,cmp_dist};\n    qsort(pts,n,sizeof(Point),cmps[mode]);\n    for(int i=0;i<n;i++) printf("%d %d\\n",pts[i].x,pts[i].y);\n    return 0;\n}')
},
{
 id:12,difficulty:'сложно',title:'Применение функции N раз',
 description:'Напишите <code>apply_n(x, n, f)</code> — применяет функцию f к значению x ровно n раз. Считайте x и n. Функция: double_val(x) = x*2. Выведите результат.',
 hints:[_H19('int apply_n(int x,int n,int(*f)(int)){for(int i=0;i<n;i++) x=f(x); return x;}'),_H19('int double_val(int x){return x*2;}'),_H19('apply_n(1,10,double_val) = 1024')],
 testCases:[
  {input:'1 10',output:'1024',hidden:false},
  {input:'3 3',output:'24',hidden:false},
  {input:'5 0',output:'5',hidden:true}
 ],
 initialCode:_T19('int double_val(int x){return x*2;}\nint apply_n(int x,int n,int(*f)(int)){\n    for(int i=0;i<n;i++) x=f(x);\n    return x;\n}\nint main(){\n    int x,n; scanf("%d%d",&x,&n);\n    printf("%d\\n",apply_n(x,n,double_val));\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'Таблица виртуальных методов',
 description:'Реализуйте полиморфизм в C через таблицу функций (vtable). Создайте тип Shape с полем area (указатель на функцию). Реализуйте Circle и Rectangle с разными функциями area.',
 hints:[_H19('typedef struct{double(*area)(void*);} VTable;'),_H19('typedef struct{VTable*vt; double r;} Circle;'),_H19('shape->vt->area(shape) — вызов виртуального метода')],
 testCases:[
  {input:'circle 5',output:'78.54',hidden:false},
  {input:'rect 4 3',output:'12.00',hidden:false}
 ],
 initialCode:_T19('#include <string.h>\n#define PI 3.14159\ntypedef struct{double(*area)(void*);}VTable;\ntypedef struct{VTable*vt;double r;}Circle;\ntypedef struct{VTable*vt;double w,h;}Rect;\ndouble circle_area(void*s){Circle*c=(Circle*)s;return PI*c->r*c->r;}\ndouble rect_area(void*s){Rect*r=(Rect*)s;return r->w*r->h;}\nVTable circle_vt={circle_area};\nVTable rect_vt={rect_area};\nint main(){\n    char type[10]; scanf("%s",type);\n    if(!strcmp(type,"circle")){\n        Circle c; c.vt=&circle_vt; scanf("%lf",&c.r);\n        printf("%.2f\\n",c.vt->area(&c));\n    } else {\n        Rect r; r.vt=&rect_vt; scanf("%lf%lf",&r.w,&r.h);\n        printf("%.2f\\n",r.vt->area(&r));\n    }\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Цепочка преобразований (compose)',
 description:'Напишите функцию <code>compose(f,g)</code> которая возвращает... Нет, C не поддерживает замыкания. Реализуйте <code>pipeline(x, fns[], n)</code> — последовательное применение n функций.',
 hints:[_H19('int pipeline(int x,int(**fns)(int),int n){for(int i=0;i<n;i++) x=fns[i](x); return x;}'),_H19('int(*fns[])(int)={double_val,add1,square} — массив функций'),_H19('Применяет функции слева направо')],
 testCases:[
  {input:'3',output:'49',hidden:false},
  {input:'1',output:'4',hidden:false}
 ],
 initialCode:_T19('int double_v(int x){return x*2;}\nint add1(int x){return x+1;}\nint sq(int x){return x*x;}\nint pipeline(int x,int(**fns)(int),int n){\n    for(int i=0;i<n;i++) x=fns[i](x);\n    return x;\n}\nint main(){\n    int x; scanf("%d",&x);\n    int(*fns[])(int)={double_v,add1,sq}; // double, +1, square\n    printf("%d\\n",pipeline(x,fns,3));\n    return 0;\n}')
},
{
 id:15,difficulty:'супер',title:'Событийная система',
 description:'Реализуйте простую событийную систему: подпишите N обработчиков на событие "tick". Каждый обработчик принимает int (номер тика). При вызове <code>emit(n)</code> вызовите всех подписчиков.',
 hints:[_H19('void(*handlers[10])(int); int handler_count=0;'),_H19('void subscribe(void(*h)(int)){handlers[handler_count++]=h;}'),_H19('void emit(int tick){for(int i=0;i<handler_count;i++) handlers[i](tick);}')],
 testCases:[
  {input:'3',output:'A got tick 1\nB got tick 1\nA got tick 2\nB got tick 2\nA got tick 3\nB got tick 3',hidden:false}
 ],
 initialCode:_T19('void(*handlers[10])(int);\nint hcnt=0;\nvoid subscribe(void(*h)(int)){handlers[hcnt++]=h;}\nvoid emit(int tick){for(int i=0;i<hcnt;i++) handlers[i](tick);}\nvoid handler_a(int t){printf("A got tick %d\\n",t);}\nvoid handler_b(int t){printf("B got tick %d\\n",t);}\nint main(){\n    int n; scanf("%d",&n);\n    subscribe(handler_a);\n    subscribe(handler_b);\n    for(int i=1;i<=n;i++) emit(i);\n    return 0;\n}')
}
];
