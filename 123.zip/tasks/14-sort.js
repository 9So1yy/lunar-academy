window.TASKS=window.TASKS||{};
const _T14=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H14=(t)=>({text:t,penalty:5});

window.TASKS[14]=[
{
 id:1,difficulty:'легко',title:'Пузырьковая сортировка',
 description:'Считайте N целых чисел и отсортируйте их по возрастанию пузырьковой сортировкой. Выведите результат.',
 hints:[_H14('Два вложенных цикла: внешний N-1 раз, внутренний N-1-i раз'),_H14('Если a[j]>a[j+1] — меняем местами через tmp'),_H14('После каждого прохода наибольший элемент «всплывает» вправо')],
 testCases:[
  {input:'5\n3 1 4 1 5',output:'1 1 3 4 5',hidden:false},
  {input:'4\n4 3 2 1',output:'1 2 3 4',hidden:false},
  {input:'6\n10 2 8 4 6 0',output:'0 2 4 6 8 10',hidden:true},
  {input:'1\n7',output:'7',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // пузырьковая сортировка\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Сортировка выбором',
 description:'Реализуйте сортировку выбором: на каждом шаге находите минимум в неотсортированной части и меняйте с первым элементом этой части.',
 hints:[_H14('Внешний цикл i от 0 до n-2: ищем min_idx в a[i..n-1]'),_H14('Найдя минимум — меняем a[i] и a[min_idx]'),_H14('Алгоритм делает ровно n-1 обмен, не более')],
 testCases:[
  {input:'5\n64 25 12 22 11',output:'11 12 22 25 64',hidden:false},
  {input:'4\n5 1 3 2',output:'1 2 3 5',hidden:false},
  {input:'6\n9 8 7 6 5 4',output:'4 5 6 7 8 9',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // сортировка выбором\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Сортировка вставками',
 description:'Реализуйте сортировку вставками: каждый элемент вставляется в нужную позицию уже отсортированной части.',
 hints:[_H14('Внешний цикл i от 1 до n-1: key=a[i]'),_H14('Сдвигаем элементы вправо пока a[j]>key: a[j+1]=a[j]; j--'),_H14('Вставляем: a[j+1]=key')],
 testCases:[
  {input:'5\n5 2 4 6 1',output:'1 2 4 5 6',hidden:false},
  {input:'4\n3 4 2 1',output:'1 2 3 4',hidden:false},
  {input:'5\n1 2 3 4 5',output:'1 2 3 4 5',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // сортировка вставками\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Подсчёт обменов пузырьковой сортировки',
 description:'Считайте N чисел. Выведите количество обменов, которые совершит пузырьковая сортировка.',
 hints:[_H14('Добавьте счётчик swaps=0, увеличивайте при каждом обмене'),_H14('Структура та же что и обычный bubble sort'),_H14('printf("%d\\n", swaps);')],
 testCases:[
  {input:'4\n4 3 2 1',output:'6',hidden:false},
  {input:'4\n1 2 3 4',output:'0',hidden:false},
  {input:'3\n3 1 2',output:'2',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // пузырьковая сортировка со счётчиком обменов\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Сортировка строк',
 description:'Считайте N строк и выведите их в лексикографическом порядке. Используйте любой алгоритм сортировки и <code>strcmp</code> для сравнения.',
 hints:[_H14('char a[20][51] — массив строк'),_H14('Для обмена строк: char tmp[51]; strcpy(tmp,a[i]); strcpy(a[i],a[j]); strcpy(a[j],tmp);'),_H14('#include <string.h> для strcmp и strcpy')],
 testCases:[
  {input:'3\nbanana\napple\ncherry',output:'apple\nbanana\ncherry',hidden:false},
  {input:'4\ndog\ncat\nbird\nant',output:'ant\nbird\ncat\ndog',hidden:false},
  {input:'2\nzebra\naardvark',output:'aardvark\nzebra',hidden:true}
 ],
 initialCode:_T14('#include <string.h>\nint main(){\n    int n; char a[20][51];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%s",a[i]);\n    // сортировка строк\n    for(int i=0;i<n;i++) puts(a[i]);\n    return 0;\n}')
},
{
 id:6,difficulty:'средне',title:'Сортировка по убыванию',
 description:'Считайте N чисел и отсортируйте по убыванию. Используйте <code>qsort</code> из <code>&lt;stdlib.h&gt;</code> с компаратором по убыванию.',
 hints:[_H14('qsort(arr, n, sizeof(int), cmp) — стандартная сортировка'),_H14('Компаратор для убывания: int cmp(const void*a,const void*b){return *(int*)b-*(int*)a;}'),_H14('Функция сравнения возвращает отрицательное/0/положительное')],
 testCases:[
  {input:'5\n3 1 4 1 5',output:'5 4 3 1 1',hidden:false},
  {input:'4\n1 2 3 4',output:'4 3 2 1',hidden:false},
  {input:'3\n7 7 7',output:'7 7 7',hidden:true}
 ],
 initialCode:_T14('#include <stdlib.h>\nint cmp(const void *a, const void *b){\n    // компаратор по убыванию\n    return 0;\n}\nint main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    qsort(a, n, sizeof(int), cmp);\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'Сортировка структур',
 description:'Считайте N студентов (имя + оценка) и выведите их, отсортировав по оценке по убыванию. При равной оценке — по имени по возрастанию.',
 hints:[_H14('struct Student { char name[51]; int score; };'),_H14('qsort с компаратором: сначала сравните score (по убыванию), при равенстве — strcmp(name)'),_H14('Компаратор: if(b.score!=a.score) return b.score-a.score; return strcmp(a.name,b.name);')],
 testCases:[
  {input:'3\nAlice 90\nBob 85\nCarol 90',output:'Alice 90\nCarol 90\nBob 85',hidden:false},
  {input:'2\nAnn 75\nMax 80',output:'Max 80\nAnn 75',hidden:false},
  {input:'3\nC 70\nA 70\nB 70',output:'A 70\nB 70\nC 70',hidden:true}
 ],
 initialCode:_T14('#include <string.h>\n#include <stdlib.h>\ntypedef struct{char name[51];int score;}Student;\nint cmp(const void*a,const void*b){\n    Student*x=(Student*)a; Student*y=(Student*)b;\n    // сначала по score убыванию, затем по name возрастанию\n    return 0;\n}\nint main(){\n    int n; Student s[50];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%s%d",s[i].name,&s[i].score);\n    qsort(s,n,sizeof(Student),cmp);\n    for(int i=0;i<n;i++) printf("%s %d\\n",s[i].name,s[i].score);\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'Сортировка слиянием (merge sort)',
 description:'Реализуйте рекурсивную сортировку слиянием. Разделите массив на две половины, отсортируйте каждую, затем слейте в отсортированный результат.',
 hints:[_H14('Базовый случай: если n<=1 — возврат'),_H14('merge(a, left, mid, right): слийте a[left..mid] и a[mid+1..right]'),_H14('Используйте вспомогательный массив tmp для слияния')],
 testCases:[
  {input:'6\n38 27 43 3 9 82',output:'3 9 27 38 43 82',hidden:false},
  {input:'4\n4 3 2 1',output:'1 2 3 4',hidden:false},
  {input:'7\n5 2 8 1 9 3 7',output:'1 2 3 5 7 8 9',hidden:true}
 ],
 initialCode:_T14('void merge(int*a,int l,int m,int r){\n    int tmp[100], i=l,j=m+1,k=0;\n    while(i<=m&&j<=r) tmp[k++]=(a[i]<=a[j])?a[i++]:a[j++];\n    while(i<=m) tmp[k++]=a[i++];\n    while(j<=r) tmp[k++]=a[j++];\n    for(int x=0;x<k;x++) a[l+x]=tmp[x];\n}\nvoid mergeSort(int*a,int l,int r){\n    // реализуйте рекурсию\n}\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    mergeSort(a,0,n-1);\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'Быстрая сортировка (quicksort)',
 description:'Реализуйте быструю сортировку. Используйте схему разделения Lomuto: опорный элемент — последний, переставляйте элементы меньше опорного влево.',
 hints:[_H14('int partition(a, l, r): pivot=a[r], i=l-1; проходите j от l до r-1'),_H14('Если a[j]<=pivot — i++; swap(a[i],a[j])'),_H14('В конце swap(a[i+1],a[r]); return i+1;')],
 testCases:[
  {input:'6\n10 7 8 9 1 5',output:'1 5 7 8 9 10',hidden:false},
  {input:'5\n3 3 3 3 3',output:'3 3 3 3 3',hidden:false},
  {input:'7\n5 2 8 1 9 3 7',output:'1 2 3 5 7 8 9',hidden:true}
 ],
 initialCode:_T14('void swap(int*a,int*b){int t=*a;*a=*b;*b=t;}\nint partition(int*a,int l,int r){\n    int pivot=a[r], i=l-1;\n    // реализуйте partition\n    return 0;\n}\nvoid quickSort(int*a,int l,int r){\n    if(l<r){\n        int p=partition(a,l,r);\n        quickSort(a,l,p-1);\n        quickSort(a,p+1,r);\n    }\n}\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    quickSort(a,0,n-1);\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'Сортировка подсчётом',
 description:'Считайте N чисел в диапазоне [0, 100]. Отсортируйте сортировкой подсчётом (counting sort) — без сравнений, за O(N+K).',
 hints:[_H14('Создайте массив count[101]={0}'),_H14('Для каждого a[i] увеличивайте count[a[i]]++'),_H14('Выведите каждое число i ровно count[i] раз')],
 testCases:[
  {input:'6\n4 2 2 8 3 3',output:'2 2 3 3 4 8',hidden:false},
  {input:'5\n0 100 50 25 75',output:'0 25 50 75 100',hidden:false},
  {input:'4\n5 5 5 5',output:'5 5 5 5',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n, a[1000], count[101]={0};\n    scanf("%d",&n);\n    for(int i=0;i<n;i++){scanf("%d",&a[i]); count[a[i]]++;}\n    // выведите элементы в отсортированном порядке\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Слияние двух отсортированных массивов',
 description:'Даны два отсортированных массива длиной N и M. Слейте их в один отсортированный массив и выведите.',
 hints:[_H14('Два указателя: i=0 для a, j=0 для b'),_H14('На каждом шаге берём меньший из a[i] и b[j]'),_H14('После окончания одного — дописываем остаток другого')],
 testCases:[
  {input:'3\n1 3 5\n3\n2 4 6',output:'1 2 3 4 5 6',hidden:false},
  {input:'2\n1 2\n3\n3 4 5',output:'1 2 3 4 5',hidden:false},
  {input:'4\n1 3 5 7\n4\n2 4 6 8',output:'1 2 3 4 5 6 7 8',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n,m,a[100],b[100],res[200];\n    scanf("%d",&n); for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&m); for(int i=0;i<m;i++) scanf("%d",&b[i]);\n    // слейте два массива\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'Проверка сортировки',
 description:'Считайте N чисел. Выведите <code>SORTED ASC</code> если отсортированы по возрастанию, <code>SORTED DESC</code> если по убыванию, иначе <code>NOT SORTED</code>.',
 hints:[_H14('Проверяйте asc: все a[i]<=a[i+1]; desc: все a[i]>=a[i+1]'),_H14('Если равны — подходят и для asc и для desc'),_H14('Выводите в порядке приоритета: ASC → DESC → NOT SORTED')],
 testCases:[
  {input:'4\n1 2 3 4',output:'SORTED ASC',hidden:false},
  {input:'4\n4 3 2 1',output:'SORTED DESC',hidden:false},
  {input:'3\n1 3 2',output:'NOT SORTED',hidden:true},
  {input:'3\n5 5 5',output:'SORTED ASC',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // определите порядок сортировки массива\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'Сортировка оболочкой (Shell sort)',
 description:'Реализуйте сортировку Шелла. Используйте последовательность промежутков: N/2, N/4, ..., 1. На каждом шаге делайте сортировку вставками с текущим промежутком.',
 hints:[_H14('Внешний цикл: gap=n/2; gap>0; gap/=2'),_H14('Для каждого gap делаем сортировку вставками: for(i=gap;i<n;i++){tmp=a[i]; j=i; while(j>=gap&&a[j-gap]>tmp){a[j]=a[j-gap];j-=gap;} a[j]=tmp;}'),_H14('Shell sort быстрее insertion sort на больших массивах')],
 testCases:[
  {input:'8\n35 33 42 10 14 19 27 44',output:'10 14 19 27 33 35 42 44',hidden:false},
  {input:'5\n5 4 3 2 1',output:'1 2 3 4 5',hidden:false},
  {input:'6\n6 5 4 3 2 1',output:'1 2 3 4 5 6',hidden:true}
 ],
 initialCode:_T14('int main(){\n    int n, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    // сортировка Шелла\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Подсчёт инверсий',
 description:'Дан массив из N чисел. Подсчитайте количество инверсий — пар (i,j), где i<j и a[i]>a[j]. Используйте модифицированный merge sort для O(N log N).',
 hints:[_H14('Во время слияния: когда берём элемент из правой половины (a[j]), добавляем (mid-i+1) инверсий'),_H14('Это все элементы в левой половине, которые больше a[j]'),_H14('long long для счётчика — может переполниться int')],
 testCases:[
  {input:'5\n2 4 1 3 5',output:'3',hidden:false},
  {input:'4\n4 3 2 1',output:'6',hidden:false},
  {input:'4\n1 2 3 4',output:'0',hidden:true}
 ],
 initialCode:_T14('long long cnt=0;\nvoid merge(int*a,int l,int m,int r){\n    int tmp[100],i=l,j=m+1,k=0;\n    while(i<=m&&j<=r){\n        if(a[i]<=a[j]) tmp[k++]=a[i++];\n        else{cnt+=m-i+1; tmp[k++]=a[j++];}\n    }\n    while(i<=m) tmp[k++]=a[i++];\n    while(j<=r) tmp[k++]=a[j++];\n    for(int x=0;x<k;x++) a[l+x]=tmp[x];\n}\nvoid ms(int*a,int l,int r){if(l<r){int m=(l+r)/2;ms(a,l,m);ms(a,m+1,r);merge(a,l,m,r);}}\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    ms(a,0,n-1);\n    printf("%lld\\n",cnt);\n    return 0;\n}')
},
{
 id:15,difficulty:'супер',title:'Сортировка за O(N) — Radix Sort',
 description:'Реализуйте поразрядную сортировку (LSD Radix Sort) для неотрицательных чисел до 999. Сортируйте по разрядам: единицы → десятки → сотни.',
 hints:[_H14('Для каждого разряда: считайте в корзины count[0..9], вычисляйте prefix sum, заполняйте output'),_H14('Цифра i-го разряда: (a[j]/exp)%10, где exp = 1, 10, 100'),_H14('После каждого прохода копируйте output обратно в a')],
 testCases:[
  {input:'6\n170 45 75 90 802 24',output:'24 45 75 90 170 802',hidden:false},
  {input:'5\n5 4 3 2 1',output:'1 2 3 4 5',hidden:false},
  {input:'4\n999 100 1 50',output:'1 50 100 999',hidden:true}
 ],
 initialCode:_T14('void countSort(int*a,int n,int exp){\n    int output[100], count[10]={0};\n    for(int i=0;i<n;i++) count[(a[i]/exp)%10]++;\n    for(int i=1;i<10;i++) count[i]+=count[i-1];\n    for(int i=n-1;i>=0;i--){output[--count[(a[i]/exp)%10]]=a[i];}\n    for(int i=0;i<n;i++) a[i]=output[i];\n}\nvoid radixSort(int*a,int n){\n    // найдите max и вызовите countSort для каждого разряда\n}\nint main(){\n    int n,a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    radixSort(a,n);\n    for(int i=0;i<n;i++) printf("%d%c",a[i]," \\n"[i==n-1]);\n    return 0;\n}')
},
{
 id:16,difficulty:'супер',title:'Стабильная сортировка с ключом',
 description:'Считайте N пар (ключ, значение). Отсортируйте по ключу по возрастанию. Если ключи одинаковы — сохраните исходный порядок (стабильная сортировка). Выведите пары.',
 hints:[_H14('Добавьте в структуру поле idx — исходный индекс'),_H14('Компаратор: если keys равны — сортировать по idx'),_H14('qsort — нестабильна сама по себе, но с полем idx можно эмулировать стабильность')],
 testCases:[
  {input:'4\n3 a\n1 b\n2 c\n1 d',output:'1 b\n1 d\n2 c\n3 a',hidden:false},
  {input:'3\n2 x\n2 y\n2 z',output:'2 x\n2 y\n2 z',hidden:false},
  {input:'5\n5 e\n3 c\n5 f\n3 d\n1 a',output:'1 a\n3 c\n3 d\n5 e\n5 f',hidden:true}
 ],
 initialCode:_T14('#include <stdlib.h>\ntypedef struct{int key;char val[51];int idx;}Pair;\nint cmp(const void*a,const void*b){\n    Pair*x=(Pair*)a; Pair*y=(Pair*)b;\n    if(x->key!=y->key) return x->key-y->key;\n    return x->idx-y->idx;\n}\nint main(){\n    int n; Pair p[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++){scanf("%d%s",&p[i].key,p[i].val); p[i].idx=i;}\n    qsort(p,n,sizeof(Pair),cmp);\n    for(int i=0;i<n;i++) printf("%d %s\\n",p[i].key,p[i].val);\n    return 0;\n}')
}
];
