window.TASKS=window.TASKS||{};
const _T7=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H7=(t)=>({text:t,penalty:5});

window.TASKS[7]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'Глобальный счётчик',
 description:'Объявите глобальную переменную <code>int count = 0</code>. В main увеличьте её 5 раз и выведите.',
 hints:[_H7('int count = 0; — вне всех функций'),_H7('for(int i=0;i<5;i++) count++;'),_H7('printf("%d", count);')],
 testCases:[{input:'',output:'5',hidden:false}],
 initialCode:_T7('int count = 0;\n\nint main(void) {\n    // увеличить count 5 раз\n    printf("%d", count);\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Считать в глобальную',
 description:'Объявите глобальный <code>int g</code>. Считайте число в main и сохраните в g. Выведите g.',
 hints:[_H7('int g; — вне main'),_H7('scanf("%d", &g);'),_H7('printf("%d", g);')],
 testCases:[
  {input:'42',output:'42',hidden:false},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T7('int g;\n\nint main(void) {\n    scanf("%d", &g);\n    // вывести g\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Сумма через глобальные',
 description:'Объявите глобальные <code>int ga, gb</code>. Считайте два числа в main. Вычислите и выведите их сумму.',
 hints:[_H7('int ga, gb; — вне main'),_H7('scanf("%d %d", &ga, &gb);'),_H7('printf("%d", ga + gb);')],
 testCases:[
  {input:'3 7',output:'10',hidden:false},
  {input:'100 200',output:'300',hidden:true}
 ],
 initialCode:_T7('int ga, gb;\n\nint main(void) {\n    scanf("%d %d", &ga, &gb);\n    // вывести сумму\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Блочная область видимости',
 description:'Объявите <code>int x = 1</code> в main. В блоке <code>{ }</code> объявите новый <code>int x = 2</code> и выведите. После блока выведите внешний <code>x</code>. Числа через пробел.',
 hints:[_H7('int x = 1; // внешний'),_H7('{ int x = 2; printf... } // внутренний'),_H7('printf("%d", x); // снова внешний')],
 testCases:[{input:'',output:'2 1',hidden:false}],
 initialCode:_T7('int main(void) {\n    int x = 1;\n    {\n        int x = 2;\n        // вывести x\n    }\n    // вывести x\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'const переменная',
 description:'Объявите <code>const int MAX = 100</code>. Считайте число <code>n</code>. Выведите <code>1</code> если n ≤ MAX, иначе <code>0</code>.',
 hints:[_H7('const int MAX = 100;'),_H7('printf("%d", n <= MAX ? 1 : 0);')],
 testCases:[
  {input:'50',output:'1',hidden:false},
  {input:'100',output:'1',hidden:true},
  {input:'101',output:'0',hidden:true}
 ],
 initialCode:_T7('int main(void) {\n    const int MAX = 100;\n    int n;\n    scanf("%d", &n);\n    // сравни n с MAX\n    return 0;\n}')
},
{
 id:6,difficulty:'легко',title:'Несколько блоков',
 description:'В main создайте два отдельных блока. В первом объявите <code>int a = 10</code> и выведите. Во втором <code>int a = 20</code> и выведите. Числа через пробел.',
 hints:[_H7('{ int a = 10; printf("%d ", a); } { int a = 20; printf("%d", a); }'),_H7('Переменная a видна только внутри своего блока')],
 testCases:[{input:'',output:'10 20',hidden:false}],
 initialCode:_T7('int main(void) {\n    { // блок 1\n        int a = 10;\n        // вывести a\n    }\n    { // блок 2\n        int a = 20;\n        // вывести a\n    }\n    return 0;\n}')
},
{
 id:7,difficulty:'легко',title:'Глобальная функция-геттер',
 description:'Объявите глобальный <code>int value</code>. Напишите функцию <code>int get_value(void)</code>, возвращающую value. Считайте число, сохраните в value, выведите через get_value().',
 hints:[_H7('int value;'),_H7('int get_value(void) { return value; }'),_H7('value = ...; printf("%d", get_value());')],
 testCases:[
  {input:'55',output:'55',hidden:false},
  {input:'-7',output:'-7',hidden:true}
 ],
 initialCode:_T7('int value;\n\nint get_value(void) {\n    // вернуть value\n}\n\nint main(void) {\n    scanf("%d", &value);\n    printf("%d", get_value());\n    return 0;\n}')
},
{
 id:8,difficulty:'легко',title:'Глобальный множитель',
 description:'Объявите глобальный <code>int factor = 3</code>. Считайте число <code>n</code>. Вычислите и выведите <code>n * factor</code>.',
 hints:[_H7('int factor = 3; // глобально'),_H7('printf("%d", n * factor);')],
 testCases:[
  {input:'5',output:'15',hidden:false},
  {input:'10',output:'30',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T7('int factor = 3;\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // вывести n * factor\n    return 0;\n}')
},
{
 id:9,difficulty:'легко',title:'Переменная для функции',
 description:'Напишите функцию <code>void set_and_print(int x)</code>, которая: создаёт локальный <code>int local = x * 2</code> и выводит local. Считайте число и вызовите функцию.',
 hints:[_H7('void set_and_print(int x) { int local = x * 2; printf("%d", local); }')],
 testCases:[
  {input:'5',output:'10',hidden:false},
  {input:'7',output:'14',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T7('void set_and_print(int x) {\n    // создать local = x * 2 и вывести\n}\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    set_and_print(n);\n    return 0;\n}')
},
{
 id:10,difficulty:'легко',title:'Изменение глобальной из функции',
 description:'Объявите глобальный <code>int total = 0</code>. Напишите <code>void add(int x)</code>, прибавляющую x к total. Считайте 3 числа, вызовите add 3 раза, выведите total.',
 hints:[_H7('int total = 0;'),_H7('void add(int x) { total += x; }'),_H7('add(a); add(b); add(c); printf("%d", total);')],
 testCases:[
  {input:'1 2 3',output:'6',hidden:false},
  {input:'10 20 30',output:'60',hidden:true},
  {input:'0 0 5',output:'5',hidden:true}
 ],
 initialCode:_T7('int total = 0;\n\nvoid add(int x) {\n    // добавить x к total\n}\n\nint main(void) {\n    int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    add(a); add(b); add(c);\n    printf("%d", total);\n    return 0;\n}')
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'static — счётчик вызовов',
 description:'Напишите <code>int nextId(void)</code> со <code>static</code> счётчиком, возвращающую 1, 2, 3... Вызовите 3 раза и выведите через пробел.',
 hints:[_H7('static int id = 0; — инициализируется один раз'),_H7('return ++id;'),_H7('printf("%d %d %d", nextId(), nextId(), nextId());')],
 testCases:[{input:'',output:'1 2 3',hidden:false}],
 initialCode:_T7('int nextId(void) {\n    // static счётчик\n}\n\nint main(void) {\n    printf("%d %d %d", nextId(), nextId(), nextId());\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'static накопитель',
 description:'Напишите <code>int accumulate(int x)</code> — добавляет x к static сумме и возвращает текущую сумму. Считайте 4 числа, вызовите accumulate для каждого, выведите последний результат.',
 hints:[_H7('static int sum = 0;'),_H7('sum += x; return sum;')],
 testCases:[
  {input:'1 2 3 4',output:'10',hidden:false},
  {input:'10 5 3 2',output:'20',hidden:true},
  {input:'0 0 0 5',output:'5',hidden:true}
 ],
 initialCode:_T7('int accumulate(int x) {\n    static int sum = 0;\n    // добавить x и вернуть sum\n}\n\nint main(void) {\n    int a, b, c, d;\n    scanf("%d %d %d %d", &a, &b, &c, &d);\n    accumulate(a); accumulate(b); accumulate(c);\n    printf("%d", accumulate(d));\n    return 0;\n}')
},
{
 id:13,difficulty:'средне',title:'Две функции — один глобальный',
 description:'Глобальный <code>int state = 0</code>. Функция <code>set(int x)</code> присваивает state=x. Функция <code>get(void)</code> возвращает state*2. Считайте число, вызовите set, выведите get().',
 hints:[_H7('void set(int x) { state = x; }'),_H7('int get(void) { return state * 2; }')],
 testCases:[
  {input:'5',output:'10',hidden:false},
  {input:'7',output:'14',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T7('int state = 0;\n\nvoid set(int x) { /* state = x */ }\nint get(void) { /* return state*2 */ }\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    set(n);\n    printf("%d", get());\n    return 0;\n}')
},
{
 id:14,difficulty:'средне',title:'Вложенные блоки',
 description:'Объявите <code>int x = 0</code> в main. В первом блоке <code>x = 10</code>. Во вложенном блоке <code>x = 20</code>. После выхода из обоих блоков выведите x.',
 hints:[_H7('Нет нового объявления x — меняем существующий'),_H7('{ x = 10; { x = 20; } } — после: x == 20'),_H7('printf("%d", x);')],
 testCases:[{input:'',output:'20',hidden:false}],
 initialCode:_T7('int main(void) {\n    int x = 0;\n    {\n        x = 10;\n        {\n            x = 20;\n        }\n    }\n    // вывести x\n    return 0;\n}')
},
{
 id:15,difficulty:'средне',title:'Параметр vs глобальная',
 description:'Глобальный <code>int g = 100</code>. Функция <code>int compute(int g)</code> возвращает g + 1 (локальный параметр g). В main: вызвать compute(5), вывести результат и отдельно глобальный g через пробел.',
 hints:[_H7('Параметр g "затеняет" глобальный g внутри функции'),_H7('printf("%d %d", compute(5), g);')],
 testCases:[{input:'',output:'6 100',hidden:false}],
 initialCode:_T7('int g = 100;\n\nint compute(int g) {\n    return g + 1; // какой g используется?\n}\n\nint main(void) {\n    printf("%d %d", compute(5), g);\n    return 0;\n}')
},
{
 id:16,difficulty:'средне',title:'static сохраняет состояние',
 description:'Функция <code>int counter(void)</code> со static int c=0: при каждом вызове c++. Если c == 3 — сброс c=0 и return -1, иначе return c. Считайте n (1–7), вызовите counter() n раз, выведите результат каждого через пробел.',
 hints:[_H7('static int c = 0;'),_H7('c++; if (c == 3) { c = 0; return -1; } return c;')],
 testCases:[
  {input:'5',output:'1 2 -1 1 2',hidden:false},
  {input:'3',output:'1 2 -1',hidden:true}
 ],
 initialCode:_T7('int counter(void) {\n    static int c = 0;\n    // ваш код\n}\n\nint main(void) {\n    int n, i;\n    scanf("%d", &n);\n    for (i = 0; i < n; i++) {\n        if (i > 0) printf(" ");\n        printf("%d", counter());\n    }\n    return 0;\n}')
},
{
 id:17,difficulty:'средне',title:'Затенение переменных',
 description:'Объявите <code>int x = 10</code>. В блоке создайте локальную <code>int x = 20</code>. Выведите внутренний x и внешний x (через пробел).',
 hints:[_H7('{ int x = 20; printf("%d ", x); }'),_H7('printf("%d", x); // внешний')],
 testCases:[{input:'',output:'20 10',hidden:false}],
 initialCode:_T7('int main(void) {\n    int x = 10;\n    {\n        int x = 20;\n        // вывести x (внутренний)\n    }\n    // вывести x (внешний)\n    return 0;\n}')
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'static в рекурсии',
 description:'Напишите рекурсивную функцию <code>void countdown(int n)</code> со static int calls. Считает вызовы. По завершении (n==0) выводит количество вызовов.',
 hints:[_H7('static int calls = 0; calls++;'),_H7('if (n == 0) { printf("%d", calls); return; }'),_H7('countdown(n - 1);')],
 testCases:[
  {input:'5',output:'6',hidden:false},
  {input:'0',output:'1',hidden:true},
  {input:'3',output:'4',hidden:true}
 ],
 initialCode:_T7('void countdown(int n) {\n    static int calls = 0;\n    calls++;\n    if (n == 0) {\n        printf("%d", calls);\n        return;\n    }\n    countdown(n - 1);\n}\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    countdown(n);\n    return 0;\n}')
},
{
 id:19,difficulty:'сложно',title:'Глобальная история максимума',
 description:'Глобальный <code>int g_max = -1</code>. Функция <code>void update(int x)</code> обновляет g_max если x > g_max. Считайте n (≤10), потом n чисел, вызовите update для каждого, выведите g_max.',
 hints:[_H7('void update(int x) { if (x > g_max) g_max = x; }'),_H7('В main: цикл с scanf и update')],
 testCases:[
  {input:'4 3 7 2 9',output:'9',hidden:false},
  {input:'3 5 1 5',output:'5',hidden:true},
  {input:'1 -3',output:'-1',hidden:true}
 ],
 initialCode:_T7('int g_max = -1;\n\nvoid update(int x) {\n    // обновить g_max\n}\n\nint main(void) {\n    int n, i, x;\n    scanf("%d", &n);\n    for (i = 0; i < n; i++) {\n        scanf("%d", &x);\n        update(x);\n    }\n    printf("%d", g_max);\n    return 0;\n}')
},
{
 id:20,difficulty:'сложно',title:'Уникальные вызовы через static set',
 description:'Функция <code>int seen(int x)</code> со static массивом (флаги 0–9): при первом x — вернуть 1, при повторном — 0. Считайте 5 чисел (0–9), выведите результат seen() для каждого через пробел.',
 hints:[_H7('static int flags[10] = {0};'),_H7('if (flags[x]) return 0; flags[x]=1; return 1;')],
 testCases:[
  {input:'1 2 1 3 2',output:'1 1 0 1 0',hidden:false},
  {input:'0 0 0 0 0',output:'1 0 0 0 0',hidden:true}
 ],
 initialCode:_T7('int seen(int x) {\n    static int flags[10] = {0};\n    // ваш код\n}\n\nint main(void) {\n    int i, x;\n    for (i = 0; i < 5; i++) {\n        scanf("%d", &x);\n        if (i > 0) printf(" ");\n        printf("%d", seen(x));\n    }\n    return 0;\n}')
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'Цепочка глобальных',
 description:'Глобальные <code>int a=1, b=1</code>. Функция <code>next()</code>: a=b, b=a+b (как Фибоначчи). Вызовите next() n раз и выведите b.',
 hints:[_H7('void next() { int t = a; a = b; b = t + b; }'),_H7('printf("%d", b);')],
 testCases:[
  {input:'5',output:'13',hidden:false},
  {input:'1',output:'2',hidden:true},
  {input:'8',output:'55',hidden:true}
 ],
 initialCode:_T7('int a = 1, b = 1;\n\nvoid next(void) {\n    // шаг Фибоначчи\n}\n\nint main(void) {\n    int n, i;\n    scanf("%d", &n);\n    for (i = 0; i < n; i++) next();\n    printf("%d", b);\n    return 0;\n}')
},
{
 id:24,difficulty:'супер',title:'Мемоизация через static',
 description:'Функция <code>int memo_fib(int n)</code> вычисляет fib(n) с кешированием в static массиве. Считайте n (≤20), выведите fib(n). fib(1)=fib(2)=1.',
 hints:[_H7('static int cache[21] = {0};'),_H7('if (cache[n]) return cache[n];'),_H7('return cache[n] = memo_fib(n-1) + memo_fib(n-2);')],
 testCases:[
  {input:'10',output:'55',hidden:false},
  {input:'1',output:'1',hidden:true},
  {input:'15',output:'610',hidden:true}
 ],
 initialCode:_T7('int memo_fib(int n) {\n    static int cache[21] = {0};\n    if (n <= 2) return 1;\n    // проверь cache[n], вычисли и сохрани\n}\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    printf("%d", memo_fib(n));\n    return 0;\n}')
}
];
