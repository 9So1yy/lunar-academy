window.TASKS=window.TASKS||{};
const _T16=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H16=(t)=>({text:t,penalty:5});

window.TASKS[16]=[
{
 id:1,difficulty:'легко',title:'Запись числа в файл',
 description:'Считайте число из stdin, запишите его в файл <code>out.txt</code> с помощью <code>fprintf</code>, затем откройте файл для чтения и выведите значение.',
 hints:[_H16('FILE *f = fopen("out.txt", "w"); — открыть для записи'),_H16('fprintf(f, "%d\\n", n); fclose(f); — записать и закрыть'),_H16('Снова fopen("out.txt","r"), fscanf(f,"%d",&m), printf')],
 testCases:[
  {input:'42',output:'42',hidden:false},
  {input:'100',output:'100',hidden:false},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T16('int main(){\n    int n;\n    scanf("%d", &n);\n    // запишите n в файл out.txt\n    // затем прочитайте и выведите\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Подсчёт строк в файле',
 description:'Считайте N строк из stdin, запишите их в файл <code>data.txt</code>. Затем откройте файл, посчитайте количество строк и выведите.',
 hints:[_H16('fgets(buf, size, f) — читает строку из файла (включая \\n)'),_H16('Цикл while(fgets(buf,101,f)!=NULL) cnt++;'),_H16('fclose после каждого использования файла')],
 testCases:[
  {input:'3\nhello\nworld\nfoo',output:'3',hidden:false},
  {input:'1\nonly',output:'1',hidden:false},
  {input:'5\na\nb\nc\nd\ne',output:'5',hidden:true}
 ],
 initialCode:_T16('int main(){\n    int n; char buf[101];\n    scanf("%d ",&n);\n    FILE *f=fopen("data.txt","w");\n    for(int i=0;i<n;i++){\n        fgets(buf,101,stdin);\n        fputs(buf,f);\n    }\n    fclose(f);\n    // откройте файл и посчитайте строки\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Копирование файла',
 description:'Считайте N чисел из stdin, запишите в <code>src.txt</code> (по одному на строке). Скопируйте содержимое в <code>dst.txt</code> символ за символом. Выведите содержимое <code>dst.txt</code>.',
 hints:[_H16('int c; while((c=fgetc(src))!=EOF) fputc(c,dst); — побайтовое копирование'),_H16('fgetc читает один символ, возвращает EOF (-1) в конце файла'),_H16('После копирования закройте dst и откройте снова для чтения')],
 testCases:[
  {input:'3\n10\n20\n30',output:'10\n20\n30',hidden:false},
  {input:'2\n5\n7',output:'5\n7',hidden:false}
 ],
 initialCode:_T16('int main(){\n    int n; scanf("%d",&n);\n    FILE *f=fopen("src.txt","w");\n    for(int i=0;i<n;i++){int x;scanf("%d",&x);fprintf(f,"%d\\n",x);}\n    fclose(f);\n    // скопируйте src.txt в dst.txt символ за символом\n    // затем выведите dst.txt\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Проверка существования файла',
 description:'Попробуйте открыть файл <code>maybe.txt</code> на чтение. Если файл не существует — выведите <code>NOT FOUND</code>. Если существует — выведите <code>FOUND</code>. (Файл не создаётся, поэтому всегда NOT FOUND.)',
 hints:[_H16('fopen возвращает NULL если файл не существует (или нет доступа)'),_H16('FILE *f = fopen("maybe.txt","r"); if(f==NULL) puts("NOT FOUND");'),_H16('else { puts("FOUND"); fclose(f); }')],
 testCases:[
  {input:'',output:'NOT FOUND',hidden:false}
 ],
 initialCode:_T16('int main(){\n    // попробуйте открыть "maybe.txt" и проверьте результат\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Сумма чисел из файла',
 description:'Запишите N чисел в файл <code>nums.txt</code>, затем прочитайте их из файла с помощью <code>fscanf</code> и выведите сумму.',
 hints:[_H16('fscanf(f, "%d", &x) — читает число из файла, возвращает 1 при успехе'),_H16('while(fscanf(f,"%d",&x)==1) sum+=x;'),_H16('Не забудьте fclose после записи перед открытием на чтение')],
 testCases:[
  {input:'4\n1 2 3 4',output:'10',hidden:false},
  {input:'5\n10 20 30 40 50',output:'150',hidden:false},
  {input:'3\n-1 0 1',output:'0',hidden:true}
 ],
 initialCode:_T16('int main(){\n    int n, x;\n    scanf("%d",&n);\n    FILE *f=fopen("nums.txt","w");\n    for(int i=0;i<n;i++){scanf("%d",&x);fprintf(f,"%d ",x);}\n    fclose(f);\n    // откройте файл, считайте числа и выведите сумму\n    return 0;\n}')
},
{
 id:6,difficulty:'средне',title:'Дозапись в файл (append)',
 description:'Запишите N чисел в файл <code>log.txt</code> по одному (первый запуск). Потом откройте файл в режиме <b>append</b> и добавьте ещё M чисел. Выведите всё содержимое файла.',
 hints:[_H16('fopen("log.txt","a") — открывает файл для добавления (append)'),_H16('Записанные данные добавляются в конец существующего файла'),_H16('После всех операций откройте на чтение и выведите')],
 testCases:[
  {input:'3\n1 2 3\n2\n4 5',output:'1\n2\n3\n4\n5',hidden:false},
  {input:'2\n10 20\n1\n30',output:'10\n20\n30',hidden:false}
 ],
 initialCode:_T16('int main(){\n    int n,m,x;\n    scanf("%d",&n);\n    FILE *f=fopen("log.txt","w");\n    for(int i=0;i<n;i++){scanf("%d",&x);fprintf(f,"%d\\n",x);}\n    fclose(f);\n    scanf("%d",&m);\n    // откройте в режиме append и добавьте m чисел\n    // затем выведите всё содержимое файла\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'Фильтрация строк из файла',
 description:'Считайте N строк и минимальную длину L. Запишите строки в файл. Затем прочитайте из файла только те строки, длина которых ≥ L, и выведите их.',
 hints:[_H16('fgets читает строку с \\n, используйте strlen и обрезайте \\n если нужно'),_H16('s[strcspn(s,"\\n")]=0; — удаление \\n в конце строки (#include <string.h>)'),_H16('Проверяйте strlen(s)>=L перед выводом')],
 testCases:[
  {input:'4 3\nhi\nhello\nok\nworld',output:'hello\nworld',hidden:false},
  {input:'3 5\nabcde\nab\nabcdef',output:'abcde\nabcdef',hidden:false}
 ],
 initialCode:_T16('#include <string.h>\nint main(){\n    int n,L; char s[101];\n    scanf("%d%d ",&n,&L);\n    FILE *f=fopen("strs.txt","w");\n    for(int i=0;i<n;i++){fgets(s,101,stdin);fputs(s,f);}\n    fclose(f);\n    // прочитайте из файла строки с длиной >= L и выведите\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'Частота слов',
 description:'Считайте N слов, запишите в файл. Прочитайте файл и выведите каждое уникальное слово и его количество вхождений, в порядке первого появления.',
 hints:[_H16('Храните массив слов и счётчики: char words[100][51]; int cnt[100];'),_H16('Для каждого прочитанного слова — ищите в массиве, увеличивайте или добавляйте'),_H16('В конце выведите: printf("%s %d\\n", words[i], cnt[i]);')],
 testCases:[
  {input:'5\napple banana apple cherry banana',output:'apple 2\nbanana 2\ncherry 1',hidden:false},
  {input:'4\na b c a',output:'a 2\nb 1\nc 1',hidden:false}
 ],
 initialCode:_T16('#include <string.h>\nint main(){\n    int n; char w[51];\n    scanf("%d",&n);\n    FILE *f=fopen("words.txt","w");\n    for(int i=0;i<n;i++){scanf("%s",w);fprintf(f,"%s\\n",w);}\n    fclose(f);\n    // прочитайте из файла и подсчитайте частоты слов\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'Максимум в файле',
 description:'Запишите N целых чисел в файл построчно. Найдите и выведите максимальное и его порядковый номер (1-based).',
 hints:[_H16('При чтении через fscanf считайте позицию: int pos=0; while(fscanf(f,"%d",&x)==1){pos++;...}'),_H16('Аналогично поиску максимума в массиве, но читаем из файла'),_H16('Храните max и max_pos')],
 testCases:[
  {input:'5\n3 7 2 9 4',output:'9 4',hidden:false},
  {input:'3\n5 5 5',output:'5 1',hidden:false},
  {input:'1\n42',output:'42 1',hidden:true}
 ],
 initialCode:_T16('int main(){\n    int n,x;\n    scanf("%d",&n);\n    FILE *f=fopen("data.txt","w");\n    for(int i=0;i<n;i++){scanf("%d",&x);fprintf(f,"%d\\n",x);}\n    fclose(f);\n    // прочитайте из файла, найдите максимум и его позицию\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'Структуры в файле',
 description:'Запишите N студентов (имя + оценка) в бинарный файл с помощью <code>fwrite</code>. Прочитайте с помощью <code>fread</code> и выведите только тех, у кого оценка ≥ 90.',
 hints:[_H16('typedef struct{char name[51];int score;}Student;'),_H16('fwrite(&s, sizeof(Student), 1, f) — запись одной структуры'),_H16('fread(&s, sizeof(Student), 1, f) — чтение, возвращает 1 при успехе')],
 testCases:[
  {input:'3\nAlice 95\nBob 85\nCarol 92',output:'Alice 95\nCarol 92',hidden:false},
  {input:'2\nAnn 89\nMax 91',output:'Max 91',hidden:false}
 ],
 initialCode:_T16('typedef struct{char name[51];int score;}Student;\nint main(){\n    int n; Student s;\n    scanf("%d",&n);\n    FILE *f=fopen("students.bin","wb");\n    for(int i=0;i<n;i++){scanf("%s%d",s.name,&s.score);fwrite(&s,sizeof(Student),1,f);}\n    fclose(f);\n    // прочитайте из бинарного файла и выведите score >= 90\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Переход по файлу (fseek)',
 description:'Запишите 5 целых чисел в бинарный файл. С помощью <code>fseek</code> перейдите к 3-му элементу (индекс 2) и выведите его без перечитывания всего файла.',
 hints:[_H16('fseek(f, offset, SEEK_SET) — переход на позицию offset от начала'),_H16('Offset для элемента i: i * sizeof(int)'),_H16('fread(&x, sizeof(int), 1, f) — чтение одного int')],
 testCases:[
  {input:'10 20 30 40 50',output:'30',hidden:false},
  {input:'1 2 3 4 5',output:'3',hidden:false},
  {input:'100 200 300 400 500',output:'300',hidden:true}
 ],
 initialCode:_T16('int main(){\n    int a[5];\n    for(int i=0;i<5;i++) scanf("%d",&a[i]);\n    FILE *f=fopen("ints.bin","wb");\n    fwrite(a,sizeof(int),5,f);\n    fclose(f);\n    f=fopen("ints.bin","rb");\n    // используйте fseek для перехода к 3-му элементу\n    fclose(f);\n    return 0;\n}')
},
{
 id:12,difficulty:'сложно',title:'Сортировка строк из файла',
 description:'Считайте N строк, запишите в файл. Прочитайте обратно, отсортируйте лексикографически и запишите в новый файл. Выведите содержимое нового файла.',
 hints:[_H16('Используйте fgets для чтения строк, обрезайте \\n'),_H16('Сортируйте массив строк через qsort с компаратором strcmp'),_H16('Запишите в "sorted.txt" и выведите')],
 testCases:[
  {input:'4\nbanana\napple\ndate\ncherry',output:'apple\nbanana\ncherry\ndate',hidden:false},
  {input:'3\nzoo\naardvark\nmiddle',output:'aardvark\nmiddle\nzoo',hidden:false}
 ],
 initialCode:_T16('#include <string.h>\n#include <stdlib.h>\nint cmp_str(const void*a,const void*b){return strcmp((char*)a,(char*)b);}\nint main(){\n    int n; char s[101];\n    scanf("%d ",&n);\n    FILE *f=fopen("input.txt","w");\n    for(int i=0;i<n;i++){fgets(s,101,stdin);fputs(s,f);}\n    fclose(f);\n    // прочитайте, отсортируйте, запишите в sorted.txt и выведите\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'CSV-парсер',
 description:'Запишите CSV-данные (N строк вида <code>имя,возраст,оценка</code>) в файл. Прочитайте и выведите только студентов с оценкой > 75 в формате <code>имя: оценка</code>.',
 hints:[_H16('sscanf(line, "%[^,],%d,%d", name, &age, &score) — разбор CSV строки'),_H16('%[^,] — читает всё до запятой'),_H16('Или используйте strtok(line, ",") для токенизации')],
 testCases:[
  {input:'3\nAlice,20,85\nBob,21,70\nCarol,22,90',output:'Alice: 85\nCarol: 90',hidden:false},
  {input:'2\nAnn,19,76\nMax,20,75',output:'Ann: 76',hidden:false}
 ],
 initialCode:_T16('#include <string.h>\nint main(){\n    int n; char line[101];\n    scanf("%d ",&n);\n    FILE *f=fopen("students.csv","w");\n    for(int i=0;i<n;i++){fgets(line,101,stdin);fputs(line,f);}\n    fclose(f);\n    // прочитайте CSV и выведите студентов с оценкой > 75\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Лог-файл с временными метками',
 description:'Эмулируйте запись лога: считайте N событий (одно слово) и запишите в файл <code>app.log</code> с порядковым номером: <code>[1] event</code>. Выведите последние K записей из файла.',
 hints:[_H16('fprintf(f,"[%d] %s\\n", i+1, event); — запись с номером'),_H16('Для вывода последних K строк: прочитайте все в массив, выведите с конца'),_H16('Или используйте fseek/ftell для перемотки')],
 testCases:[
  {input:'5 3\nlogin\nerror\nquery\nlogout\nstart',output:'[3] query\n[4] logout\n[5] start',hidden:false},
  {input:'3 2\nstart\nstop\nerror',output:'[2] stop\n[3] error',hidden:false}
 ],
 initialCode:_T16('#include <string.h>\nint main(){\n    int n,k; char ev[51];\n    scanf("%d%d",&n,&k);\n    FILE *f=fopen("app.log","w");\n    for(int i=0;i<n;i++){scanf("%s",ev);fprintf(f,"[%d] %s\\n",i+1,ev);}\n    fclose(f);\n    // прочитайте последние k записей из файла и выведите\n    return 0;\n}')
},
{
 id:15,difficulty:'супер',title:'База данных в файле',
 description:'Реализуйте мини-БД: считайте команды из stdin и выполняйте:<br><code>ADD name score</code> — добавить запись в конец файла<br><code>GET name</code> — найти и вывести score или <code>NOT FOUND</code><br><code>MAX</code> — вывести имя с максимальным score<br><code>END</code> — завершить.',
 hints:[_H16('Используйте бинарный файл структур: fwrite/fread + fseek'),_H16('ADD: fseek(SEEK_END), fwrite'),_H16('GET и MAX: читать все записи с начала файла в цикле')],
 testCases:[
  {input:'ADD Alice 90\nADD Bob 85\nGET Alice\nMAX\nEND',output:'90\nAlice',hidden:false},
  {input:'ADD Ann 75\nADD Max 95\nGET Tom\nMAX\nEND',output:'NOT FOUND\nMax',hidden:false}
 ],
 initialCode:_T16('typedef struct{char name[51];int score;}Record;\nint main(){\n    char cmd[10];\n    FILE *f=fopen("db.bin","w+b");\n    while(scanf("%s",cmd)==1&&cmd[0]!=\'E\'){\n        Record r;\n        if(cmd[0]==\'A\'){\n            scanf("%s%d",r.name,&r.score);\n            fseek(f,0,SEEK_END);\n            fwrite(&r,sizeof(Record),1,f);\n        } else if(cmd[0]==\'G\'){\n            char name[51]; scanf("%s",name);\n            // найдите запись с именем name\n        } else if(cmd[0]==\'M\'){\n            // найдите запись с максимальным score\n        }\n    }\n    fclose(f);\n    return 0;\n}')
}
];
