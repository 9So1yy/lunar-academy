window.TASKS=window.TASKS||{};
const _T5=(c)=>`#include <stdio.h>\n\nint main(void) {\n    ${c||'// ваш код здесь'}\n    return 0;\n}\n`;
const _H5=(t)=>({text:t,penalty:5});

window.TASKS[5]=[
/* ============ ЛЁГКО (1-10) ============ */
{
 id:1,difficulty:'легко',title:'Обмен двух переменных',
 description:'Даны два целых числа A и B. Поменяйте их значения местами и выведите через пробел (сначала бывшее B, затем бывшее A).',
 hints:[_H5('Используйте третью (временную) переменную для сохранения одного из значений.'),_H5('tmp = a; a = b; b = tmp;'),_H5('Выведите результат: printf(\"%d %d\", a, b);')],
 testCases:[{input:'3 5',output:'5 3',hidden:false},{input:'10 20',output:'20 10',hidden:true},{input:'7 7',output:'7 7',hidden:true}],
 initialCode:_T5('int a, b;\n    scanf(\"%d %d\", &a, &b);\n    // ваш код здесь\n    printf(\"%d %d\", a, b);')
},
{
 id:2,difficulty:'легко',title:'Максимум из двух',
 description:'Даны два целых числа A и B. Выведите наибольшее из них.',
 hints:[_H5('Сравните a и b с помощью оператора if.'),_H5('if (a > b) printf(\"%d\", a); else printf(\"%d\", b);'),_H5('Если числа равны, выведите любое из них — они одинаковые.')],
 testCases:[{input:'3 5',output:'5',hidden:false},{input:'10 2',output:'10',hidden:true},{input:'7 7',output:'7',hidden:true}],
 initialCode:_T5('int a, b;\n    scanf(\"%d %d\", &a, &b);\n    // ваш код здесь')
},
{
 id:3,difficulty:'легко',title:'Минимум из двух',
 description:'Даны два целых числа A и B. Выведите наименьшее из них.',
 hints:[_H5('Сравните a и b с помощью оператора if.'),_H5('if (a < b) printf(\"%d\", a); else printf(\"%d\", b);'),_H5('Если числа равны, выведите любое из них.')],
 testCases:[{input:'3 5',output:'3',hidden:false},{input:'10 2',output:'2',hidden:true},{input:'7 7',output:'7',hidden:true}],
 initialCode:_T5('int a, b;\n    scanf(\"%d %d\", &a, &b);\n    // ваш код здесь')
},
{
 id:4,difficulty:'легко',title:'Максимум из трёх',
 description:'Даны три целых числа A, B и C. Выведите наибольшее из них.',
 hints:[_H5('Запишите максимум в отдельную переменную: int max = a;'),_H5('Затем сравните max с b: if (b > max) max = b;'),_H5('Аналогично сравните с c и выведите max.')],
 testCases:[{input:'3 7 5',output:'7',hidden:false},{input:'10 10 10',output:'10',hidden:true},{input:'1 2 3',output:'3',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
{
 id:5,difficulty:'легко',title:'Минимум из трёх',
 description:'Даны три целых числа A, B и C. Выведите наименьшее из них.',
 hints:[_H5('Запишите минимум в переменную: int min = a;'),_H5('if (b < min) min = b; if (c < min) min = c;'),_H5('printf(\"%d\", min);')],
 testCases:[{input:'3 7 5',output:'3',hidden:false},{input:'10 10 10',output:'10',hidden:true},{input:'3 1 2',output:'1',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
{
 id:6,difficulty:'легко',title:'Сортировка двух чисел',
 description:'Даны два целых числа A и B. Выведите их в порядке возрастания через пробел.',
 hints:[_H5('Если a > b, поменяйте их местами через временную переменную.'),_H5('int tmp = a; a = b; b = tmp; — только при a > b.'),_H5('После возможного обмена выведите: printf(\"%d %d\", a, b);')],
 testCases:[{input:'5 3',output:'3 5',hidden:false},{input:'1 10',output:'1 10',hidden:true},{input:'4 4',output:'4 4',hidden:true}],
 initialCode:_T5('int a, b;\n    scanf(\"%d %d\", &a, &b);\n    // ваш код здесь\n    printf(\"%d %d\", a, b);')
},
{
 id:7,difficulty:'легко',title:'Все три равны?',
 description:'Даны три целых числа A, B и C. Выведите YES, если все три числа равны между собой, и NO в противном случае.',
 hints:[_H5('Проверьте два условия одновременно: a == b и b == c.'),_H5('if (a == b && b == c) printf(\"YES\");'),_H5('else printf(\"NO\");')],
 testCases:[{input:'5 5 5',output:'YES',hidden:false},{input:'5 5 3',output:'NO',hidden:true},{input:'1 2 3',output:'NO',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
{
 id:8,difficulty:'легко',title:'Медиана трёх',
 description:'Даны три целых числа A, B и C. Выведите медиану — среднее по величине число, которое не является ни наибольшим, ни наименьшим.',
 hints:[_H5('Можно отсортировать три числа и вывести среднее.'),_H5('Другой способ: если (a >= b и a <= c) или (a <= b и a >= c), то a — медиана.'),_H5('Проверьте аналогично для b и c.')],
 testCases:[{input:'5 1 3',output:'3',hidden:false},{input:'7 7 2',output:'7',hidden:true},{input:'4 4 4',output:'4',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
{
 id:9,difficulty:'легко',title:'Сумма трёх',
 description:'Даны три целых числа A, B и C. Вычислите и выведите их сумму.',
 hints:[_H5('Сложите все три числа: a + b + c.'),_H5('Результат можно вывести напрямую, без отдельной переменной.'),_H5('printf(\"%d\", a + b + c);')],
 testCases:[{input:'1 2 3',output:'6',hidden:false},{input:'10 20 30',output:'60',hidden:true},{input:'0 0 0',output:'0',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    printf(\"%d\", a + b + c);')
},
{
 id:10,difficulty:'легко',title:'Среднее арифметическое трёх',
 description:'Даны три целых числа A, B и C. Вычислите их среднее арифметическое и выведите с одним знаком после запятой.',
 hints:[_H5('Среднее = (a + b + c) / 3.0 — используйте 3.0, а не 3!'),_H5('Деление на целое 3 отбросит дробную часть. Нужно 3.0 для вещественного деления.'),_H5('printf(\"%.1f\", (a + b + c) / 3.0);')],
 testCases:[{input:'1 2 3',output:'2.0',hidden:false},{input:'1 2 4',output:'2.3',hidden:true},{input:'10 20 30',output:'20.0',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
/* ============ СРЕДНЕ (11-17) ============ */
{
 id:11,difficulty:'средне',title:'Сортировка трёх по возрастанию',
 description:'Даны три целых числа A, B и C. Выведите их в порядке возрастания через пробел.',
 hints:[_H5('Сравните пары и поменяйте при необходимости: if (a > b) — обмен.'),_H5('Три сравнения-обмена достаточно: (a,b), затем (b,c), затем снова (a,b).'),_H5('Это простейшая пузырьковая сортировка для трёх элементов.')],
 testCases:[{input:'3 1 2',output:'1 2 3',hidden:false},{input:'5 5 5',output:'5 5 5',hidden:true},{input:'9 3 6',output:'3 6 9',hidden:true}],
 initialCode:_T5('int a, b, c, tmp;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь\n    printf(\"%d %d %d\", a, b, c);')
},
{
 id:12,difficulty:'средне',title:'Циклический сдвиг',
 description:'Даны три целых числа A, B и C. Выполните циклический сдвиг вправо: значение C переходит в A, значение A — в B, значение B — в C. Выведите новые значения A, B, C через пробел.',
 hints:[_H5('Сохраните значение C во временной переменной перед началом присваиваний.'),_H5('Порядок: tmp = c; c = b; b = a; a = tmp;'),_H5('Порядок присваиваний критически важен — иначе значения перезапишутся!')],
 testCases:[{input:'1 2 3',output:'3 1 2',hidden:false},{input:'10 20 30',output:'30 10 20',hidden:true},{input:'5 5 5',output:'5 5 5',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь\n    printf(\"%d %d %d\", a, b, c);')
},
{
 id:13,difficulty:'средне',title:'Второе по величине',
 description:'Даны три целых числа A, B и C. Найдите и выведите второе по величине число — не наибольшее и не наименьшее.',
 hints:[_H5('Один способ: отсортируйте три числа и выведите среднее.'),_H5('Другой способ: найдите max и min, тогда второе = a + b + c − max − min.'),_H5('Сумма минус крайние значения = среднее.')],
 testCases:[{input:'5 1 3',output:'3',hidden:false},{input:'7 7 2',output:'7',hidden:true},{input:'10 10 10',output:'10',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
{
 id:14,difficulty:'средне',title:'Сколько положительных',
 description:'Даны три целых числа A, B и C. Подсчитайте, сколько из них являются положительными (строго больше нуля).',
 hints:[_H5('Создайте счётчик count = 0.'),_H5('Для каждого числа: if (a > 0) count++;'),_H5('Повторите для b и c, затем выведите count.')],
 testCases:[{input:'3 -1 5',output:'2',hidden:false},{input:'0 0 0',output:'0',hidden:true},{input:'1 2 3',output:'3',hidden:true}],
 initialCode:_T5('int a, b, c, count = 0;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь\n    printf(\"%d\", count);')
},
{
 id:15,difficulty:'средне',title:'Максимум из четырёх',
 description:'Даны четыре целых числа A, B, C и D. Выведите наибольшее из них.',
 hints:[_H5('Начните с max = a, затем последовательно сравните с b, c, d.'),_H5('if (b > max) max = b; — повторите для c и d.'),_H5('printf(\"%d\", max);')],
 testCases:[{input:'3 7 2 5',output:'7',hidden:false},{input:'10 10 10 10',output:'10',hidden:true},{input:'1 2 3 4',output:'4',hidden:true}],
 initialCode:_T5('int a, b, c, d;\n    scanf(\"%d %d %d %d\", &a, &b, &c, &d);\n    // ваш код здесь')
},
{
 id:16,difficulty:'средне',title:'Сортировка трёх по убыванию',
 description:'Даны три целых числа A, B и C. Выведите их в порядке убывания через пробел.',
 hints:[_H5('Отсортируйте по возрастанию, а затем выведите в обратном порядке.'),_H5('Или измените условие: if (a < b) — обмен (вместо a > b).'),_H5('Три сравнения: (a,b), (b,c), (a,b) с условием «меньше».')],
 testCases:[{input:'1 3 2',output:'3 2 1',hidden:false},{input:'5 5 5',output:'5 5 5',hidden:true},{input:'9 3 6',output:'9 6 3',hidden:true}],
 initialCode:_T5('int a, b, c, tmp;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь\n    printf(\"%d %d %d\", a, b, c);')
},
{
 id:17,difficulty:'средне',title:'Арифметическая прогрессия',
 description:'Даны три целых числа A, B и C (в указанном порядке). Определите, образуют ли они арифметическую прогрессию (разность между соседними одинакова). Выведите YES или NO.',
 hints:[_H5('В арифметической прогрессии b − a == c − b.'),_H5('Или эквивалентно: 2 * b == a + c.'),_H5('if (b - a == c - b) printf(\"YES\"); else printf(\"NO\");')],
 testCases:[{input:'2 4 6',output:'YES',hidden:false},{input:'1 3 4',output:'NO',hidden:true},{input:'5 5 5',output:'YES',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
/* ============ СЛОЖНО (18-22) ============ */
{
 id:18,difficulty:'сложно',title:'Сортировка четырёх',
 description:'Даны четыре целых числа A, B, C и D. Выведите их в порядке возрастания через пробел. Используйте только отдельные переменные (без массивов).',
 hints:[_H5('Применяйте метод пузырька: сравнивайте соседние пары и меняйте местами.'),_H5('Потребуется три прохода: (a,b)(b,c)(c,d), затем (a,b)(b,c), затем (a,b).'),_H5('Всего 6 сравнений-обменов гарантируют правильную сортировку.')],
 testCases:[{input:'4 2 3 1',output:'1 2 3 4',hidden:false},{input:'10 10 10 10',output:'10 10 10 10',hidden:true},{input:'1 2 3 4',output:'1 2 3 4',hidden:true}],
 initialCode:_T5('int a, b, c, d, tmp;\n    scanf(\"%d %d %d %d\", &a, &b, &c, &d);\n    // ваш код здесь\n    printf(\"%d %d %d %d\", a, b, c, d);')
},
{
 id:19,difficulty:'сложно',title:'Медиана пяти',
 description:'Даны пять целых чисел A, B, C, D и E. Найдите и выведите медиану — третье по величине значение (среднее при сортировке).',
 hints:[_H5('Отсортируйте все пять переменных с помощью сравнений-обменов.'),_H5('Используйте пузырьковую сортировку: 4 прохода по убывающему числу сравнений.'),_H5('После сортировки медиана — третья переменная (c).')],
 testCases:[{input:'5 1 3 2 4',output:'3',hidden:false},{input:'10 20 30 40 50',output:'30',hidden:true},{input:'7 7 7 7 7',output:'7',hidden:true}],
 initialCode:_T5('int a, b, c, d, e, tmp;\n    scanf(\"%d %d %d %d %d\", &a, &b, &c, &d, &e);\n    // ваш код здесь')
},
{
 id:20,difficulty:'сложно',title:'Геометрическая прогрессия',
 description:'Даны три ненулевых целых числа A, B и C (в указанном порядке). Определите, образуют ли они геометрическую прогрессию (отношение соседних постоянно). Выведите YES или NO.',
 hints:[_H5('В геометрической прогрессии b/a == c/b, то есть b² = a·c.'),_H5('Чтобы избежать деления (и проблем с точностью), проверяйте: b * b == a * c.'),_H5('if (b * b == a * c) printf(\"YES\"); else printf(\"NO\");')],
 testCases:[{input:'2 6 18',output:'YES',hidden:false},{input:'1 2 3',output:'NO',hidden:true},{input:'3 9 27',output:'YES',hidden:true}],
 initialCode:_T5('int a, b, c;\n    scanf(\"%d %d %d\", &a, &b, &c);\n    // ваш код здесь')
},
{
 id:21,difficulty:'сложно',title:'Максимум из пяти',
 description:'Даны пять целых чисел A, B, C, D и E. Выведите наибольшее из них.',
 hints:[_H5('Начните с max = a.'),_H5('Последовательно сравните max с b, c, d и e: if (b > max) max = b;'),_H5('Повторите для каждой переменной и выведите max.')],
 testCases:[{input:'3 7 2 5 1',output:'7',hidden:false},{input:'10 10 10 10 10',output:'10',hidden:true},{input:'1 2 3 4 5',output:'5',hidden:true}],
 initialCode:_T5('int a, b, c, d, e;\n    scanf(\"%d %d %d %d %d\", &a, &b, &c, &d, &e);\n    // ваш код здесь')
},
{
 id:22,difficulty:'сложно',title:'Реверс четырёх',
 description:'Даны четыре целых числа A, B, C и D. Выведите их в обратном порядке через пробел (D, C, B, A).',
 hints:[_H5('Просто выведите переменные в обратном порядке.'),_H5('printf(\"%d %d %d %d\", d, c, b, a);'),_H5('Никакие обмены не нужны — измените только порядок вывода.')],
 testCases:[{input:'1 2 3 4',output:'4 3 2 1',hidden:false},{input:'5 10 15 20',output:'20 15 10 5',hidden:true},{input:'7 7 7 7',output:'7 7 7 7',hidden:true}],
 initialCode:_T5('int a, b, c, d;\n    scanf(\"%d %d %d %d\", &a, &b, &c, &d);\n    // ваш код здесь')
},
/* ============ СУПЕР (23-24) ============ */
{
 id:23,difficulty:'супер',title:'Сортировка пяти',
 description:'Даны пять целых чисел A, B, C, D и E. Выведите их в порядке возрастания через пробел. Используйте только отдельные переменные (без массивов).',
 hints:[_H5('Используйте пузырьковую сортировку: на каждом проходе сравнивайте соседние пары.'),_H5('Проход 1: (a,b)(b,c)(c,d)(d,e). Проход 2: (a,b)(b,c)(c,d). Проход 3: (a,b)(b,c). Проход 4: (a,b).'),_H5('Всего 10 сравнений-обменов. Каждый обмен: if (x > y) { tmp = x; x = y; y = tmp; }')],
 testCases:[{input:'5 3 1 4 2',output:'1 2 3 4 5',hidden:false},{input:'10 10 10 10 10',output:'10 10 10 10 10',hidden:true},{input:'5 4 3 2 1',output:'1 2 3 4 5',hidden:true}],
 initialCode:_T5('int a, b, c, d, e, tmp;\n    scanf(\"%d %d %d %d %d\", &a, &b, &c, &d, &e);\n    // ваш код здесь\n    printf(\"%d %d %d %d %d\", a, b, c, d, e);')
},
{
 id:24,difficulty:'супер',title:'Два ближайших числа',
 description:'Даны четыре целых числа A, B, C и D. Найдите пару чисел с наименьшей абсолютной разницей и выведите их через пробел (сначала меньшее, затем большее). Если пар с одинаковой минимальной разницей несколько — выведите ту, где меньшее число минимально.',
 hints:[_H5('Проверьте все 6 возможных пар: (a,b), (a,c), (a,d), (b,c), (b,d), (c,d).'),_H5('Для каждой пары вычислите разницу: diff = x − y; if (diff < 0) diff = −diff;'),_H5('Запоминайте пару с минимальной разницей. При равенстве — выбирайте пару с меньшим минимумом.')],
 testCases:[{input:'1 10 6 3',output:'1 3',hidden:false},{input:'7 2 15 9',output:'7 9',hidden:true},{input:'4 4 10 1',output:'4 4',hidden:true}],
 initialCode:_T5('int a, b, c, d;\n    scanf(\"%d %d %d %d\", &a, &b, &c, &d);\n    // ваш код здесь')
}
];
