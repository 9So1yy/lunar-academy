window.TASKS=window.TASKS||{};
const T=(d,c)=>`#include <stdio.h>\n\nint main(void) {\n    ${c||'// ваш код здесь'}\n    return 0;\n}\n`;
const H=(t)=>({text:t,penalty:5});

window.TASKS[1]=[
/* ============ ЛЁГКО (1-10) ============ */
{
 id:1,difficulty:'легко',title:'Знакомство с int',
 description:'Объявите переменную <code>int x</code> со значением <b>42</b> и выведите её через <code>printf</code> с переводом строки.',
 hints:[H('Используйте <code>%d</code> для int'),H('Шаблон: <code>printf("%d\\n", x);</code>'),H('Не забудьте <code>\\n</code> в конце')],
 testCases:[{input:'',output:'42',hidden:false}],
 initialCode:T('','int x = 42;\n    // выведите x')
},
{
 id:2,difficulty:'легко',title:'Дробное число',
 description:'Объявите <code>float pi = 3.14f</code> и выведите его с точностью <b>2 знака после запятой</b>.',
 hints:[H('Используйте <code>%.2f</code>'),H('printf("%.2f\\n", pi);'),H('Суффикс <code>f</code> делает литерал типом float')],
 testCases:[{input:'',output:'3.14',hidden:false}],
 initialCode:T('','float pi = 3.14f;\n    ')
},
{
 id:3,difficulty:'легко',title:'Символ',
 description:'Объявите <code>char c = \'A\'</code> и выведите его как символ.',
 hints:[H('Используйте <code>%c</code> для char'),H('printf("%c", c);'),H('Одинарные кавычки для одного символа')],
 testCases:[{input:'',output:'A',hidden:false}],
 initialCode:T('','char c = \'A\';\n    ')
},
{
 id:4,difficulty:'легко',title:'Double с точностью',
 description:'Объявите <code>double e = 2.71828</code> и выведите с <b>4 знаками</b> после запятой.',
 hints:[H('Используйте <code>%.4f</code>'),H('Для double в printf достаточно %f'),H('printf("%.4f\\n", e);')],
 testCases:[{input:'',output:'2.7183',hidden:false}],
 initialCode:T('','double e = 2.71828;\n    ')
},
{
 id:5,difficulty:'легко',title:'Сумма двух int',
 description:'Объявите <code>a = 17</code> и <code>b = 25</code>, выведите их сумму.',
 hints:[H('Объявите int a, b'),H('printf("%d", a + b);'),H('Ожидаемый вывод: 42')],
 testCases:[{input:'',output:'42',hidden:false}],
 initialCode:T('','int a = 17;\n    int b = 25;\n    ')
},
{
 id:6,difficulty:'легко',title:'Произведение float',
 description:'<code>x = 2.5f</code>, <code>y = 4.0f</code>. Выведите их произведение с <b>1 знаком</b> после запятой.',
 hints:[H('Тип результата — float'),H('printf("%.1f", x * y);'),H('Ожидается: 10.0')],
 testCases:[{input:'',output:'10.0',hidden:false}],
 initialCode:T('','float x = 2.5f;\n    float y = 4.0f;\n    ')
},
{
 id:7,difficulty:'легко',title:'int + double',
 description:'<code>int a = 5</code>, <code>double b = 2.5</code>. Выведите сумму с <b>2 знаками</b>. Тип результата — double.',
 hints:[H('При сложении int + double результат — double'),H('printf("%.2f", a + b);'),H('Ожидается: 7.50')],
 testCases:[{input:'',output:'7.50',hidden:false}],
 initialCode:T('','int a = 5;\n    double b = 2.5;\n    ')
},
{
 id:8,difficulty:'легко',title:'Отбрасывание дробной',
 description:'<code>double d = 9.7</code>. Преобразуйте в <code>int</code> через cast и выведите. Должно быть <b>9</b> (отбрасывание, не округление).',
 hints:[H('Используйте <code>(int)d</code>'),H('printf("%d", (int)d);'),H('Дробная часть просто отбрасывается')],
 testCases:[{input:'',output:'9',hidden:false}],
 initialCode:T('','double d = 9.7;\n    ')
},
{
 id:9,difficulty:'легко',title:'Размер int',
 description:'Выведите размер типа <code>int</code> в байтах через <code>sizeof</code>. Обычно это 4.',
 hints:[H('sizeof(int) возвращает размер в байтах'),H('Используйте <code>%zu</code> или <code>%d</code> с приведением'),H('printf("%d", (int)sizeof(int));')],
 testCases:[{input:'',output:'4',hidden:false}],
 initialCode:T()
},
{
 id:10,difficulty:'легко',title:'Размер double',
 description:'Выведите размер типа <code>double</code> в байтах. Стандарт — 8.',
 hints:[H('sizeof(double)'),H('printf("%d", (int)sizeof(double));'),H('double — это 8 байт')],
 testCases:[{input:'',output:'8',hidden:false}],
 initialCode:T()
},

/* ============ СРЕДНЕ (11-17) ============ */
{
 id:11,difficulty:'средне',title:'Среднее двух чисел',
 description:'Считайте два целых числа и выведите их среднее арифметическое с <b>1 знаком</b> после запятой. Помните: целочисленное деление обрезает!',
 hints:[H('scanf("%d %d", &a, &b);'),H('Приводите к double до деления: (double)(a+b)/2'),H('printf("%.1f", avg);')],
 testCases:[
  {input:'4 6',output:'5.0',hidden:false},
  {input:'7 8',output:'7.5',hidden:true},
  {input:'1 2',output:'1.5',hidden:true}
 ],
 initialCode:T('','int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:12,difficulty:'средне',title:'Площадь круга',
 description:'Считайте радиус <code>r</code> (целое) и выведите площадь круга S = π·r² с <b>2 знаками</b>. Возьмите π = 3.14159.',
 hints:[H('Объявите double r, S'),H('S = 3.14159 * r * r;'),H('printf("%.2f", S);')],
 testCases:[
  {input:'5',output:'78.54',hidden:false},
  {input:'10',output:'314.16',hidden:true},
  {input:'1',output:'3.14',hidden:true}
 ],
 initialCode:T('','double r;\n    scanf("%lf", &r);\n    ')
},
{
 id:13,difficulty:'средне',title:'Площадь треугольника',
 description:'Считайте основание <code>b</code> и высоту <code>h</code> (целые). Выведите площадь S = b·h/2 с <b>1 знаком</b>.',
 hints:[H('S = (double)b * h / 2;'),H('Приведение нужно из-за целочисленного деления'),H('printf("%.1f", S);')],
 testCases:[
  {input:'4 3',output:'6.0',hidden:false},
  {input:'5 7',output:'17.5',hidden:true},
  {input:'10 10',output:'50.0',hidden:true}
 ],
 initialCode:T('','int b, h;\n    scanf("%d %d", &b, &h);\n    ')
},
{
 id:14,difficulty:'средне',title:'Цельсий → Фаренгейт',
 description:'Считайте температуру в Цельсиях (целое) и выведите в Фаренгейтах с <b>1 знаком</b>. Формула: F = C·9/5 + 32.',
 hints:[H('Объявите double f'),H('f = c * 9.0 / 5.0 + 32;'),H('printf("%.1f", f);')],
 testCases:[
  {input:'0',output:'32.0',hidden:false},
  {input:'100',output:'212.0',hidden:true},
  {input:'25',output:'77.0',hidden:true}
 ],
 initialCode:T('','int c;\n    scanf("%d", &c);\n    ')
},
{
 id:15,difficulty:'средне',title:'Километры → мили',
 description:'Считайте расстояние в километрах (double) и выведите в милях с <b>2 знаками</b>. 1 км = 0.621371 мили.',
 hints:[H('scanf("%lf", &km);'),H('mi = km * 0.621371;'),H('printf("%.2f", mi);')],
 testCases:[
  {input:'10',output:'6.21',hidden:false},
  {input:'100',output:'62.14',hidden:true},
  {input:'1',output:'0.62',hidden:true}
 ],
 initialCode:T('','double km;\n    scanf("%lf", &km);\n    ')
},
{
 id:16,difficulty:'средне',title:'Среднее трёх чисел',
 description:'Считайте три целых числа и выведите их среднее с <b>2 знаками</b>.',
 hints:[H('scanf("%d %d %d", &a, &b, &c);'),H('avg = (a+b+c) / 3.0;'),H('Делите на 3.0, а не на 3!')],
 testCases:[
  {input:'1 2 3',output:'2.00',hidden:false},
  {input:'10 20 30',output:'20.00',hidden:true},
  {input:'5 7 9',output:'7.00',hidden:true}
 ],
 initialCode:T('','int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:17,difficulty:'средне',title:'Объём параллелепипеда',
 description:'Считайте три стороны <code>a, b, c</code> (целые). Выведите объём V = a·b·c. Используйте <code>long long</code> на случай больших значений.',
 hints:[H('long long V = (long long)a * b * c;'),H('printf("%lld", V);'),H('Приведение важно, иначе переполнение int')],
 testCases:[
  {input:'2 3 4',output:'24',hidden:false},
  {input:'10 10 10',output:'1000',hidden:true},
  {input:'1000 1000 1000',output:'1000000000',hidden:true}
 ],
 initialCode:T('','int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},

/* ============ СЛОЖНО (18-22) ============ */
{
 id:18,difficulty:'сложно',title:'Перевод секунд в ЧЧ:ММ:СС',
 description:'Считайте число секунд (int) и выведите время в формате <code>H:M:S</code> без ведущих нулей. Например, 3661 → <code>1:1:1</code>.',
 hints:[H('h = sec / 3600'),H('m = (sec % 3600) / 60'),H('s = sec % 60. Используйте printf("%d:%d:%d", h, m, s);')],
 testCases:[
  {input:'3661',output:'1:1:1',hidden:false},
  {input:'7200',output:'2:0:0',hidden:true},
  {input:'59',output:'0:0:59',hidden:true},
  {input:'0',output:'0:0:0',hidden:true}
 ],
 initialCode:T('','int sec;\n    scanf("%d", &sec);\n    ')
},
{
 id:19,difficulty:'сложно',title:'Цифры трёхзначного числа',
 description:'Считайте трёхзначное число и выведите его цифры через пробел: сотни, десятки, единицы. Например, 379 → <code>3 7 9</code>.',
 hints:[H('Сотни: n / 100'),H('Десятки: (n / 10) % 10'),H('Единицы: n % 10')],
 testCases:[
  {input:'379',output:'3 7 9',hidden:false},
  {input:'100',output:'1 0 0',hidden:true},
  {input:'999',output:'9 9 9',hidden:true},
  {input:'205',output:'2 0 5',hidden:true}
 ],
 initialCode:T('','int n;\n    scanf("%d", &n);\n    ')
},
{
 id:20,difficulty:'сложно',title:'Сумма цифр трёхзначного',
 description:'Считайте трёхзначное число и выведите сумму его цифр. Например, 234 → 9.',
 hints:[H('Разложите на цифры: n/100, (n/10)%10, n%10'),H('Сложите эти три значения'),H('printf("%d", s);')],
 testCases:[
  {input:'234',output:'9',hidden:false},
  {input:'999',output:'27',hidden:true},
  {input:'100',output:'1',hidden:true},
  {input:'555',output:'15',hidden:true}
 ],
 initialCode:T('','int n;\n    scanf("%d", &n);\n    ')
},
{
 id:21,difficulty:'сложно',title:'Реверс трёхзначного',
 description:'Считайте трёхзначное число и выведите его «перевёрнутым». Например, 123 → 321, 700 → 7.',
 hints:[H('a = n / 100; b = (n/10) % 10; c = n % 10;'),H('rev = c*100 + b*10 + a'),H('printf("%d", rev);')],
 testCases:[
  {input:'123',output:'321',hidden:false},
  {input:'700',output:'7',hidden:true},
  {input:'506',output:'605',hidden:true},
  {input:'999',output:'999',hidden:true}
 ],
 initialCode:T('','int n;\n    scanf("%d", &n);\n    ')
},
{
 id:22,difficulty:'сложно',title:'Длина гипотенузы',
 description:'Считайте два целых катета и выведите длину гипотенузы с <b>3 знаками</b> после запятой. Используйте sqrt из <code>&lt;math.h&gt;</code>.',
 hints:[H('#include <math.h>'),H('double c = sqrt((double)a*a + b*b);'),H('printf("%.3f", c);')],
 testCases:[
  {input:'3 4',output:'5.000',hidden:false},
  {input:'5 12',output:'13.000',hidden:true},
  {input:'1 1',output:'1.414',hidden:true},
  {input:'8 15',output:'17.000',hidden:true}
 ],
 initialCode:'#include <stdio.h>\n#include <math.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    \n    return 0;\n}\n'
},

/* ============ СУПЕР (23-24) ============ */
{
 id:23,difficulty:'супер',title:'Калькулятор времени с переносами',
 description:'Считайте часы, минуты, секунды (три int). Минуты могут быть &gt; 59, секунды тоже — нормализуйте. Выведите в формате <code>HH:MM:SS</code> с ведущими нулями.',
 hints:[H('Сначала переведите всё в секунды: total = h*3600 + m*60 + s'),H('Затем обратно: h = total/3600, m = (total%3600)/60, s = total%60'),H('printf("%02d:%02d:%02d", h, m, s); — формат с ведущими нулями')],
 testCases:[
  {input:'1 70 0',output:'02:10:00',hidden:false},
  {input:'0 0 3725',output:'01:02:05',hidden:true},
  {input:'2 30 45',output:'02:30:45',hidden:true},
  {input:'0 59 59',output:'00:59:59',hidden:true},
  {input:'0 0 86399',output:'23:59:59',hidden:true}
 ],
 initialCode:T('','int h, m, s;\n    scanf("%d %d %d", &h, &m, &s);\n    ')
},
{
 id:24,difficulty:'супер',title:'Уравнение прямой через 2 точки',
 description:'Даны 4 целых числа — координаты двух точек: x1 y1 x2 y2. Вычислите коэффициенты k и b прямой y = kx + b. Выведите их через пробел с <b>2 знаками</b>. Гарантируется x1 ≠ x2.',
 hints:[H('k = (y2 - y1) / (double)(x2 - x1);'),H('b = y1 - k * x1;'),H('printf("%.2f %.2f", k, b);')],
 testCases:[
  {input:'0 0 1 1',output:'1.00 0.00',hidden:false},
  {input:'1 2 3 6',output:'2.00 0.00',hidden:true},
  {input:'0 5 2 5',output:'0.00 5.00',hidden:true},
  {input:'1 1 5 9',output:'2.00 -1.00',hidden:true}
 ],
 initialCode:T('','int x1, y1, x2, y2;\n    scanf("%d %d %d %d", &x1, &y1, &x2, &y2);\n    ')
}
];
