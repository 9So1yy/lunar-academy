window.TASKS=window.TASKS||{};
const _T10=(c)=>`#include <stdio.h>\n#include <stdlib.h>\n\n${c}\n`;
const _H10=(t)=>({text:t,penalty:5});

window.TASKS[10]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'malloc одного int',
 description:'Через <code>malloc</code> выделите память под один int, запишите 99, выведите и освободите.',
 hints:[_H10('int* p = malloc(sizeof(int));'),_H10('*p = 99; printf("%d", *p);'),_H10('free(p);')],
 testCases:[{input:'',output:'99',hidden:false}],
 initialCode:_T10('int main(void) {\n    int* p = malloc(sizeof(int));\n    *p = 99;\n    printf("%d", *p);\n    free(p);\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'malloc и scanf',
 description:'Выделите через malloc память под один int. Считайте число в него. Выведите значение, освободите память.',
 hints:[_H10('int* p = malloc(sizeof(int));'),_H10('scanf("%d", p); // p уже адрес'),_H10('printf("%d", *p); free(p);')],
 testCases:[
  {input:'42',output:'42',hidden:false},
  {input:'-7',output:'-7',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int* p = malloc(sizeof(int));\n    scanf("%d", p);\n    printf("%d", *p);\n    free(p);\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'malloc массива',
 description:'Считайте N. Выделите массив из N int. Заполните числами 1..N. Выведите через пробел. Освободите.',
 hints:[_H10('int* a = malloc(n * sizeof(int));'),_H10('for(i=0;i<n;i++) a[i] = i+1;'),_H10('free(a);')],
 testCases:[
  {input:'5',output:'1 2 3 4 5',hidden:false},
  {input:'3',output:'1 2 3',hidden:true},
  {input:'1',output:'1',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, i;\n    scanf("%d", &n);\n    int* a = malloc(n * sizeof(int));\n    for(i=0;i<n;i++) a[i] = i+1;\n    for(i=0;i<n;i++) { if(i>0) printf(" "); printf("%d",a[i]); }\n    free(a);\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'calloc — нули',
 description:'Считайте N. Через <code>calloc</code> создайте массив N int. Выведите a[0] (должен быть 0). Освободите.',
 hints:[_H10('int* a = calloc(n, sizeof(int));'),_H10('calloc заполняет нулями автоматически'),_H10('printf("%d", a[0]);')],
 testCases:[
  {input:'5',output:'0',hidden:false},
  {input:'1',output:'0',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n;\n    scanf("%d", &n);\n    int* a = calloc(n, sizeof(int));\n    printf("%d", a[0]);\n    free(a);\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Динамическая сумма',
 description:'Считайте N, выделите массив, считайте N чисел в него, выведите их сумму. Освободите.',
 hints:[_H10('int* a = malloc(n * sizeof(int));'),_H10('int sum = 0; for(...) sum += a[i];'),_H10('printf("%d", sum);')],
 testCases:[
  {input:'4 1 2 3 4',output:'10',hidden:false},
  {input:'3 10 20 30',output:'60',hidden:true},
  {input:'1 7',output:'7',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, i;\n    scanf("%d", &n);\n    int* a = malloc(n * sizeof(int));\n    for(i=0;i<n;i++) scanf("%d",&a[i]);\n    int sum=0;\n    for(i=0;i<n;i++) sum+=a[i];\n    printf("%d", sum);\n    free(a);\n    return 0;\n}')
},
{
 id:6,difficulty:'легко',title:'Проверка malloc на NULL',
 description:'Выделите память под 1 int. Если результат NULL — выведите <code>0</code>, иначе запишите 42 и выведите. Освободите.',
 hints:[_H10('int* p = malloc(sizeof(int));'),_H10('if (p == NULL) { printf("0"); return 1; }'),_H10('*p = 42; printf("%d", *p); free(p);')],
 testCases:[{input:'',output:'42',hidden:false}],
 initialCode:_T10('int main(void) {\n    int* p = malloc(sizeof(int));\n    if (p == NULL) { printf("0"); return 1; }\n    *p = 42;\n    printf("%d", *p);\n    free(p);\n    return 0;\n}')
},
{
 id:7,difficulty:'легко',title:'Максимум в динамическом массиве',
 description:'Считайте N, выделите массив, считайте N чисел. Найдите и выведите максимум. Освободите.',
 hints:[_H10('int mx = a[0]; for(i=1;i<n;i++) if(a[i]>mx) mx=a[i];'),_H10('printf("%d", mx);')],
 testCases:[
  {input:'5 3 7 1 9 4',output:'9',hidden:false},
  {input:'3 5 5 5',output:'5',hidden:true},
  {input:'1 -3',output:'-3',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, i;\n    scanf("%d",&n);\n    int* a = malloc(n * sizeof(int));\n    for(i=0;i<n;i++) scanf("%d",&a[i]);\n    int mx = a[0];\n    for(i=1;i<n;i++) if(a[i]>mx) mx=a[i];\n    printf("%d",mx);\n    free(a);\n    return 0;\n}')
},
{
 id:8,difficulty:'легко',title:'Обращение динамического массива',
 description:'Считайте N и N чисел в динамический массив. Выведите в обратном порядке через пробел.',
 hints:[_H10('for(i=n-1;i>=0;i--) printf("%d ",a[i]);')],
 testCases:[
  {input:'4 1 2 3 4',output:'4 3 2 1',hidden:false},
  {input:'3 7 8 9',output:'9 8 7',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, i;\n    scanf("%d",&n);\n    int* a = malloc(n * sizeof(int));\n    for(i=0;i<n;i++) scanf("%d",&a[i]);\n    for(i=n-1;i>=0;i--) { if(i<n-1) printf(" "); printf("%d",a[i]); }\n    free(a);\n    return 0;\n}')
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'calloc + изменение элемента',
 description:'Считайте N. calloc массив. Выведите сумму (0). Поменяйте a[2]=100. Выведите a[2]. Числа через пробел.',
 hints:[_H10('int* a = calloc(n, sizeof(int));'),_H10('Сумма = 0 (все нули)'),_H10('a[2]=100; printf("0 100");')],
 testCases:[
  {input:'5',output:'0 100',hidden:false},
  {input:'3',output:'0 100',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, i, sum=0;\n    scanf("%d",&n);\n    int* a = calloc(n, sizeof(int));\n    for(i=0;i<n;i++) sum+=a[i];\n    a[2]=100;\n    printf("%d %d",sum,a[2]);\n    free(a);\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'realloc — расширение массива',
 description:'Выделите массив 3 int (1,2,3). Расширьте до 5 через <code>realloc</code>, добавьте 4,5. Выведите все 5 элементов через пробел.',
 hints:[_H10('int* a = malloc(3 * sizeof(int));'),_H10('a = realloc(a, 5 * sizeof(int));'),_H10('a[3]=4; a[4]=5;')],
 testCases:[{input:'',output:'1 2 3 4 5',hidden:false}],
 initialCode:_T10('int main(void) {\n    int* a = malloc(3 * sizeof(int));\n    a[0]=1; a[1]=2; a[2]=3;\n    a = realloc(a, 5 * sizeof(int));\n    a[3]=4; a[4]=5;\n    int i;\n    for(i=0;i<5;i++) { if(i>0) printf(" "); printf("%d",a[i]); }\n    free(a);\n    return 0;\n}')
},
{
 id:13,difficulty:'средне',title:'Динамическая функция',
 description:'Напишите <code>int* create_squares(int n)</code> — выделяет массив n int и заполняет квадратами 1²,2²,...,n². Считайте n, вызовите, выведите через пробел, освободите.',
 hints:[_H10('int* a = malloc(n * sizeof(int));'),_H10('for(i=0;i<n;i++) a[i]=(i+1)*(i+1);'),_H10('return a;')],
 testCases:[
  {input:'4',output:'1 4 9 16',hidden:false},
  {input:'5',output:'1 4 9 16 25',hidden:true}
 ],
 initialCode:_T10('int* create_squares(int n) {\n    int* a = malloc(n * sizeof(int));\n    int i;\n    for(i=0;i<n;i++) a[i]=(i+1)*(i+1);\n    return a;\n}\n\nint main(void) {\n    int n, i;\n    scanf("%d",&n);\n    int* a = create_squares(n);\n    for(i=0;i<n;i++) { if(i>0) printf(" "); printf("%d",a[i]); }\n    free(a);\n    return 0;\n}')
},
{
 id:14,difficulty:'средне',title:'Фильтрация в новый массив',
 description:'Считайте N и N чисел. Создайте динамический массив, скопируйте только чётные. Выведите их через пробел (если нет — вывести <code>none</code>).',
 hints:[_H10('int* even = malloc(n * sizeof(int)); int cnt=0;'),_H10('for(i=0;i<n;i++) if(a[i]%2==0) even[cnt++]=a[i];'),_H10('if(cnt==0) printf("none");')],
 testCases:[
  {input:'5 1 2 3 4 5',output:'2 4',hidden:false},
  {input:'3 1 3 5',output:'none',hidden:true},
  {input:'4 2 4 6 8',output:'2 4 6 8',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, i;\n    scanf("%d",&n);\n    int* a = malloc(n*sizeof(int));\n    for(i=0;i<n;i++) scanf("%d",&a[i]);\n    int* even = malloc(n*sizeof(int));\n    int cnt=0;\n    for(i=0;i<n;i++) if(a[i]%2==0) even[cnt++]=a[i];\n    if(cnt==0) printf("none");\n    else for(i=0;i<cnt;i++) { if(i>0) printf(" "); printf("%d",even[i]); }\n    free(a); free(even);\n    return 0;\n}')
},
{
 id:15,difficulty:'средне',title:'Два динамических массива',
 description:'Считайте N. Создайте два массива: odd (нечётные числа 1,3,...) и even (чётные 2,4,...) — по N/2+1 элементов каждый. Выведите odd[0] и even[0] через пробел.',
 hints:[_H10('int* odd = malloc(...); int* even = malloc(...);'),_H10('odd[0]=1; even[0]=2;'),_H10('printf("%d %d", odd[0], even[0]);')],
 testCases:[
  {input:'10',output:'1 2',hidden:false},
  {input:'4',output:'1 2',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n;\n    scanf("%d",&n);\n    int* odd = malloc((n/2+1)*sizeof(int));\n    int* even = malloc((n/2+1)*sizeof(int));\n    int i;\n    for(i=0;i<n/2+1;i++) { odd[i]=2*i+1; even[i]=2*(i+1); }\n    printf("%d %d", odd[0], even[0]);\n    free(odd); free(even);\n    return 0;\n}')
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'Динамическая сортировка пузырьком',
 description:'Считайте N и N чисел в динамический массив. Отсортируйте пузырьком. Выведите через пробел.',
 hints:[_H10('Стандартная сортировка с двойным циклом'),_H10('int t=a[j]; a[j]=a[j+1]; a[j+1]=t;')],
 testCases:[
  {input:'5 3 1 4 1 5',output:'1 1 3 4 5',hidden:false},
  {input:'4 8 4 2 6',output:'2 4 6 8',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, i, j;\n    scanf("%d",&n);\n    int* a = malloc(n*sizeof(int));\n    for(i=0;i<n;i++) scanf("%d",&a[i]);\n    for(i=0;i<n-1;i++)\n        for(j=0;j<n-1-i;j++)\n            if(a[j]>a[j+1]) { int t=a[j]; a[j]=a[j+1]; a[j+1]=t; }\n    for(i=0;i<n;i++) { if(i>0) printf(" "); printf("%d",a[i]); }\n    free(a);\n    return 0;\n}')
},
{
 id:19,difficulty:'сложно',title:'Слияние двух динамических массивов',
 description:'Считайте N и M, потом N и M чисел (оба массива уже отсортированы по возрастанию). Объедините в один отсортированный массив. Выведите через пробел.',
 hints:[_H10('int* c = malloc((n+m)*sizeof(int));'),_H10('Используй два индекса i и j, сравнивай a[i] и b[j]'),_H10('Добавь остатки обоих массивов')],
 testCases:[
  {input:'3 3 1 3 5 2 4 6',output:'1 2 3 4 5 6',hidden:false},
  {input:'2 2 1 2 3 4',output:'1 2 3 4',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, m, i, j, k=0;\n    scanf("%d %d",&n,&m);\n    int *a=malloc(n*sizeof(int)),*b=malloc(m*sizeof(int));\n    int *c=malloc((n+m)*sizeof(int));\n    for(i=0;i<n;i++) scanf("%d",&a[i]);\n    for(i=0;i<m;i++) scanf("%d",&b[i]);\n    i=0; j=0;\n    while(i<n&&j<m) c[k++]=(a[i]<b[j]?a[i++]:b[j++]);\n    while(i<n) c[k++]=a[i++];\n    while(j<m) c[k++]=b[j++];\n    for(i=0;i<n+m;i++) { if(i>0) printf(" "); printf("%d",c[i]); }\n    free(a);free(b);free(c);\n    return 0;\n}')
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'Динамический стек',
 description:'Реализуйте стек через динамически выделенный массив с resize при заполнении. Считайте n команд: <code>+ x</code> (push) или <code>-</code> (pop и вывести). Вывод через пробел.',
 hints:[_H10('int cap=4; int* st=malloc(cap*sizeof(int)); int top=0;'),_H10('При push: if(top==cap) { cap*=2; st=realloc(st,cap*sizeof(int)); }'),_H10('Pop: printf("%d ",st[--top]);')],
 testCases:[
  {input:'4 + 1 + 2 - -',output:'2 1',hidden:false},
  {input:'2 + 5 -',output:'5',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int cap=4, top=0, n, x; char op;\n    int* st=malloc(cap*sizeof(int));\n    scanf("%d",&n);\n    while(n--) {\n        scanf(" %c",&op);\n        if(op==\'+\') {\n            scanf("%d",&x);\n            if(top==cap) { cap*=2; st=realloc(st,cap*sizeof(int)); }\n            st[top++]=x;\n        } else {\n            if(top>0) printf("%d ",st[--top]);\n        }\n    }\n    free(st);\n    return 0;\n}')
},
{
 id:24,difficulty:'супер',title:'Матрица через double pointer',
 description:'Выделите матрицу NxM через <code>int**</code> (N указателей, каждый — malloc M int). Заполните элементами i*M+j. Выведите по строкам (числа через пробел, строки через \\n). Освободите.',
 hints:[_H10('int** m = malloc(n*sizeof(int*));'),_H10('for(i=0;i<n;i++) m[i]=malloc(cols*sizeof(int));'),_H10('m[i][j] = i*cols+j;'),_H10('Освобождать: for(i) free(m[i]); free(m);')],
 testCases:[
  {input:'2 3',output:'0 1 2\n3 4 5',hidden:false},
  {input:'3 2',output:'0 1\n2 3\n4 5',hidden:true}
 ],
 initialCode:_T10('int main(void) {\n    int n, cols, i, j;\n    scanf("%d %d",&n,&cols);\n    int** m=malloc(n*sizeof(int*));\n    for(i=0;i<n;i++) m[i]=malloc(cols*sizeof(int));\n    for(i=0;i<n;i++) for(j=0;j<cols;j++) m[i][j]=i*cols+j;\n    for(i=0;i<n;i++) {\n        for(j=0;j<cols;j++) { if(j>0) printf(" "); printf("%d",m[i][j]); }\n        printf("\\n");\n    }\n    for(i=0;i<n;i++) free(m[i]);\n    free(m);\n    return 0;\n}')
}
];
