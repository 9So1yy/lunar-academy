window.TASKS=window.TASKS||{};
const _T9=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H9=(t)=>({text:t,penalty:5});

window.TASKS[9]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'Разыменование указателя',
 description:'Объявите <code>int x = 42</code> и <code>int* p = &amp;x</code>. Выведите значение через указатель.',
 hints:[_H9('int* p = &x;'),_H9('printf("%d", *p);')],
 testCases:[{input:'',output:'42',hidden:false}],
 initialCode:_T9('int main(void) {\n    int x = 42;\n    int* p = &x;\n    printf("%d", *p);\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Изменение через указатель',
 description:'Объявите <code>int x = 5</code>. Создайте указатель на x. Через указатель присвойте значение 100. Выведите x.',
 hints:[_H9('int* p = &x;'),_H9('*p = 100;'),_H9('printf("%d", x);')],
 testCases:[{input:'',output:'100',hidden:false}],
 initialCode:_T9('int main(void) {\n    int x = 5;\n    int* p = &x;\n    // изменить через *p\n    printf("%d", x);\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Указатель и scanf',
 description:'Объявите <code>int n</code> и указатель <code>int* p = &amp;n</code>. Используйте <code>scanf("%d", p)</code> (без &). Выведите n.',
 hints:[_H9('int* p = &n;'),_H9('scanf("%d", p); // p уже адрес'),_H9('printf("%d", n);')],
 testCases:[
  {input:'77',output:'77',hidden:false},
  {input:'-5',output:'-5',hidden:true}
 ],
 initialCode:_T9('int main(void) {\n    int n;\n    int* p = &n;\n    scanf("%d", p);\n    printf("%d", n);\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Два указателя — один объект',
 description:'Объявите <code>int x = 10</code>. Создайте два указателя: <code>p1</code> и <code>p2</code>, оба на x. Через p1 увеличьте x на 5, через p2 — умножьте на 2. Выведите x.',
 hints:[_H9('int* p1 = &x; int* p2 = &x;'),_H9('*p1 += 5; *p2 *= 2;'),_H9('x = 10: +5 = 15, *2 = 30 → printf("30")')],
 testCases:[{input:'',output:'30',hidden:false}],
 initialCode:_T9('int main(void) {\n    int x = 10;\n    int* p1 = &x;\n    int* p2 = &x;\n    *p1 += 5;\n    *p2 *= 2;\n    printf("%d", x);\n    return 0;\n}')
},
{
 id:5,difficulty:'легко',title:'Арифметика указателей — массив',
 description:'Объявите <code>int arr[3] = {10, 20, 30}</code> и указатель <code>int* p = arr</code>. Выведите *(p+1) — второй элемент.',
 hints:[_H9('int* p = arr;'),_H9('printf("%d", *(p+1));'),_H9('*(p+1) == arr[1]')],
 testCases:[{input:'',output:'20',hidden:false}],
 initialCode:_T9('int main(void) {\n    int arr[3] = {10, 20, 30};\n    int* p = arr;\n    printf("%d", *(p+1));\n    return 0;\n}')
},
{
 id:6,difficulty:'легко',title:'p++ — сдвиг указателя',
 description:'Объявите <code>int a[4] = {1,2,3,4}</code> и <code>int* p = a</code>. Сдвиньте p на 2 шага (p += 2). Выведите *p.',
 hints:[_H9('p += 2; // теперь p указывает на a[2]'),_H9('printf("%d", *p); // 3')],
 testCases:[{input:'',output:'3',hidden:false}],
 initialCode:_T9('int main(void) {\n    int a[4] = {1,2,3,4};\n    int* p = a;\n    p += 2;\n    printf("%d", *p);\n    return 0;\n}')
},
{
 id:7,difficulty:'легко',title:'Считать через указатель',
 description:'Объявите <code>int a, b</code>. Создайте указатели и считайте значения через <code>scanf("%d %d", pa, pb)</code>. Выведите a+b.',
 hints:[_H9('int* pa = &a; int* pb = &b;'),_H9('scanf("%d %d", pa, pb);'),_H9('printf("%d", a+b);')],
 testCases:[
  {input:'3 4',output:'7',hidden:false},
  {input:'10 20',output:'30',hidden:true}
 ],
 initialCode:_T9('int main(void) {\n    int a, b;\n    int* pa = &a;\n    int* pb = &b;\n    scanf("%d %d", pa, pb);\n    printf("%d", a + b);\n    return 0;\n}')
},
{
 id:8,difficulty:'легко',title:'NULL-проверка',
 description:'Объявите <code>int* p = NULL</code>. Если p == NULL — вывести <code>0</code>, иначе <code>1</code>.',
 hints:[_H9('if (p == NULL) printf("0");'),_H9('printf("%d", p != NULL);')],
 testCases:[{input:'',output:'0',hidden:false}],
 initialCode:_T9('int main(void) {\n    int* p = NULL;\n    printf("%d", p != NULL);\n    return 0;\n}')
},
{
 id:9,difficulty:'легко',title:'Указатель на указатель (**)',
 description:'Объявите <code>int x = 7</code>, <code>int* p = &amp;x</code>, <code>int** pp = &amp;p</code>. Выведите значение x через **pp.',
 hints:[_H9('int** pp = &p;'),_H9('printf("%d", **pp); // то же что x')],
 testCases:[{input:'',output:'7',hidden:false}],
 initialCode:_T9('int main(void) {\n    int x = 7;\n    int* p = &x;\n    int** pp = &p;\n    printf("%d", **pp);\n    return 0;\n}')
},
{
 id:10,difficulty:'легко',title:'Указатель на struct',
 description:'Объявите <code>struct Point { int x, y; }</code>. Создайте экземпляр и указатель. Через <code>-&gt;</code> считайте x и y, выведите сумму.',
 hints:[_H9('struct Point p; struct Point* ptr = &p;'),_H9('scanf("%d %d", &ptr->x, &ptr->y);'),_H9('printf("%d", ptr->x + ptr->y);')],
 testCases:[
  {input:'5 8',output:'13',hidden:false},
  {input:'0 0',output:'0',hidden:true}
 ],
 initialCode:_T9('struct Point { int x, y; };\n\nint main(void) {\n    struct Point p;\n    struct Point* ptr = &p;\n    scanf("%d %d", &ptr->x, &ptr->y);\n    printf("%d", ptr->x + ptr->y);\n    return 0;\n}')
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'Swap через указатели',
 description:'Напишите <code>void swap(int* a, int* b)</code>. Считайте 2 числа, поменяйте, выведите через пробел.',
 hints:[_H9('int t = *a; *a = *b; *b = t;'),_H9('Вызов: swap(&x, &y);'),_H9('printf("%d %d", x, y);')],
 testCases:[
  {input:'1 2',output:'2 1',hidden:false},
  {input:'10 20',output:'20 10',hidden:true},
  {input:'5 5',output:'5 5',hidden:true}
 ],
 initialCode:_T9('void swap(int* a, int* b) {\n    // меняем значения\n}\n\nint main(void) {\n    int x, y;\n    scanf("%d %d", &x, &y);\n    swap(&x, &y);\n    printf("%d %d", x, y);\n    return 0;\n}')
},
{
 id:12,difficulty:'средне',title:'Минимум и максимум через указатели',
 description:'Напишите <code>void minmax(int a, int b, int* pmin, int* pmax)</code>. Считайте 2 числа, вызовите, выведите min и max через пробел.',
 hints:[_H9('*pmin = a < b ? a : b;'),_H9('*pmax = a > b ? a : b;'),_H9('printf("%d %d", mn, mx);')],
 testCases:[
  {input:'5 3',output:'3 5',hidden:false},
  {input:'7 7',output:'7 7',hidden:true},
  {input:'2 9',output:'2 9',hidden:true}
 ],
 initialCode:_T9('void minmax(int a, int b, int* pmin, int* pmax) {\n    // заполни *pmin и *pmax\n}\n\nint main(void) {\n    int a, b, mn, mx;\n    scanf("%d %d", &a, &b);\n    minmax(a, b, &mn, &mx);\n    printf("%d %d", mn, mx);\n    return 0;\n}')
},
{
 id:13,difficulty:'средне',title:'Функция с несколькими выходами',
 description:'Напишите <code>void divide(int a, int b, int* q, int* r)</code> — вычисляет частное (q) и остаток (r) деления a на b. Считайте a, b, выведите q и r через пробел.',
 hints:[_H9('*q = a / b; *r = a % b;'),_H9('printf("%d %d", q, r);')],
 testCases:[
  {input:'17 5',output:'3 2',hidden:false},
  {input:'10 3',output:'3 1',hidden:true},
  {input:'20 4',output:'5 0',hidden:true}
 ],
 initialCode:_T9('void divide(int a, int b, int* q, int* r) {\n    // заполни *q и *r\n}\n\nint main(void) {\n    int a, b, q, r;\n    scanf("%d %d", &a, &b);\n    divide(a, b, &q, &r);\n    printf("%d %d", q, r);\n    return 0;\n}')
},
{
 id:14,difficulty:'средне',title:'Обход массива через указатель',
 description:'Объявите <code>int a[5]</code>. Считайте 5 элементов. Через указатель (p++) выведите их в обратном порядке через пробел.',
 hints:[_H9('int* p = a + 4; // последний'),_H9('for(i=0;i<5;i++) { printf("%d",*p); p--; }')],
 testCases:[
  {input:'1 2 3 4 5',output:'5 4 3 2 1',hidden:false},
  {input:'10 20 30 40 50',output:'50 40 30 20 10',hidden:true}
 ],
 initialCode:_T9('int main(void) {\n    int a[5], i;\n    for(i=0;i<5;i++) scanf("%d",&a[i]);\n    int* p = a + 4;\n    for(i=0;i<5;i++) {\n        if(i>0) printf(" ");\n        printf("%d",*p--);\n    }\n    return 0;\n}')
},
{
 id:15,difficulty:'средне',title:'Копирование массива через указатели',
 description:'Считайте 4 числа в массив <code>src</code>. Скопируйте в <code>dst</code> через указатели (p, q). Удвойте каждый элемент dst. Выведите dst через пробел.',
 hints:[_H9('int *p=src, *q=dst;'),_H9('while(p < src+4) *q++ = *p++;'),_H9('Потом удвоить: for(i...) dst[i]*=2;')],
 testCases:[
  {input:'1 2 3 4',output:'2 4 6 8',hidden:false},
  {input:'5 5 5 5',output:'10 10 10 10',hidden:true}
 ],
 initialCode:_T9('int main(void) {\n    int src[4], dst[4], i;\n    for(i=0;i<4;i++) scanf("%d",&src[i]);\n    int *p=src, *q=dst;\n    while(p < src+4) *q++ = *p++;\n    for(i=0;i<4;i++) dst[i]*=2;\n    for(i=0;i<4;i++) { if(i>0) printf(" "); printf("%d",dst[i]); }\n    return 0;\n}')
},
{
 id:16,difficulty:'средне',title:'Указатель на функцию (базовый)',
 description:'Объявите указатель на функцию <code>int (*op)(int, int)</code>. Считайте два числа и символ операции (+/-/*). Присвойте нужную функцию и вызовите. Выведите результат.',
 hints:[_H9('int add(int a,int b){return a+b;}'),_H9('if(c==\'+\') op=add;'),_H9('printf("%d",op(a,b));')],
 testCases:[
  {input:'5 3 +',output:'8',hidden:false},
  {input:'10 4 -',output:'6',hidden:true},
  {input:'3 4 *',output:'12',hidden:true}
 ],
 initialCode:_T9('int add(int a,int b){return a+b;}\nint sub(int a,int b){return a-b;}\nint mul(int a,int b){return a*b;}\n\nint main(void) {\n    int a, b; char c;\n    int (*op)(int, int);\n    scanf("%d %d %c", &a, &b, &c);\n    if(c==\'+\') op=add;\n    else if(c==\'-\') op=sub;\n    else op=mul;\n    printf("%d", op(a,b));\n    return 0;\n}')
},
{
 id:17,difficulty:'средне',title:'Подсчёт элементов через указатель',
 description:'Напишите <code>int count_pos(int* arr, int n)</code> — считает положительные элементы. Считайте n (≤10), потом n чисел. Выведите количество положительных.',
 hints:[_H9('int count = 0;'),_H9('while(n--) if(*arr++ > 0) count++;'),_H9('return count;')],
 testCases:[
  {input:'5 1 -2 3 -4 5',output:'3',hidden:false},
  {input:'3 0 0 0',output:'0',hidden:true},
  {input:'4 1 2 3 4',output:'4',hidden:true}
 ],
 initialCode:_T9('int count_pos(int* arr, int n) {\n    int count = 0;\n    // обход через указатель\n    return count;\n}\n\nint main(void) {\n    int arr[10], n, i;\n    scanf("%d", &n);\n    for(i=0;i<n;i++) scanf("%d",&arr[i]);\n    printf("%d", count_pos(arr, n));\n    return 0;\n}')
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'Bubble sort через указатели',
 description:'Напишите <code>void bubble(int* arr, int n)</code> — сортировка пузырьком с использованием указателей. Считайте n (≤8) и n чисел. Выведите отсортированный массив.',
 hints:[_H9('for(i=0;i<n-1;i++) for(j=0;j<n-1-i;j++) if(*(arr+j)>*(arr+j+1)) swap...'),_H9('swap через вспомогательный: int t=*(arr+j); *(arr+j)=*(arr+j+1); *(arr+j+1)=t;')],
 testCases:[
  {input:'5 3 1 4 1 5',output:'1 1 3 4 5',hidden:false},
  {input:'3 9 5 7',output:'5 7 9',hidden:true}
 ],
 initialCode:_T9('void bubble(int* arr, int n) {\n    int i, j, t;\n    // сортировка\n}\n\nint main(void) {\n    int arr[8], n, i;\n    scanf("%d", &n);\n    for(i=0;i<n;i++) scanf("%d",&arr[i]);\n    bubble(arr, n);\n    for(i=0;i<n;i++) { if(i>0) printf(" "); printf("%d",arr[i]); }\n    return 0;\n}')
},
{
 id:19,difficulty:'сложно',title:'Обращение строки через указатели',
 description:'Считайте строку (без пробелов, ≤50 символов). Переверните её через два указателя (start и end). Выведите результат.',
 hints:[_H9('char s[51]; scanf("%s",s);'),_H9('char *p=s, *q=s+strlen(s)-1;'),_H9('while(p<q) { char t=*p; *p++=*q; *q--=t; }'),_H9('#include <string.h> для strlen')],
 testCases:[
  {input:'hello',output:'olleh',hidden:false},
  {input:'abcde',output:'edcba',hidden:true},
  {input:'a',output:'a',hidden:true}
 ],
 initialCode:_T9('#include <string.h>\n\nint main(void) {\n    char s[51];\n    scanf("%s", s);\n    char *p = s, *q = s + strlen(s) - 1;\n    // переворот через два указателя\n    printf("%s", s);\n    return 0;\n}')
},
{
 id:20,difficulty:'сложно',title:'Функция поиска через указатель',
 description:'Напишите <code>int* find(int* arr, int n, int x)</code> — возвращает указатель на первое вхождение x или NULL. Считайте n, n чисел, x. Выведите индекс (0-based) или -1.',
 hints:[_H9('for(int i=0;i<n;i++) if(*(arr+i)==x) return arr+i;'),_H9('return NULL;'),_H9('int* r = find(arr,n,x); printf("%d", r ? r-arr : -1);')],
 testCases:[
  {input:'5 1 2 3 4 5 3',output:'2',hidden:false},
  {input:'4 7 8 9 10 6',output:'-1',hidden:true},
  {input:'3 5 5 5 5',output:'0',hidden:true}
 ],
 initialCode:_T9('int* find(int* arr, int n, int x) {\n    int i;\n    for(i=0;i<n;i++) if(arr[i]==x) return arr+i;\n    return NULL;\n}\n\nint main(void) {\n    int arr[20], n, x, i;\n    scanf("%d",&n);\n    for(i=0;i<n;i++) scanf("%d",&arr[i]);\n    scanf("%d",&x);\n    int* r = find(arr,n,x);\n    printf("%d", r ? (int)(r-arr) : -1);\n    return 0;\n}')
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'Quicksort через указатели',
 description:'Напишите быструю сортировку (quicksort). Считайте n (≤10) и n чисел, выведите отсортированные через пробел.',
 hints:[_H9('void qsort_manual(int* lo, int* hi) — partition вокруг pivot=*hi'),_H9('Рекурсивно: qsort_manual(lo, p-1) и qsort_manual(p+1, hi)'),_H9('Или используй стандартный qsort из <stdlib.h>')],
 testCases:[
  {input:'6 64 34 25 12 22 11',output:'11 12 22 25 34 64',hidden:false},
  {input:'4 4 1 3 2',output:'1 2 3 4',hidden:true}
 ],
 initialCode:_T9('#include <stdlib.h>\n\nint cmp(const void* a, const void* b) {\n    return (*(int*)a - *(int*)b);\n}\n\nint main(void) {\n    int arr[10], n, i;\n    scanf("%d",&n);\n    for(i=0;i<n;i++) scanf("%d",&arr[i]);\n    qsort(arr, n, sizeof(int), cmp);\n    for(i=0;i<n;i++) { if(i>0) printf(" "); printf("%d",arr[i]); }\n    return 0;\n}')
},
{
 id:24,difficulty:'супер',title:'Матрица через двойной указатель',
 description:'Считайте размер n (≤4) и n×n матрицу. Через двойной указатель (статический массив) найдите максимум главной диагонали.',
 hints:[_H9('int a[4][4]; int(*p)[4]=a;'),_H9('Диагональ: p[i][i] для i=0..n-1'),_H9('Найти максимум среди p[0][0], p[1][1], ...')],
 testCases:[
  {input:'3 1 2 3 4 5 6 7 8 9',output:'9',hidden:false},
  {input:'2 10 1 1 20',output:'20',hidden:true}
 ],
 initialCode:_T9('int main(void) {\n    int a[4][4], n, i, j;\n    scanf("%d",&n);\n    for(i=0;i<n;i++) for(j=0;j<n;j++) scanf("%d",&a[i][j]);\n    int(*p)[4]=a, mx=p[0][0];\n    for(i=1;i<n;i++) if(p[i][i]>mx) mx=p[i][i];\n    printf("%d",mx);\n    return 0;\n}')
}
];
