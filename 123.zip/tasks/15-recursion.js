window.TASKS=window.TASKS||{};
const _T15=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H15=(t)=>({text:t,penalty:5});

window.TASKS[15]=[
{
 id:1,difficulty:'легко',title:'Рекурсивная сумма',
 description:'Реализуйте рекурсивную функцию <code>sum(n)</code>, которая возвращает 1+2+...+n.',
 hints:[_H15('Базовый случай: sum(0) = 0 или sum(1) = 1'),_H15('Рекурсивный шаг: sum(n) = n + sum(n-1)'),_H15('Главное — всегда уменьшать n, иначе бесконечная рекурсия')],
 testCases:[
  {input:'5',output:'15',hidden:false},
  {input:'10',output:'55',hidden:false},
  {input:'1',output:'1',hidden:true},
  {input:'100',output:'5050',hidden:true}
 ],
 initialCode:_T15('int sum(int n){\n    // базовый случай и рекурсивный шаг\n    return 0;\n}\nint main(){\n    int n; scanf("%d",&n);\n    printf("%d\\n", sum(n));\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Рекурсивное умножение',
 description:'Реализуйте умножение двух неотрицательных целых чисел через рекурсию, используя только сложение. <code>mul(a,b) = a + mul(a, b-1)</code>.',
 hints:[_H15('Базовый случай: mul(a, 0) = 0'),_H15('Рекурсивный шаг: mul(a, b) = a + mul(a, b-1)'),_H15('Гарантируется b >= 0')],
 testCases:[
  {input:'3 4',output:'12',hidden:false},
  {input:'5 0',output:'0',hidden:false},
  {input:'7 7',output:'49',hidden:true},
  {input:'0 10',output:'0',hidden:true}
 ],
 initialCode:_T15('int mul(int a, int b){\n    // умножение через сложение рекурсивно\n    return 0;\n}\nint main(){\n    int a, b; scanf("%d%d",&a,&b);\n    printf("%d\\n", mul(a,b));\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Рекурсивный реверс числа',
 description:'Напишите рекурсивную функцию, которая выводит цифры числа N в обратном порядке.',
 hints:[_H15('print_rev(n): сначала выводите n%10, потом рекурсивно вызывайте для n/10'),_H15('Базовый случай: n == 0 — возврат'),_H15('Для n=123: выводим 3, потом 2, потом 1')],
 testCases:[
  {input:'123',output:'321',hidden:false},
  {input:'1000',output:'0001',hidden:false},
  {input:'9876',output:'6789',hidden:true}
 ],
 initialCode:_T15('void print_rev(int n){\n    // выводите цифры в обратном порядке рекурсивно\n}\nint main(){\n    int n; scanf("%d",&n);\n    print_rev(n);\n    printf("\\n");\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'Рекурсивная проверка палиндрома',
 description:'Напишите рекурсивную функцию <code>is_palindrome(s, l, r)</code>, которая проверяет, является ли строка s[l..r] палиндромом. Выведите <code>YES</code> или <code>NO</code>.',
 hints:[_H15('Базовый случай: l >= r — это палиндром (пустая строка или один символ)'),_H15('Рекурсивный шаг: s[l]==s[r] && is_palindrome(s, l+1, r-1)'),_H15('#include <string.h> для strlen')],
 testCases:[
  {input:'racecar',output:'YES',hidden:false},
  {input:'hello',output:'NO',hidden:false},
  {input:'abcba',output:'YES',hidden:true},
  {input:'a',output:'YES',hidden:true}
 ],
 initialCode:_T15('#include <string.h>\nint is_palindrome(char*s, int l, int r){\n    // рекурсивная проверка палиндрома\n    return 1;\n}\nint main(){\n    char s[101]; scanf("%s",s);\n    int n=strlen(s);\n    puts(is_palindrome(s,0,n-1)?"YES":"NO");\n    return 0;\n}')
},
{
 id:5,difficulty:'средне',title:'Числа Фибоначчи с мемоизацией',
 description:'Вычислите N-е число Фибоначчи (F(0)=0, F(1)=1) рекурсивно с мемоизацией. Используйте массив memo для хранения вычисленных значений.',
 hints:[_H15('static long long memo[100]; инициализируйте -1'),_H15('Если memo[n]!=-1 — возвращайте cached значение'),_H15('Иначе: memo[n]=fib(n-1)+fib(n-2); return memo[n];')],
 testCases:[
  {input:'10',output:'55',hidden:false},
  {input:'0',output:'0',hidden:false},
  {input:'20',output:'6765',hidden:true},
  {input:'40',output:'102334155',hidden:true}
 ],
 initialCode:_T15('long long memo[100];\nlong long fib(int n){\n    // рекурсия с мемоизацией\n    return 0;\n}\nint main(){\n    for(int i=0;i<100;i++) memo[i]=-1;\n    int n; scanf("%d",&n);\n    printf("%lld\\n",fib(n));\n    return 0;\n}')
},
{
 id:6,difficulty:'средне',title:'Ханойские башни',
 description:'Решите задачу Ханойских башен для N дисков. Выведите последовательность ходов вида <code>A -> C</code> (с именами стержней A, B, C).',
 hints:[_H15('hanoi(n, from, to, via): переместить n дисков с from на to через via'),_H15('Базовый случай: n==1 — выводим "from -> to"'),_H15('Рекурсия: hanoi(n-1,from,via,to); print; hanoi(n-1,via,to,from)')],
 testCases:[
  {input:'2',output:'A -> B\nA -> C\nB -> C',hidden:false},
  {input:'3',output:'A -> C\nA -> B\nC -> B\nA -> C\nB -> A\nB -> C\nA -> C',hidden:false},
  {input:'1',output:'A -> C',hidden:true}
 ],
 initialCode:_T15('void hanoi(int n, char from, char to, char via){\n    // рекурсивное решение\n}\nint main(){\n    int n; scanf("%d",&n);\n    hanoi(n, \'A\', \'C\', \'B\');\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'Степень множества (2^n)',
 description:'Дано множество из N элементов (целые числа). Выведите все подмножества, по одному на строку. Элементы множества в строке через пробел (пустое множество — пустая строка).',
 hints:[_H15('Рекурсивная функция subset(i, chosen[]): выбрали i-й элемент или нет'),_H15('На каждом шаге: рекурсия без a[i] и рекурсия с a[i]'),_H15('Базовый случай: i==n — вывести выбранные элементы')],
 testCases:[
  {input:'2\n1 2',output:'\n2\n1\n1 2',hidden:false},
  {input:'1\n5',output:'\n5',hidden:false}
 ],
 initialCode:_T15('int a[20], chosen[20], n;\nvoid subset(int i, int k){\n    if(i==n){\n        for(int j=0;j<k;j++) printf("%d%c",chosen[j]," \\n"[j==k-1]);\n        if(k==0) printf("\\n");\n        return;\n    }\n    // рекурсия: без a[i] и с a[i]\n}\nint main(){\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    subset(0,0);\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'Рекурсивный двоичный поиск',
 description:'Реализуйте двоичный поиск рекурсивно. Функция принимает массив, границы left и right, и искомый элемент X. Возвращает индекс или -1.',
 hints:[_H15('Базовый случай: left > right — return -1'),_H15('mid = (left+right)/2'),_H15('Рекурсия: если a[mid]<X — ищем в правой половине, иначе в левой')],
 testCases:[
  {input:'7\n1 3 5 7 9 11 13\n7',output:'3',hidden:false},
  {input:'5\n2 4 6 8 10\n5',output:'-1',hidden:false},
  {input:'1\n42\n42',output:'0',hidden:true}
 ],
 initialCode:_T15('int bsearch_rec(int*a, int l, int r, int x){\n    // рекурсивный двоичный поиск\n    return -1;\n}\nint main(){\n    int n, x, a[100];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    scanf("%d",&x);\n    printf("%d\\n", bsearch_rec(a,0,n-1,x));\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'Сумма цифр рекурсивно',
 description:'Напишите рекурсивную функцию <code>digit_sum(n)</code>, возвращающую сумму цифр числа n. Для n=0 вернуть 0.',
 hints:[_H15('digit_sum(n) = n%10 + digit_sum(n/10)'),_H15('Базовый случай: n == 0 → return 0'),_H15('Для n=123: 3 + digit_sum(12) = 3 + 2 + digit_sum(1) = 6')],
 testCases:[
  {input:'123',output:'6',hidden:false},
  {input:'9999',output:'36',hidden:false},
  {input:'1000',output:'1',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T15('int digit_sum(int n){\n    // сумма цифр рекурсивно\n    return 0;\n}\nint main(){\n    int n; scanf("%d",&n);\n    printf("%d\\n", digit_sum(n));\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'НОД рекурсивно (Евклид)',
 description:'Реализуйте алгоритм Евклида для НОД рекурсивно. <code>gcd(a, b) = gcd(b, a%b)</code>, базовый случай: <code>gcd(a, 0) = a</code>.',
 hints:[_H15('Базовый случай: если b==0 — return a'),_H15('Рекурсивный шаг: return gcd(b, a%b)'),_H15('Алгоритм всегда завершается за O(log min(a,b)) шагов')],
 testCases:[
  {input:'48 18',output:'6',hidden:false},
  {input:'100 75',output:'25',hidden:false},
  {input:'17 5',output:'1',hidden:true},
  {input:'12 12',output:'12',hidden:true}
 ],
 initialCode:_T15('int gcd(int a, int b){\n    // алгоритм Евклида рекурсивно\n    return 0;\n}\nint main(){\n    int a, b; scanf("%d%d",&a,&b);\n    printf("%d\\n", gcd(a,b));\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Быстрое возведение в степень',
 description:'Реализуйте рекурсивное быстрое возведение в степень: <code>pow(b,e) = pow(b,e/2)² если e чётное, иначе b·pow(b,e-1)</code>. Результат по модулю 10⁹+7.',
 hints:[_H15('Базовый случай: pow(b,0) = 1'),_H15('Четный: long long half=pow(b,e/2); return half*half%MOD'),_H15('Нечетный: return b*pow(b,e-1)%MOD. MOD=1000000007')],
 testCases:[
  {input:'2 10',output:'1024',hidden:false},
  {input:'3 5',output:'243',hidden:false},
  {input:'2 30',output:'73741817',hidden:true},
  {input:'5 0',output:'1',hidden:true}
 ],
 initialCode:_T15('#define MOD 1000000007LL\nlong long pw(long long b, long long e){\n    // быстрое возведение в степень по модулю\n    return 0;\n}\nint main(){\n    long long b,e; scanf("%lld%lld",&b,&e);\n    printf("%lld\\n",pw(b,e));\n    return 0;\n}')
},
{
 id:12,difficulty:'сложно',title:'Перестановки строки',
 description:'Выведите все перестановки строки из N различных символов в лексикографическом порядке (по одной на строке).',
 hints:[_H15('permute(s, l, r): меняем s[l] с s[i] для i от l до r, рекурсия для l+1'),_H15('После рекурсии — обратная замена (backtrack)'),_H15('Для лексикографического порядка — отсортируйте строку перед вызовом')],
 testCases:[
  {input:'abc',output:'abc\nacb\nbac\nbca\ncab\ncba',hidden:false},
  {input:'ab',output:'ab\nba',hidden:false},
  {input:'a',output:'a',hidden:true}
 ],
 initialCode:_T15('#include <string.h>\nvoid swap_c(char*a,char*b){char t=*a;*a=*b;*b=t;}\nvoid permute(char*s,int l,int r){\n    if(l==r){puts(s);return;}\n    for(int i=l;i<=r;i++){\n        swap_c(s+l,s+i);\n        permute(s,l+1,r);\n        swap_c(s+l,s+i);\n    }\n}\nint main(){\n    char s[10]; scanf("%s",s);\n    // отсортируйте s и вызовите permute\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'Задача о рюкзаке (рекурсия)',
 description:'Дан рюкзак ёмкостью W и N предметов с весами w[] и ценностями v[]. Найдите максимальную ценность, которую можно положить рекурсивно (без мемоизации).<br><small>N ≤ 15, W ≤ 100</small>',
 hints:[_H15('knapsack(i, cap): максимальная ценность из предметов i..n-1 при ёмкости cap'),_H15('Базовый: i==n → return 0'),_H15('Два варианта: не берём i → knapsack(i+1,cap); берём если w[i]<=cap → v[i]+knapsack(i+1,cap-w[i])')],
 testCases:[
  {input:'4 8\n2 3 4 5\n3 4 5 7',output:'10',hidden:false},
  {input:'3 5\n1 2 3\n2 3 4',output:'7',hidden:false},
  {input:'2 3\n4 5\n10 20',output:'0',hidden:true}
 ],
 initialCode:_T15('int n,W,w[15],v[15];\nint knapsack(int i,int cap){\n    if(i==n) return 0;\n    // не берём i или берём i\n    return 0;\n}\nint main(){\n    scanf("%d%d",&n,&W);\n    for(int i=0;i<n;i++) scanf("%d",&w[i]);\n    for(int i=0;i<n;i++) scanf("%d",&v[i]);\n    printf("%d\\n",knapsack(0,W));\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Задача N ферзей',
 description:'Разместите N ферзей на доске N×N так, чтобы они не атаковали друг друга. Выведите количество решений.',
 hints:[_H15('Рекурсия по строкам: queens(row): пробуем каждый столбец'),_H15('Проверка безопасности: нет ферзя в том же столбце и на диагоналях'),_H15('col[], diag1[], diag2[] — массивы занятых позиций')],
 testCases:[
  {input:'4',output:'2',hidden:false},
  {input:'8',output:'92',hidden:false},
  {input:'1',output:'1',hidden:true},
  {input:'6',output:'4',hidden:true}
 ],
 initialCode:_T15('int n, col[15], d1[30], d2[30], cnt;\nvoid queens(int row){\n    if(row==n){cnt++;return;}\n    for(int c=0;c<n;c++){\n        if(!col[c]&&!d1[row-c+n]&&!d2[row+c]){\n            col[c]=d1[row-c+n]=d2[row+c]=1;\n            queens(row+1);\n            col[c]=d1[row-c+n]=d2[row+c]=0;\n        }\n    }\n}\nint main(){\n    scanf("%d",&n);\n    queens(0);\n    printf("%d\\n",cnt);\n    return 0;\n}')
},
{
 id:15,difficulty:'сложно',title:'Генерация скобочных последовательностей',
 description:'Выведите все правильные скобочные последовательности длиной 2N в лексикографическом порядке.',
 hints:[_H15('gen(pos, open, close, s[]): pos текущая позиция'),_H15('Можно добавить \'(\' если open < n'),_H15('Можно добавить \')\' если close < open')],
 testCases:[
  {input:'2',output:'(())\n()()',hidden:false},
  {input:'3',output:'((()))\n(()())\n(())()\n()(())\n()()()',hidden:false},
  {input:'1',output:'()',hidden:true}
 ],
 initialCode:_T15('int n; char buf[30];\nvoid gen(int pos,int open,int close){\n    if(pos==2*n){buf[pos]=0;puts(buf);return;}\n    if(open<n){buf[pos]=\'(\'; gen(pos+1,open+1,close);}\n    if(close<open){buf[pos]=\')\'; gen(pos+1,open,close+1);}\n}\nint main(){\n    scanf("%d",&n);\n    gen(0,0,0);\n    return 0;\n}')
},
{
 id:16,difficulty:'супер',title:'Разбиение числа на слагаемые',
 description:'Дано число N. Выведите все способы представить N как сумму натуральных слагаемых (в неубывающем порядке), по одному на строке. Каждое слагаемое ≥ 1.',
 hints:[_H15('partition(n, min, parts[], k): разбить n на слагаемые ≥ min'),_H15('Цикл i от min до n: parts[k]=i; partition(n-i, i, parts, k+1)'),_H15('Базовый: n==0 — вывести parts[0..k-1] через " + "')],
 testCases:[
  {input:'4',output:'1 + 1 + 1 + 1\n1 + 1 + 2\n1 + 3\n2 + 2\n4',hidden:false},
  {input:'3',output:'1 + 1 + 1\n1 + 2\n3',hidden:false},
  {input:'2',output:'1 + 1\n2',hidden:true}
 ],
 initialCode:_T15('int parts[30];\nvoid partition(int n,int mn,int k){\n    if(n==0){\n        for(int i=0;i<k;i++) printf("%d%s",parts[i],i<k-1?" + ":"\\n");\n        return;\n    }\n    for(int i=mn;i<=n;i++){parts[k]=i; partition(n-i,i,k+1);}\n}\nint main(){\n    int n; scanf("%d",&n);\n    partition(n,1,0);\n    return 0;\n}')
}
];
