window.TASKS=window.TASKS||{};
const _T20=(c)=>`#include <stdio.h>\n\n${c}\n`;
const _H20=(t)=>({text:t,penalty:5});

window.TASKS[20]=[
{
 id:1,difficulty:'легко',title:'O(1) vs O(N) — сумма Гаусса',
 description:'Выведите сумму 1+2+...+N двумя способами: циклом O(N) и формулой Гаусса O(1). Убедитесь что результаты совпадают. Выведите оба.',
 hints:[_H20('Цикл: sum=0; for(i=1;i<=n;i++) sum+=i;'),_H20('Формула Гаусса: sum = n*(n+1)/2'),_H20('long long для больших N — N*(N+1) может переполнить int')],
 testCases:[
  {input:'100',output:'5050\n5050',hidden:false},
  {input:'10',output:'55\n55',hidden:false},
  {input:'1000000',output:'500000500000\n500000500000',hidden:true}
 ],
 initialCode:_T20('int main(){\n    long long n; scanf("%lld",&n);\n    long long s1=0;\n    for(long long i=1;i<=n;i++) s1+=i;\n    long long s2=n*(n+1)/2;\n    printf("%lld\\n%lld\\n",s1,s2);\n    return 0;\n}')
},
{
 id:2,difficulty:'легко',title:'Кэширование — мемоизация факториала',
 description:'Вычислите факториалы для Q запросов. Без мемоизации — O(Q·N). С кэшем — O(N+Q). Реализуйте версию с кэшем: вычисляйте каждый факториал только один раз.',
 hints:[_H20('static long long cache[21]={0}; cache[0]=1;'),_H20('При запросе n: если cache[n]!=0 — вернуть cache[n]'),_H20('Иначе вычислить и сохранить: cache[n]=n*fact(n-1)')],
 testCases:[
  {input:'3\n5\n10\n5',output:'120\n3628800\n120',hidden:false},
  {input:'2\n0\n20',output:'1\n2432902008176640000',hidden:true}
 ],
 initialCode:_T20('long long cache[21];\nlong long fact(int n){\n    if(cache[n]) return cache[n];\n    return cache[n]=n*fact(n-1);\n}\nint main(){\n    cache[0]=1;\n    int q,n;\n    scanf("%d",&q);\n    while(q--){scanf("%d",&n);printf("%lld\\n",fact(n));}\n    return 0;\n}')
},
{
 id:3,difficulty:'легко',title:'Избегание лишних вычислений в цикле',
 description:'Дан массив из N чисел. Найдите среднее значение. Вынесите вычисление N из цикла. Выведите среднее с 2 знаками после запятой.',
 hints:[_H20('Неоптимально: for(i=0;i<strlen(s);i++) — strlen вызывается на каждой итерации'),_H20('Оптимально: int len=n; for(i=0;i<len;i++) — кэшируем длину'),_H20('Компилятор не всегда оптимизирует вызовы функций в условии')],
 testCases:[
  {input:'5\n1 2 3 4 5',output:'3.00',hidden:false},
  {input:'4\n10 20 30 40',output:'25.00',hidden:false},
  {input:'3\n1 1 1',output:'1.00',hidden:true}
 ],
 initialCode:_T20('int main(){\n    int n,a[1000];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    double sum=0;\n    int len=n;\n    for(int i=0;i<len;i++) sum+=a[i];\n    printf("%.2f\\n",sum/n);\n    return 0;\n}')
},
{
 id:4,difficulty:'легко',title:'register и volatile (ключевые слова)',
 description:'Напишите программу с переменной <code>register int i</code> для счётчика цикла. Подсчитайте сумму 1..N. Объявите <code>volatile int flag=1</code> (имитация IO-флага). Выведите сумму.',
 hints:[_H20('register int i — подсказка компилятору держать i в регистре (современные компиляторы игнорируют)'),_H20('volatile int x — запрет оптимизации переменной (для IO, прерываний)'),_H20('На практике register игнорируется в C99+')],
 testCases:[
  {input:'10',output:'55',hidden:false},
  {input:'100',output:'5050',hidden:false}
 ],
 initialCode:_T20('int main(){\n    int n; scanf("%d",&n);\n    register int i;\n    volatile int flag=1;\n    long long sum=0;\n    for(i=1;i<=n&&flag;i++) sum+=i;\n    printf("%lld\\n",sum);\n    return 0;\n}')
},
{
 id:5,difficulty:'средне',title:'Динамическое программирование — монеты',
 description:'Дан номинал монет и сумма S. Найдите минимальное количество монет для набора суммы S. DP O(S·N) vs рекурсия O(N^S).',
 hints:[_H20('dp[0]=0; dp[i]=INT_MAX для i>0'),_H20('Для каждой суммы i от 1 до S: для каждой монеты c: если i>=c && dp[i-c]+1 < dp[i]'),_H20('#include <limits.h> для INT_MAX')],
 testCases:[
  {input:'3 11\n1 5 6',output:'2',hidden:false},
  {input:'4 7\n1 3 4 5',output:'2',hidden:false},
  {input:'2 11\n5 6',output:'-1',hidden:true}
 ],
 initialCode:_T20('#include <limits.h>\nint main(){\n    int n,S;\n    scanf("%d%d",&n,&S);\n    int coins[20];\n    for(int i=0;i<n;i++) scanf("%d",&coins[i]);\n    int dp[10001];\n    dp[0]=0;\n    for(int i=1;i<=S;i++) dp[i]=INT_MAX;\n    for(int i=1;i<=S;i++){\n        for(int j=0;j<n;j++){\n            if(i>=coins[j]&&dp[i-coins[j]]!=INT_MAX)\n                if(dp[i-coins[j]]+1<dp[i]) dp[i]=dp[i-coins[j]]+1;\n        }\n    }\n    printf("%d\\n",dp[S]==INT_MAX?-1:dp[S]);\n    return 0;\n}')
},
{
 id:6,difficulty:'средне',title:'Сито Эратосфена',
 description:'Найдите все простые числа до N методом сита Эратосфена O(N log log N). Выведите их через пробел.',
 hints:[_H20('Создайте массив is_prime[N+1] = {true}'),_H20('Для каждого p от 2 до sqrt(N): если is_prime[p] — зачеркните все кратные p²,p²+p,...'),_H20('for(j=p*p;j<=N;j+=p) is_prime[j]=0;')],
 testCases:[
  {input:'20',output:'2 3 5 7 11 13 17 19',hidden:false},
  {input:'10',output:'2 3 5 7',hidden:false},
  {input:'2',output:'2',hidden:true},
  {input:'50',output:'2 3 5 7 11 13 17 19 23 29 31 37 41 43 47',hidden:true}
 ],
 initialCode:_T20('int main(){\n    int n; scanf("%d",&n);\n    int sieve[10001];\n    for(int i=0;i<=n;i++) sieve[i]=1;\n    sieve[0]=sieve[1]=0;\n    for(int p=2;(long long)p*p<=n;p++)\n        if(sieve[p]) for(int j=p*p;j<=n;j+=p) sieve[j]=0;\n    int first=1;\n    for(int i=2;i<=n;i++) if(sieve[i]){\n        if(!first) printf(" ");\n        printf("%d",i); first=0;\n    }\n    printf("\\n");\n    return 0;\n}')
},
{
 id:7,difficulty:'средне',title:'Префиксные суммы',
 description:'Дан массив из N чисел. Постройте массив префиксных сумм. Ответьте на Q запросов [l,r]: сумма элементов a[l..r] за O(1) каждый.',
 hints:[_H20('prefix[0]=0; prefix[i]=prefix[i-1]+a[i-1] (1-indexed)'),_H20('Сумма a[l..r] = prefix[r+1] - prefix[l] (0-indexed)'),_H20('Построение O(N), каждый запрос O(1)')],
 testCases:[
  {input:'5\n1 2 3 4 5\n3\n0 2\n1 3\n0 4',output:'6\n9\n15',hidden:false},
  {input:'3\n10 20 30\n2\n0 0\n1 2',output:'10\n50',hidden:false}
 ],
 initialCode:_T20('int main(){\n    int n,a[1000],pre[1001];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    pre[0]=0;\n    for(int i=0;i<n;i++) pre[i+1]=pre[i]+a[i];\n    int q,l,r;\n    scanf("%d",&q);\n    while(q--){\n        scanf("%d%d",&l,&r);\n        printf("%d\\n",pre[r+1]-pre[l]);\n    }\n    return 0;\n}')
},
{
 id:8,difficulty:'средне',title:'Двумерные префиксные суммы',
 description:'Дана матрица N×M. Постройте 2D-префиксные суммы. Ответьте на Q запросов: сумма подматрицы (r1,c1)-(r2,c2) за O(1).',
 hints:[_H20('pre[i][j] = a[i-1][j-1] + pre[i-1][j] + pre[i][j-1] - pre[i-1][j-1]'),_H20('Сумма подматрицы: pre[r2+1][c2+1] - pre[r1][c2+1] - pre[r2+1][c1] + pre[r1][c1]'),_H20('Формула включения-исключения')],
 testCases:[
  {input:'3 3\n1 2 3\n4 5 6\n7 8 9\n1\n0 0 1 1',output:'12',hidden:false},
  {input:'2 2\n1 2\n3 4\n1\n0 0 1 1',output:'10',hidden:false}
 ],
 initialCode:_T20('int a[101][101],pre[102][102];\nint main(){\n    int n,m;\n    scanf("%d%d",&n,&m);\n    for(int i=0;i<n;i++) for(int j=0;j<m;j++) scanf("%d",&a[i][j]);\n    for(int i=1;i<=n;i++)\n        for(int j=1;j<=m;j++)\n            pre[i][j]=a[i-1][j-1]+pre[i-1][j]+pre[i][j-1]-pre[i-1][j-1];\n    int q; scanf("%d",&q);\n    while(q--){\n        int r1,c1,r2,c2; scanf("%d%d%d%d",&r1,&c1,&r2,&c2);\n        printf("%d\\n",pre[r2+1][c2+1]-pre[r1][c2+1]-pre[r2+1][c1]+pre[r1][c1]);\n    }\n    return 0;\n}')
},
{
 id:9,difficulty:'средне',title:'Скользящее окно (sliding window)',
 description:'Дан массив из N чисел и размер окна K. Найдите максимум в каждом окне [i, i+K-1] для всех i от 0 до N-K.',
 hints:[_H20('Простой O(N·K): вложенный цикл — для малых K'),_H20('Для каждого нового окна: сдвигаем i, ищем max среди K элементов'),_H20('Оптимум O(N) через deque (двухсторонняя очередь), но O(N·K) тоже принимается')],
 testCases:[
  {input:'7 3\n1 3 -1 -3 5 3 6',output:'3 3 5 5 6',hidden:false},
  {input:'5 2\n2 1 5 3 6',output:'2 5 5 6',hidden:false}
 ],
 initialCode:_T20('int main(){\n    int n,k,a[1000];\n    scanf("%d%d",&n,&k);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    for(int i=0;i<=n-k;i++){\n        int mx=a[i];\n        for(int j=i+1;j<i+k;j++) if(a[j]>mx) mx=a[j];\n        printf("%d%c",mx," \\n"[i==n-k]);\n    }\n    return 0;\n}')
},
{
 id:10,difficulty:'средне',title:'Задача о наибольшей подпоследовательности (LIS)',
 description:'Дан массив из N чисел. Найдите длину наибольшей возрастающей подпоследовательности (LIS) за O(N²).',
 hints:[_H20('dp[i] = длина LIS, заканчивающейся в a[i]'),_H20('dp[i] = 1 + max(dp[j]) для всех j<i, где a[j]<a[i]'),_H20('Ответ: max(dp[0..n-1])')],
 testCases:[
  {input:'8\n10 9 2 5 3 7 101 18',output:'4',hidden:false},
  {input:'6\n3 10 2 1 20 5',output:'3',hidden:false},
  {input:'4\n1 2 3 4',output:'4',hidden:true},
  {input:'4\n4 3 2 1',output:'1',hidden:true}
 ],
 initialCode:_T20('int main(){\n    int n,a[1000],dp[1000];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    for(int i=0;i<n;i++){\n        dp[i]=1;\n        for(int j=0;j<i;j++)\n            if(a[j]<a[i]&&dp[j]+1>dp[i]) dp[i]=dp[j]+1;\n    }\n    int ans=0;\n    for(int i=0;i<n;i++) if(dp[i]>ans) ans=dp[i];\n    printf("%d\\n",ans);\n    return 0;\n}')
},
{
 id:11,difficulty:'средне',title:'Матричное умножение — кэш-дружелюбный порядок',
 description:'Умножьте две матрицы N×N. Реализуйте ikj-порядок цикла (кэш-дружелюбный): меняйте порядок вложенных циклов ijk → ikj и сравните корректность.',
 hints:[_H20('ijk: C[i][j] += A[i][k]*B[k][j] — каждый шаг прыгает в памяти по B'),_H20('ikj: C[i][j] += A[i][k]*B[k][j] — та же формула, но сканируем строку B (кэш-дружелюбно)'),_H20('Правильный порядок for(i) for(k) for(j)')],
 testCases:[
  {input:'2\n1 2\n3 4\n5 6\n7 8',output:'19 22\n43 50',hidden:false},
  {input:'2\n1 0\n0 1\n3 4\n5 6',output:'3 4\n5 6',hidden:false}
 ],
 initialCode:_T20('int a[50][50],b[50][50],c[50][50];\nint main(){\n    int n; scanf("%d",&n);\n    for(int i=0;i<n;i++) for(int j=0;j<n;j++) scanf("%d",&a[i][j]);\n    for(int i=0;i<n;i++) for(int j=0;j<n;j++) scanf("%d",&b[i][j]);\n    // ikj-порядок: for i, for k, for j\n    for(int i=0;i<n;i++) for(int k=0;k<n;k++) for(int j=0;j<n;j++) c[i][j]+=a[i][k]*b[k][j];\n    for(int i=0;i<n;i++){for(int j=0;j<n;j++) printf("%d%c",c[i][j]," \\n"[j==n-1]);}\n    return 0;\n}')
},
{
 id:12,difficulty:'сложно',title:'Задача о наибольшей общей подпоследовательности (LCS)',
 description:'Дано две строки. Найдите длину наибольшей общей подпоследовательности (LCS) методом динамического программирования.',
 hints:[_H20('dp[i][j] = LCS(s1[0..i-1], s2[0..j-1])'),_H20('Если s1[i-1]==s2[j-1]: dp[i][j]=dp[i-1][j-1]+1'),_H20('Иначе: dp[i][j]=max(dp[i-1][j],dp[i][j-1])')],
 testCases:[
  {input:'ABCBDAB\nBDCAB',output:'4',hidden:false},
  {input:'AGGTAB\nGXTXAYB',output:'4',hidden:false},
  {input:'abc\nabc',output:'3',hidden:true}
 ],
 initialCode:_T20('#include <string.h>\nint dp[1001][1001];\nint main(){\n    char s1[101],s2[101];\n    scanf("%s%s",s1,s2);\n    int n=strlen(s1),m=strlen(s2);\n    for(int i=1;i<=n;i++)\n        for(int j=1;j<=m;j++){\n            if(s1[i-1]==s2[j-1]) dp[i][j]=dp[i-1][j-1]+1;\n            else dp[i][j]=dp[i-1][j]>dp[i][j-1]?dp[i-1][j]:dp[i][j-1];\n        }\n    printf("%d\\n",dp[n][m]);\n    return 0;\n}')
},
{
 id:13,difficulty:'сложно',title:'Алгоритм Кадане — максимальная подпоследовательность',
 description:'Найдите подмассив с максимальной суммой (алгоритм Кадане, O(N)). Выведите максимальную сумму и индексы начала и конца подмассива.',
 hints:[_H20('max_ending_here = max(a[i], max_ending_here + a[i])'),_H20('Отслеживайте start, end, temp_start'),_H20('Когда обновляем max_so_far — обновляем start и end')],
 testCases:[
  {input:'8\n-2 1 -3 4 -1 2 1 -5',output:'6 3 6',hidden:false},
  {input:'5\n1 2 3 4 5',output:'15 0 4',hidden:false},
  {input:'4\n-1 -2 -3 -4',output:'-1 0 0',hidden:true}
 ],
 initialCode:_T20('int main(){\n    int n,a[1000];\n    scanf("%d",&n);\n    for(int i=0;i<n;i++) scanf("%d",&a[i]);\n    int max_h=a[0],max_s=a[0],ts=0,s=0,e=0;\n    for(int i=1;i<n;i++){\n        if(max_h+a[i]>a[i]) max_h+=a[i];\n        else{max_h=a[i];ts=i;}\n        if(max_h>max_s){max_s=max_h;s=ts;e=i;}\n    }\n    printf("%d %d %d\\n",max_s,s,e);\n    return 0;\n}')
},
{
 id:14,difficulty:'сложно',title:'Дискретное логарифмирование (Baby-step Giant-step)',
 description:'Решите уравнение <code>a^x ≡ b (mod p)</code> за O(√p). Алгоритм BSGS. Выведите наименьший x ≥ 0 или <code>-1</code> если решения нет.<br><small>p простое, 2 ≤ a,b < p ≤ 1000</small>',
 hints:[_H20('m = ceil(sqrt(p))'),_H20('Baby step: вычислите b * a^j mod p для j=0..m, сохраните в хэш-таблицу'),_H20('Giant step: вычислите (a^m)^i mod p для i=1..m, ищите совпадение')],
 testCases:[
  {input:'3 13 1',output:'3',hidden:false},
  {input:'2 11 8',output:'3',hidden:false},
  {input:'2 7 3',output:'-1',hidden:true}
 ],
 initialCode:_T20('#include <math.h>\n#include <string.h>\nlong long pw(long long b,long long e,long long m){long long r=1;b%=m;while(e>0){if(e&1)r=r*b%m;b=b*b%m;e>>=1;}return r;}\nint main(){\n    long long a,p,b;\n    scanf("%lld%lld%lld",&a,&p,&b);\n    int m=(int)ceil(sqrt((double)p))+1;\n    long long keys[1001],vals[1001]; int sz=0;\n    long long cur=b;\n    for(int j=0;j<=m;j++){keys[sz]=cur;vals[sz]=j;sz++;cur=cur*a%p;}\n    long long am=pw(a,m,p); cur=1;\n    for(int i=1;i<=m+1;i++){\n        cur=cur*am%p;\n        for(int k=0;k<sz;k++) if(keys[k]==cur){printf("%lld\\n",(long long)i*m-vals[k]);return 0;}\n    }\n    printf("-1\\n");\n    return 0;\n}')
},
{
 id:15,difficulty:'супер',title:'Задача о рюкзаке с DP O(N·W)',
 description:'Дан рюкзак ёмкостью W и N предметов с весами w[] и ценностями v[]. Найдите максимальную ценность с помощью ДП. Также восстановите набор предметов.',
 hints:[_H20('dp[i][w] = максимальная ценность из первых i предметов с ёмкостью w'),_H20('dp[i][w] = max(dp[i-1][w], v[i-1]+dp[i-1][w-w[i-1]]) если w>=w[i-1]'),_H20('Восстановление: идём от dp[n][W] назад: если dp[i][w]!=dp[i-1][w] — взяли предмет i')],
 testCases:[
  {input:'4 8\n2 3 4 5\n3 4 5 7',output:'10\n2 4',hidden:false},
  {input:'3 5\n2 3 4\n3 4 5',output:'7\n1 2',hidden:false}
 ],
 initialCode:_T20('int dp[101][1001],w[101],v[101];\nint main(){\n    int n,W;\n    scanf("%d%d",&n,&W);\n    for(int i=0;i<n;i++) scanf("%d",&w[i]);\n    for(int i=0;i<n;i++) scanf("%d",&v[i]);\n    for(int i=1;i<=n;i++)\n        for(int j=0;j<=W;j++){\n            dp[i][j]=dp[i-1][j];\n            if(j>=w[i-1]&&dp[i-1][j-w[i-1]]+v[i-1]>dp[i][j])\n                dp[i][j]=dp[i-1][j-w[i-1]]+v[i-1];\n        }\n    printf("%d\\n",dp[n][W]);\n    int j=W;\n    int first=1;\n    for(int i=n;i>0;i--) if(dp[i][j]!=dp[i-1][j]){\n        if(!first) printf(" "); printf("%d",i); first=0; j-=w[i-1];\n    }\n    printf("\\n");\n    return 0;\n}')
}
];
