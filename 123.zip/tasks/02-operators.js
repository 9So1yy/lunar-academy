window.TASKS=window.TASKS||{};
const _T2=(c)=>`#include <stdio.h>\n\nint main(void) {\n    ${c}\n    return 0;\n}\n`;
const _H2=(t)=>({text:t,penalty:5});

window.TASKS[2]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'Сложение',
 description:'Считайте два целых числа и выведите их сумму.',
 hints:[_H2('scanf("%d %d", &a, &b);'),_H2('printf("%d", a + b);')],
 testCases:[
  {input:'2 3',output:'5',hidden:false},
  {input:'100 200',output:'300',hidden:true},
  {input:'-5 3',output:'-2',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    // выведи сумму')
},
{
 id:2,difficulty:'легко',title:'Вычитание',
 description:'Считайте два целых числа и выведите разность a−b.',
 hints:[_H2('printf("%d", a - b);')],
 testCases:[
  {input:'10 3',output:'7',hidden:false},
  {input:'5 5',output:'0',hidden:true},
  {input:'3 10',output:'-7',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:3,difficulty:'легко',title:'Умножение',
 description:'Считайте два целых числа и выведите их произведение.',
 hints:[_H2('printf("%d", a * b);')],
 testCases:[
  {input:'4 5',output:'20',hidden:false},
  {input:'7 6',output:'42',hidden:true},
  {input:'-3 4',output:'-12',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:4,difficulty:'легко',title:'Целочисленное деление',
 description:'Считайте два целых числа и выведите результат целочисленного деления a/b.',
 hints:[_H2('В C деление int / int отбрасывает дробь'),_H2('printf("%d", a / b);')],
 testCases:[
  {input:'10 3',output:'3',hidden:false},
  {input:'20 4',output:'5',hidden:true},
  {input:'7 2',output:'3',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:5,difficulty:'легко',title:'Остаток от деления',
 description:'Считайте два числа и выведите остаток от деления a на b (оператор %).',
 hints:[_H2('Оператор % — остаток'),_H2('printf("%d", a % b);')],
 testCases:[
  {input:'17 5',output:'2',hidden:false},
  {input:'100 7',output:'2',hidden:true},
  {input:'10 3',output:'1',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:6,difficulty:'легко',title:'Квадрат числа',
 description:'Считайте целое число и выведите его квадрат.',
 hints:[_H2('n * n'),_H2('printf("%d", n * n);')],
 testCases:[
  {input:'5',output:'25',hidden:false},
  {input:'12',output:'144',hidden:true},
  {input:'-3',output:'9',hidden:true}
 ],
 initialCode:_T2('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:7,difficulty:'легко',title:'Среднее двух чисел',
 description:'Считайте два целых числа и выведите их среднее с двумя знаками после запятой.',
 hints:[_H2('Приведи к double: (double)(a + b) / 2'),_H2('printf("%.2f", avg);')],
 testCases:[
  {input:'3 7',output:'5.00',hidden:false},
  {input:'1 2',output:'1.50',hidden:true},
  {input:'10 10',output:'10.00',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:8,difficulty:'легко',title:'Минуты → часы и минуты',
 description:'Считайте количество минут. Выведите через пробел: количество полных часов и оставшиеся минуты.',
 hints:[_H2('Часы = m / 60'),_H2('Минуты = m % 60'),_H2('printf("%d %d", m/60, m%60);')],
 testCases:[
  {input:'90',output:'1 30',hidden:false},
  {input:'60',output:'1 0',hidden:true},
  {input:'125',output:'2 5',hidden:true}
 ],
 initialCode:_T2('int m;\n    scanf("%d", &m);\n    ')
},
{
 id:9,difficulty:'легко',title:'Цифры двузначного числа',
 description:'Считайте двузначное число. Выведите через пробел сначала цифру десятков, потом единиц.',
 hints:[_H2('Десятки: n / 10'),_H2('Единицы: n % 10'),_H2('printf("%d %d", n/10, n%10);')],
 testCases:[
  {input:'42',output:'4 2',hidden:false},
  {input:'71',output:'7 1',hidden:true},
  {input:'50',output:'5 0',hidden:true}
 ],
 initialCode:_T2('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:10,difficulty:'легко',title:'Знак числа без if',
 description:'Считайте целое число. Выведите <code>1</code> (положительное), <code>-1</code> (отрицательное) или <code>0</code>. Используйте только арифметические/сравнительные операторы — без <code>if</code>.',
 hints:[_H2('В C результат сравнения — 0 или 1'),_H2('(n > 0) - (n < 0)'),_H2('printf("%d", (n>0)-(n<0));')],
 testCases:[
  {input:'5',output:'1',hidden:false},
  {input:'-3',output:'-1',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T2('int n;\n    scanf("%d", &n);\n    ')
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'Цепочка составных операторов',
 description:'Считайте <code>x</code>. Выполни последовательно: <code>x += 10</code>, <code>x *= 2</code>, <code>x -= 5</code>, <code>x /= 3</code>. Выведи результат.',
 hints:[_H2('Применяй операции по очереди'),_H2('Результат для x=5: 5+10=15, *2=30, -5=25, /3=8')],
 testCases:[
  {input:'5',output:'8',hidden:false},
  {input:'0',output:'5',hidden:true},
  {input:'10',output:'11',hidden:true}
 ],
 initialCode:_T2('int x;\n    scanf("%d", &x);\n    // x+=10; x*=2; x-=5; x/=3;')
},
{
 id:12,difficulty:'средне',title:'Побитовое И',
 description:'Считайте два целых числа. Выведите результат побитового И (<code>&</code>).',
 hints:[_H2('printf("%d", a & b);'),_H2('Например: 6 & 3 → 110 & 011 = 010 = 2')],
 testCases:[
  {input:'6 3',output:'2',hidden:false},
  {input:'15 9',output:'9',hidden:true},
  {input:'255 170',output:'170',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:13,difficulty:'средне',title:'Побитовые ИЛИ и XOR',
 description:'Считайте два числа <code>a</code> и <code>b</code>. Выведите через пробел: <code>a|b</code> и <code>a^b</code>.',
 hints:[_H2('printf("%d %d", a|b, a^b);')],
 testCases:[
  {input:'5 3',output:'7 6',hidden:false},
  {input:'12 10',output:'14 6',hidden:true},
  {input:'0 255',output:'255 255',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:14,difficulty:'средне',title:'Битовые сдвиги',
 description:'Считайте <code>n</code>. Выведите через пробел: <code>n&lt;&lt;1</code> (×2) и <code>n&gt;&gt;1</code> (÷2).',
 hints:[_H2('printf("%d %d", n<<1, n>>1);')],
 testCases:[
  {input:'8',output:'16 4',hidden:false},
  {input:'5',output:'10 2',hidden:true},
  {input:'100',output:'200 50',hidden:true}
 ],
 initialCode:_T2('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:15,difficulty:'средне',title:'Обмен без третьей переменной',
 description:'Считайте <code>a</code> и <code>b</code>. Поменяйте их местами без третьей переменной (используй XOR или арифметику). Выведите через пробел.',
 hints:[_H2('XOR-swap: a^=b; b^=a; a^=b;'),_H2('Арифметика: a=a+b; b=a-b; a=a-b;'),_H2('printf("%d %d", a, b);')],
 testCases:[
  {input:'3 7',output:'7 3',hidden:false},
  {input:'10 20',output:'20 10',hidden:true},
  {input:'42 1',output:'1 42',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    // обменяй без tmp')
},
{
 id:16,difficulty:'средне',title:'Чётность через &',
 description:'Считайте целое число. Выведите <code>0</code> если чётное, <code>1</code> если нечётное. Используйте только оператор <code>&</code>.',
 hints:[_H2('n & 1 == 1 для нечётных'),_H2('printf("%d", n & 1);')],
 testCases:[
  {input:'4',output:'0',hidden:false},
  {input:'7',output:'1',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T2('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:17,difficulty:'средне',title:'Логические операторы',
 description:'Считайте три числа <code>a</code>, <code>b</code>, <code>c</code>. Выведите <code>1</code>, если <code>a&gt;b</code> И <code>b&gt;c</code>, иначе <code>0</code>.',
 hints:[_H2('printf("%d", a > b && b > c);'),_H2('В C результат && это 0 или 1')],
 testCases:[
  {input:'5 3 1',output:'1',hidden:false},
  {input:'1 3 5',output:'0',hidden:true},
  {input:'5 5 3',output:'0',hidden:true}
 ],
 initialCode:_T2('int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'Максимум трёх через тернарник',
 description:'Считайте три числа и выведите максимум, используя <b>только</b> тернарный оператор <code>?:</code> (без if).',
 hints:[_H2('int m = a > b ? a : b; m = m > c ? m : c;'),_H2('printf("%d", m);')],
 testCases:[
  {input:'5 3 8',output:'8',hidden:false},
  {input:'10 20 15',output:'20',hidden:true},
  {input:'7 7 7',output:'7',hidden:true}
 ],
 initialCode:_T2('int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:19,difficulty:'сложно',title:'Приоритет операторов',
 description:'Вычислите <code>a + b * c - d / e % f</code>. Считайте 6 чисел и выведите результат.',
 hints:[_H2('*, / и % выполняются раньше + и -'),_H2('d/e%f = (d/e)%f (левая ассоциативность)'),_H2('printf("%d", a + b*c - d/e%f);')],
 testCases:[
  {input:'2 3 4 6 2 5',output:'11',hidden:false},
  {input:'1 2 5 10 3 4',output:'8',hidden:true},
  {input:'3 4 3 12 4 3',output:'15',hidden:true}
 ],
 initialCode:_T2('int a, b, c, d, e, f;\n    scanf("%d %d %d %d %d %d", &a, &b, &c, &d, &e, &f);\n    ')
},
{
 id:20,difficulty:'сложно',title:'Упаковка двух байтов',
 description:'Считайте <code>hi</code> (0–255) и <code>lo</code> (0–255). Упакуйте в одно число: <code>(hi &lt;&lt; 8) | lo</code>. Выведите результат.',
 hints:[_H2('hi << 8 сдвигает hi в старший байт'),_H2('| lo вставляет lo в младший байт'),_H2('printf("%d", (hi<<8)|lo);')],
 testCases:[
  {input:'1 0',output:'256',hidden:false},
  {input:'255 255',output:'65535',hidden:true},
  {input:'2 3',output:'515',hidden:true}
 ],
 initialCode:_T2('int hi, lo;\n    scanf("%d %d", &hi, &lo);\n    ')
},
{
 id:21,difficulty:'сложно',title:'Абсолютная разность без if',
 description:'Считайте два числа. Выведите модуль их разности. Без <code>if</code> и функции <code>abs</code>.',
 hints:[_H2('Тернарный оператор — не if: (a>b ? a-b : b-a)'),_H2('printf("%d", a>b ? a-b : b-a);')],
 testCases:[
  {input:'10 3',output:'7',hidden:false},
  {input:'3 10',output:'7',hidden:true},
  {input:'5 5',output:'0',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'НОД алгоритмом Евклида',
 description:'Считайте два натуральных числа. Найдите НОД итерационным алгоритмом Евклида через оператор <code>%</code>.',
 hints:[_H2('while (b != 0) { int t = b; b = a % b; a = t; }'),_H2('printf("%d", a);')],
 testCases:[
  {input:'12 8',output:'4',hidden:false},
  {input:'48 18',output:'6',hidden:true},
  {input:'100 75',output:'25',hidden:true}
 ],
 initialCode:_T2('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:24,difficulty:'супер',title:'Двоичное представление',
 description:'Считайте целое <code>n</code> (1–255). Выведите его двоичное представление ровно в 8 битах (без пробелов, без переноса строки).',
 hints:[_H2('Проверяй каждый бит от 7 до 0: (n >> i) & 1'),_H2('for (int i = 7; i >= 0; i--) printf("%d", (n>>i)&1);')],
 testCases:[
  {input:'5',output:'00000101',hidden:false},
  {input:'255',output:'11111111',hidden:true},
  {input:'128',output:'10000000',hidden:true}
 ],
 initialCode:_T2('int n, i;\n    scanf("%d", &n);\n    for (i = 7; i >= 0; i--) {\n        // выведи i-й бит\n    }')
}
];
