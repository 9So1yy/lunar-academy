window.TASKS=window.TASKS||{};
const _T3=(c)=>`#include <stdio.h>\n\nint main(void) {\n    ${c}\n    return 0;\n}\n`;
const _H3=(t)=>({text:t,penalty:5});

window.TASKS[3]=[
// ===== ЛЕГКО =====
{
 id:1,difficulty:'легко',title:'Чётное или нечётное',
 description:'Считайте целое число. Выведите <code>0</code> если чётное, <code>1</code> если нечётное.',
 hints:[_H3('if (n % 2 == 0) ...'),_H3('printf("%d", n % 2 == 0 ? 0 : 1);')],
 testCases:[
  {input:'4',output:'0',hidden:false},
  {input:'7',output:'1',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T3('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:2,difficulty:'легко',title:'Знак числа',
 description:'Считайте целое число. Выведите <code>1</code> (положительное), <code>-1</code> (отрицательное) или <code>0</code>.',
 hints:[_H3('Три ветки: if (n > 0) ... else if (n < 0) ... else ...')],
 testCases:[
  {input:'5',output:'1',hidden:false},
  {input:'-3',output:'-1',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T3('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:3,difficulty:'легко',title:'Максимум двух чисел',
 description:'Считайте два числа и выведите наибольшее.',
 hints:[_H3('if (a >= b) printf("%d", a); else printf("%d", b);')],
 testCases:[
  {input:'5 3',output:'5',hidden:false},
  {input:'2 8',output:'8',hidden:true},
  {input:'4 4',output:'4',hidden:true}
 ],
 initialCode:_T3('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:4,difficulty:'легко',title:'Минимум двух чисел',
 description:'Считайте два числа и выведите наименьшее.',
 hints:[_H3('if (a <= b) printf("%d", a); else printf("%d", b);')],
 testCases:[
  {input:'5 3',output:'3',hidden:false},
  {input:'2 8',output:'2',hidden:true},
  {input:'4 4',output:'4',hidden:true}
 ],
 initialCode:_T3('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:5,difficulty:'легко',title:'Делится ли на K',
 description:'Считайте <code>n</code> и <code>k</code>. Выведите <code>1</code> если n делится на k без остатка, иначе <code>0</code>.',
 hints:[_H3('if (n % k == 0) ...'),_H3('printf("%d", n % k == 0 ? 1 : 0);')],
 testCases:[
  {input:'12 3',output:'1',hidden:false},
  {input:'10 3',output:'0',hidden:true},
  {input:'0 7',output:'1',hidden:true}
 ],
 initialCode:_T3('int n, k;\n    scanf("%d %d", &n, &k);\n    ')
},
{
 id:6,difficulty:'легко',title:'Число в диапазоне',
 description:'Считайте <code>n</code>, <code>a</code>, <code>b</code>. Выведите <code>1</code> если a ≤ n ≤ b, иначе <code>0</code>.',
 hints:[_H3('if (n >= a && n <= b) ...'),_H3('printf("%d", (n>=a && n<=b) ? 1 : 0);')],
 testCases:[
  {input:'5 1 10',output:'1',hidden:false},
  {input:'15 1 10',output:'0',hidden:true},
  {input:'1 1 10',output:'1',hidden:true}
 ],
 initialCode:_T3('int n, a, b;\n    scanf("%d %d %d", &n, &a, &b);\n    ')
},
{
 id:7,difficulty:'легко',title:'Абсолютное значение через if',
 description:'Считайте целое число и выведите его абсолютное значение.',
 hints:[_H3('if (n < 0) n = -n;'),_H3('printf("%d", n);')],
 testCases:[
  {input:'-5',output:'5',hidden:false},
  {input:'3',output:'3',hidden:true},
  {input:'0',output:'0',hidden:true}
 ],
 initialCode:_T3('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:8,difficulty:'легко',title:'Результат сравнения',
 description:'Считайте <code>a</code> и <code>b</code>. Выведите <code>0</code> (a&lt;b), <code>1</code> (a==b) или <code>2</code> (a&gt;b).',
 hints:[_H3('if (a < b) ... else if (a == b) ... else ...')],
 testCases:[
  {input:'3 5',output:'0',hidden:false},
  {input:'5 5',output:'1',hidden:true},
  {input:'7 3',output:'2',hidden:true}
 ],
 initialCode:_T3('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:9,difficulty:'легко',title:'Трёхзначное число',
 description:'Считайте целое число. Выведите <code>1</code> если оно трёхзначное (100–999), иначе <code>0</code>.',
 hints:[_H3('if (n >= 100 && n <= 999) ...')],
 testCases:[
  {input:'100',output:'1',hidden:false},
  {input:'99',output:'0',hidden:true},
  {input:'1000',output:'0',hidden:true}
 ],
 initialCode:_T3('int n;\n    scanf("%d", &n);\n    ')
},
{
 id:10,difficulty:'легко',title:'Оба условия',
 description:'Считайте <code>n</code>. Выведите <code>1</code> если n чётное <b>и</b> больше 10, иначе <code>0</code>.',
 hints:[_H3('if (n % 2 == 0 && n > 10) ...')],
 testCases:[
  {input:'12',output:'1',hidden:false},
  {input:'4',output:'0',hidden:true},
  {input:'11',output:'0',hidden:true}
 ],
 initialCode:_T3('int n;\n    scanf("%d", &n);\n    ')
},
// ===== СРЕДНЕ =====
{
 id:11,difficulty:'средне',title:'Максимум трёх чисел',
 description:'Считайте три числа и выведите наибольшее.',
 hints:[_H3('int m = a; if (b > m) m = b; if (c > m) m = c;'),_H3('printf("%d", m);')],
 testCases:[
  {input:'5 3 8',output:'8',hidden:false},
  {input:'10 20 15',output:'20',hidden:true},
  {input:'7 7 7',output:'7',hidden:true}
 ],
 initialCode:_T3('int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:12,difficulty:'средне',title:'Медиана трёх чисел',
 description:'Считайте три числа и выведите медиану (среднее значение при сортировке по возрастанию).',
 hints:[_H3('Пузырьковая сортировка 3 элементов: swap(a,b); swap(b,c); swap(a,b); → b = медиана'),_H3('int t; if(a>b){t=a;a=b;b=t;} ...')],
 testCases:[
  {input:'3 1 2',output:'2',hidden:false},
  {input:'5 5 3',output:'5',hidden:true},
  {input:'10 20 15',output:'15',hidden:true}
 ],
 initialCode:_T3('int a, b, c, t;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:13,difficulty:'средне',title:'Квартал по месяцу',
 description:'Считайте номер месяца (1–12). Выведите номер квартала (1–4). При неверном вводе — <code>0</code>.',
 hints:[_H3('switch(m) { case 1: case 2: case 3: printf("1"); break; ... }'),_H3('1-3→Q1, 4-6→Q2, 7-9→Q3, 10-12→Q4')],
 testCases:[
  {input:'3',output:'1',hidden:false},
  {input:'7',output:'3',hidden:true},
  {input:'12',output:'4',hidden:true}
 ],
 initialCode:_T3('int m;\n    scanf("%d", &m);\n    switch (m) {\n        // case ...\n    }')
},
{
 id:14,difficulty:'средне',title:'Деление с защитой от нуля',
 description:'Считайте <code>a</code> и <code>b</code>. Если b=0 — вывести <code>0</code>, иначе — результат целочисленного деления a/b.',
 hints:[_H3('if (b == 0) printf("0"); else printf("%d", a/b);')],
 testCases:[
  {input:'10 2',output:'5',hidden:false},
  {input:'9 3',output:'3',hidden:true},
  {input:'5 0',output:'0',hidden:true}
 ],
 initialCode:_T3('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
{
 id:15,difficulty:'средне',title:'Существование треугольника',
 description:'Считайте три стороны. Выведите <code>1</code> если треугольник существует, <code>0</code> — если нет.',
 hints:[_H3('Каждая сторона должна быть меньше суммы двух других'),_H3('if (a+b>c && a+c>b && b+c>a) ...')],
 testCases:[
  {input:'3 4 5',output:'1',hidden:false},
  {input:'1 2 3',output:'0',hidden:true},
  {input:'5 5 5',output:'1',hidden:true}
 ],
 initialCode:_T3('int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:16,difficulty:'средне',title:'Тип треугольника',
 description:'Считайте три стороны. Выведите: <code>0</code> (не треугольник), <code>1</code> (равносторонний), <code>2</code> (равнобедренный), <code>3</code> (разносторонний).',
 hints:[_H3('Сначала проверь существование'),_H3('a==b && b==c → 1; два равны → 2; иначе → 3')],
 testCases:[
  {input:'5 5 5',output:'1',hidden:false},
  {input:'3 3 4',output:'2',hidden:true},
  {input:'3 4 5',output:'3',hidden:true}
 ],
 initialCode:_T3('int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:17,difficulty:'средне',title:'Знак произведения',
 description:'Считайте <code>a</code> и <code>b</code>. Выведите знак их произведения: <code>1</code>, <code>-1</code> или <code>0</code> — без умножения.',
 hints:[_H3('if (a==0 || b==0): 0'),_H3('else if ((a>0&&b>0)||(a<0&&b<0)): 1; else -1')],
 testCases:[
  {input:'3 5',output:'1',hidden:false},
  {input:'-2 4',output:'-1',hidden:true},
  {input:'0 7',output:'0',hidden:true}
 ],
 initialCode:_T3('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
},
// ===== СЛОЖНО =====
{
 id:18,difficulty:'сложно',title:'Дней в месяце',
 description:'Считайте месяц (1–12) и год. Выведите количество дней в этом месяце (с учётом высокосного года).',
 hints:[_H3('Высокосный: (y%4==0 && y%100!=0) || y%400==0'),_H3('Февраль: 28 или 29. Апр/Июн/Сен/Ноя — 30. Остальные — 31'),_H3('switch(month) { case 2: ... }')],
 testCases:[
  {input:'2 2000',output:'29',hidden:false},
  {input:'2 2001',output:'28',hidden:true},
  {input:'1 2023',output:'31',hidden:true}
 ],
 initialCode:_T3('int month, year;\n    scanf("%d %d", &month, &year);\n    ')
},
{
 id:19,difficulty:'сложно',title:'Кусочная функция',
 description:'Вычислите y для целого x:<ul><li>x &lt; 0 → y = x² + 1</li><li>0 ≤ x &lt; 5 → y = 2x + 1</li><li>x ≥ 5 → y = x − 4</li></ul>',
 hints:[_H3('if / else if / else с тремя ветками'),_H3('printf("%d", y);')],
 testCases:[
  {input:'-2',output:'5',hidden:false},
  {input:'3',output:'7',hidden:true},
  {input:'5',output:'1',hidden:true}
 ],
 initialCode:_T3('int x, y;\n    scanf("%d", &x);\n    ')
},
{
 id:20,difficulty:'сложно',title:'Корни квадратного уравнения',
 description:'Считайте <code>a</code>, <code>b</code>, <code>c</code>. Выведите количество вещественных корней: <code>0</code>, <code>1</code> или <code>2</code>. Если a=0 — выведите <code>-1</code>.',
 hints:[_H3('D = b*b - 4*a*c'),_H3('D<0 → 0 корней; D==0 → 1; D>0 → 2'),_H3('if (a==0) printf("-1"); else ...')],
 testCases:[
  {input:'1 -5 6',output:'2',hidden:false},
  {input:'1 2 1',output:'1',hidden:true},
  {input:'1 0 1',output:'0',hidden:true}
 ],
 initialCode:_T3('int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:21,difficulty:'сложно',title:'Налог на доход',
 description:'Считайте <code>income</code>. Налог: 0% (≤1000), 10% (1001–5000), 20% (&gt;5000). Выведите сумму налога (целое).',
 hints:[_H3('if (income <= 1000) tax = 0;'),_H3('else if (income <= 5000) tax = income * 10 / 100;'),_H3('else tax = income * 20 / 100;')],
 testCases:[
  {input:'500',output:'0',hidden:false},
  {input:'2000',output:'200',hidden:true},
  {input:'10000',output:'2000',hidden:true}
 ],
 initialCode:_T3('int income, tax;\n    scanf("%d", &income);\n    ')
},
{
 id:22,difficulty:'сложно',title:'Clamp — ограничение в диапазон',
 description:'Считайте <code>n</code>, <code>lo</code>, <code>hi</code>. Если n&lt;lo — вывести lo; если n&gt;hi — вывести hi; иначе — n.',
 hints:[_H3('if (n < lo) printf("%d", lo);'),_H3('else if (n > hi) printf("%d", hi); else printf("%d", n);')],
 testCases:[
  {input:'5 1 10',output:'5',hidden:false},
  {input:'-3 0 10',output:'0',hidden:true},
  {input:'15 0 10',output:'10',hidden:true}
 ],
 initialCode:_T3('int n, lo, hi;\n    scanf("%d %d %d", &n, &lo, &hi);\n    ')
},
// ===== СУПЕР =====
{
 id:23,difficulty:'супер',title:'Сортировка трёх чисел',
 description:'Считайте три числа и выведите через пробел в порядке возрастания. Используй только <code>if</code> и обмен переменных.',
 hints:[_H3('3 прохода: if(a>b) swap; if(b>c) swap; if(a>b) swap;'),_H3('Обмен: int t=a; a=b; b=t;'),_H3('printf("%d %d %d", a, b, c);')],
 testCases:[
  {input:'3 1 2',output:'1 2 3',hidden:false},
  {input:'5 5 3',output:'3 5 5',hidden:true},
  {input:'10 20 15',output:'10 15 20',hidden:true}
 ],
 initialCode:_T3('int a, b, c, t;\n    scanf("%d %d %d", &a, &b, &c);\n    ')
},
{
 id:24,difficulty:'супер',title:'Решение линейного уравнения',
 description:'Считайте <code>a</code> и <code>b</code> (ax = b). Вывести: <code>-1</code> (a=0,b=0 — бесконечно), <code>-2</code> (a=0,b≠0 — нет решения), иначе b/a (целое).',
 hints:[_H3('Сначала if (a == 0)'),_H3('printf("%d", b / a);')],
 testCases:[
  {input:'2 6',output:'3',hidden:false},
  {input:'0 0',output:'-1',hidden:true},
  {input:'0 5',output:'-2',hidden:true}
 ],
 initialCode:_T3('int a, b;\n    scanf("%d %d", &a, &b);\n    ')
}
];
