window.THEORY=window.THEORY||{};
window.THEORY[19]={
intro:"Указатели на функции позволяют хранить функцию в переменной, передавать её как параметр, выбирать поведение во время выполнения. Это основа callback-ов, плагинов, виртуальных функций.",
sections:[
{title:"Синтаксис",content:`
<p>Объявление указателя на функцию выглядит непривычно — функция в скобках, чтобы отличить от обычного указателя:</p>
<div class="code"><span class="cmt">// функция: int → int → int</span>
<span class="kw">int</span> <span class="fn">add</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) { <span class="kw">return</span> a + b; }

<span class="cmt">// указатель на такую функцию</span>
<span class="kw">int</span> (*op)(<span class="kw">int</span>, <span class="kw">int</span>);

op = add;                <span class="cmt">// присваиваем функцию</span>
<span class="kw">int</span> r = op(<span class="num">3</span>, <span class="num">4</span>);       <span class="cmt">// вызов через указатель → 7</span>
<span class="kw">int</span> r2 = (*op)(<span class="num">3</span>, <span class="num">4</span>);    <span class="cmt">// то же самое — старый синтаксис</span></div>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body">Объявление читается «изнутри наружу»: <code>(*op)</code> — это указатель; <code>(*op)(int,int)</code> — указатель на функцию двух int; <code>int (*op)(int,int)</code> — возвращает int.</div></div>`},
{title:"Callback-функции",content:`
<p>Указатели на функции часто используются для <b>callback</b> — передаваемых функций, которые библиотека вызывает в нужный момент.</p>
<div class="code"><span class="kw">void</span> <span class="fn">apply</span>(<span class="kw">int</span>* arr, <span class="kw">int</span> n, <span class="kw">int</span> (*f)(<span class="kw">int</span>)) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++)
        arr[i] = f(arr[i]);
}

<span class="kw">int</span> <span class="fn">square</span>(<span class="kw">int</span> x) { <span class="kw">return</span> x * x; }
<span class="kw">int</span> <span class="fn">negate</span>(<span class="kw">int</span> x) { <span class="kw">return</span> -x; }

<span class="fn">apply</span>(arr, n, square);   <span class="cmt">// все элементы в квадрат</span>
<span class="fn">apply</span>(arr, n, negate);   <span class="cmt">// все знаки сменить</span></div>
<h3>qsort — классический пример</h3>
<div class="code"><span class="kw">int</span> <span class="fn">cmp</span>(<span class="kw">const</span> <span class="kw">void</span>* a, <span class="kw">const</span> <span class="kw">void</span>* b) {
    <span class="kw">return</span> *(<span class="kw">int</span>*)a - *(<span class="kw">int</span>*)b;
}
<span class="fn">qsort</span>(arr, n, <span class="kw">sizeof</span>(<span class="kw">int</span>), cmp);  <span class="cmt">// cmp — это callback</span></div>`},
{title:"Таблицы функций",content:`
<p>Массив указателей на функции — это способ заменить большой <code>switch</code> на индекс в таблице:</p>
<div class="code"><span class="kw">int</span> <span class="fn">add</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) { <span class="kw">return</span> a + b; }
<span class="kw">int</span> <span class="fn">sub</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) { <span class="kw">return</span> a - b; }
<span class="kw">int</span> <span class="fn">mul</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) { <span class="kw">return</span> a * b; }
<span class="kw">int</span> <span class="fn">divv</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) { <span class="kw">return</span> a / b; }

<span class="kw">int</span> (*ops[<span class="num">4</span>])(<span class="kw">int</span>, <span class="kw">int</span>) = {add, sub, mul, divv};

<span class="kw">int</span> r = ops[<span class="num">2</span>](<span class="num">6</span>, <span class="num">7</span>);  <span class="cmt">// mul(6,7) = 42</span></div>
<p>Это даёт O(1) выбор операции и легко расширяется.</p>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body">Так в C реализуют примитивный полиморфизм: структура хранит указатели на «методы», и разные «классы» подставляют свои реализации.</div></div>`}
],
keyPoints:[
"<code>int (*p)(int)</code> — указатель на функцию, принимающую int и возвращающую int",
"Имя функции в C само по себе уже указатель на её код",
"Вызов: <code>p(args)</code> или <code>(*p)(args)</code> — эквивалентно",
"<b>Callback</b> — функция, передаваемая как параметр другой функции",
"<code>qsort</code>, <code>bsearch</code> используют callback-компараторы",
"Массив указателей на функции = диспетчерная таблица"
]
};
