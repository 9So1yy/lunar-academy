window.THEORY=window.THEORY||{};
window.THEORY[8]={
intro:"<code>struct</code>, <code>union</code> и <code>enum</code> — три способа создать пользовательские типы. struct группирует разнотипные поля, union экономит память, enum даёт именованные константы.",
sections:[
{title:"struct — структура",content:`
<p>Объединяет несколько полей разных типов под одним именем:</p>
<div class="code"><span class="kw">struct</span> Point {
    <span class="kw">int</span> x;
    <span class="kw">int</span> y;
};

<span class="kw">struct</span> Point p = {<span class="num">3</span>, <span class="num">4</span>};
<span class="fn">printf</span>(<span class="str">"%d %d\\n"</span>, p.x, p.y);</div>
<p>С <code>typedef</code> удобнее:</p>
<div class="code"><span class="kw">typedef</span> <span class="kw">struct</span> {
    <span class="kw">char</span> name[<span class="num">50</span>];
    <span class="kw">int</span> age;
    <span class="kw">double</span> gpa;
} Student;

Student s = {<span class="str">"Иван"</span>, <span class="num">20</span>, <span class="num">3.8</span>};</div>
<p>Доступ через указатель — стрелочка:</p>
<div class="code">Student* ps = &amp;s;
<span class="fn">printf</span>(<span class="str">"%s"</span>, ps-&gt;name);   <span class="cmt">// эквивалентно (*ps).name</span></div>`},
{title:"union — объединение",content:`
<p>Похоже на struct, но все поля <b>занимают одну и ту же память</b>. Размер union = размер самого большого поля.</p>
<div class="code"><span class="kw">union</span> Data {
    <span class="kw">int</span> i;
    <span class="kw">float</span> f;
    <span class="kw">char</span> str[<span class="num">20</span>];
};

<span class="kw">union</span> Data d;
d.i = <span class="num">10</span>;
<span class="fn">printf</span>(<span class="str">"%d"</span>, d.i);    <span class="cmt">// 10</span>
d.f = <span class="num">3.14</span>;
<span class="fn">printf</span>(<span class="str">"%f"</span>, d.f);    <span class="cmt">// 3.14, но d.i теперь мусор!</span></div>
<p>Используется для variant-типов, экономии памяти, низкоуровневых трюков.</p>`},
{title:"enum — перечисление",content:`
<p>Набор именованных целочисленных констант:</p>
<div class="code"><span class="kw">enum</span> Day { MON, TUE, WED, THU, FRI, SAT, SUN };
<span class="kw">enum</span> Day today = WED;
<span class="fn">printf</span>(<span class="str">"%d"</span>, today);   <span class="cmt">// 2 (отсчёт с нуля)</span></div>
<p>Можно задавать значения вручную:</p>
<div class="code"><span class="kw">enum</span> Status { OK = <span class="num">200</span>, NOT_FOUND = <span class="num">404</span>, ERROR = <span class="num">500</span> };</div>
<p>Хорошо подходит для switch:</p>
<div class="code"><span class="kw">switch</span> (today) {
    <span class="kw">case</span> MON: ... <span class="kw">break</span>;
    <span class="kw">case</span> SAT:
    <span class="kw">case</span> SUN: <span class="fn">printf</span>(<span class="str">"Выходной"</span>); <span class="kw">break</span>;
}</div>`}
],
keyPoints:[
"<code>struct</code> — группа полей разных типов в одной памяти",
"<code>union</code> — все поля разделяют одну память, размер = max поля",
"<code>enum</code> — именованные целочисленные константы",
"<code>typedef</code> позволяет дать структуре короткое имя",
"Доступ к полю через <code>.</code>, через указатель — <code>-&gt;</code>",
"Передавайте структуры по указателю — экономит копирование"
]
};
