window.THEORY=window.THEORY||{};
window.THEORY[20]={
intro:"Оптимизация — это искусство. Главное правило: «преждевременная оптимизация — корень всех зол». Сначала пишите ясный, корректный код. Оптимизируйте только узкие места, найденные профилированием.",
sections:[
{title:"Компилятор работает за вас",content:`
<p>Современные компиляторы (<code>gcc</code>, <code>clang</code>) очень умные. С флагами <code>-O2</code> или <code>-O3</code> они выполняют десятки оптимизаций:</p>
<ul>
 <li><b>Inline</b> — встраивание мелких функций в место вызова;</li>
 <li><b>Loop unrolling</b> — разворот циклов;</li>
 <li><b>Constant folding</b> — вычисление констант на этапе сборки;</li>
 <li><b>Dead code elimination</b> — удаление недостижимого кода;</li>
 <li><b>SIMD</b> — векторизация операций над массивами;</li>
 <li><b>Tail call</b> — оптимизация хвостовых вызовов.</li>
</ul>
<table>
 <tr><th>Флаг</th><th>Что делает</th></tr>
 <tr><td><code>-O0</code></td><td>без оптимизаций, для отладки</td></tr>
 <tr><td><code>-O1</code></td><td>базовая оптимизация</td></tr>
 <tr><td><code>-O2</code></td><td>умеренная (стандарт для релиза)</td></tr>
 <tr><td><code>-O3</code></td><td>агрессивная (может раздуть код)</td></tr>
 <tr><td><code>-Os</code></td><td>оптимизация размера</td></tr>
</table>`},
{title:"Профилирование, потом оптимизация",content:`
<div class="box danger"><div class="box-ic">🚫</div><div class="box-body"><b>Не угадывайте</b>, что медленно. 90% времени программа проводит в 10% кода. Профилируйте: <code>gprof</code>, <code>perf</code>, <code>valgrind --tool=callgrind</code>.</div></div>
<h3>Что обычно медленно</h3>
<ul>
 <li><b>Сложность алгоритма</b> — O(n²) на больших данных всегда хуже, чем O(n log n).</li>
 <li><b>Системные вызовы</b> — открытие файлов, сеть, malloc.</li>
 <li><b>Кэш-промахи</b> — обращения к памяти, разбросанной по адресам.</li>
 <li><b>Ветвления</b> — непредсказуемые if внутри циклов.</li>
</ul>
<h3>Подсказки для компилятора</h3>
<div class="code"><span class="kw">inline</span> <span class="kw">int</span> <span class="fn">small</span>(<span class="kw">int</span> x) { <span class="kw">return</span> x + <span class="num">1</span>; }
<span class="kw">static</span> <span class="kw">inline</span> ... <span class="cmt">// предлагаем встроить</span>
<span class="kw">const</span> <span class="kw">int</span> N = <span class="num">1000</span>;       <span class="cmt">// компилятор знает, что значение не меняется</span>
<span class="kw">register</span> <span class="kw">int</span> i;            <span class="cmt">// устар. — компилятор и так разместит в регистре</span>
<span class="kw">restrict</span>                   <span class="cmt">// гарантия, что указатель — единственный</span></div>`},
{title:"Кэш-дружественность",content:`
<p>Современные CPU гораздо быстрее памяти. Программа, работающая «в кэше» в 100 раз быстрее, чем та же программа с промахами кэша.</p>
<div class="code"><span class="cmt">// Хорошо: обход массива по порядку (row-major)</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; N; i++)
    <span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">0</span>; j &lt; M; j++)
        sum += a[i][j];

<span class="cmt">// Плохо: переключение между строками</span>
<span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">0</span>; j &lt; M; j++)
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; N; i++)
        sum += a[i][j];   <span class="cmt">// прыгаем по памяти, промахи кэша</span></div>
<h3>Чек-лист оптимизации</h3>
<ol>
 <li>Сначала код работает <b>правильно</b>.</li>
 <li>Затем компилируйте с <code>-O2</code>.</li>
 <li>Профилируйте, найдите узкое место.</li>
 <li>Подумайте про <b>алгоритм</b> — это даёт больший выигрыш, чем микро-оптимизации.</li>
 <li>Только потом — мелкие трюки.</li>
 <li>Измеряйте результат. Если стало быстрее на 0.5% — не стоило.</li>
</ol>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body"><b>Дональд Кнут:</b> «Преждевременная оптимизация — корень всех зол». Сначала ясность, потом скорость.</div></div>`}
],
keyPoints:[
"Компилятор с <code>-O2</code>/<code>-O3</code> делает огромную работу за вас",
"Оптимизируйте только то, что измерили как узкое место",
"Сложность алгоритма важнее микро-оптимизаций",
"Кэш-промахи могут замедлить программу в 100 раз",
"Обходите массивы в порядке памяти (последовательно)",
"<code>inline</code>, <code>const</code>, <code>restrict</code> помогают компилятору",
"«Преждевременная оптимизация — корень всех зол» — Кнут"
]
};
