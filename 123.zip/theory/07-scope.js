window.THEORY=window.THEORY||{};
window.THEORY[7]={
intro:"Область видимости определяет, где переменная доступна в программе. C различает локальные, глобальные и блочные переменные, а также имеет ключевые слова <code>static</code> и <code>extern</code> для тонкого контроля.",
sections:[
{title:"Локальные и глобальные",content:`
<p><b>Локальная</b> переменная видна только внутри функции (или блока), где объявлена. Создаётся при входе, уничтожается при выходе.</p>
<p><b>Глобальная</b> объявляется вне функций — видна всему файлу с момента объявления.</p>
<div class="code"><span class="kw">int</span> counter = <span class="num">0</span>;          <span class="cmt">// глобальная</span>

<span class="kw">void</span> <span class="fn">tick</span>(<span class="kw">void</span>) {
    counter++;             <span class="cmt">// видна здесь</span>
    <span class="kw">int</span> local = <span class="num">42</span>;        <span class="cmt">// локальная — только в tick</span>
}</div>
<div class="box warn"><div class="box-ic">⚠️</div><div class="box-body">Глобальные переменные — это <b>глобальное состояние</b>. Усложняют отладку и тестирование. Используйте их экономно.</div></div>`},
{title:"Блочная область",content:`
<p>Каждые фигурные скобки <code>{}</code> создают новый блок:</p>
<div class="code"><span class="kw">int</span> x = <span class="num">10</span>;
{
    <span class="kw">int</span> x = <span class="num">20</span>;       <span class="cmt">// другая переменная, перекрывает внешнюю</span>
    <span class="fn">printf</span>(<span class="str">"%d\\n"</span>, x); <span class="cmt">// 20</span>
}
<span class="fn">printf</span>(<span class="str">"%d\\n"</span>, x);    <span class="cmt">// 10 — снова внешняя</span></div>
<p>Это также работает в <code>for</code> и <code>if</code>: переменная, объявленная в условии или теле, существует только там.</p>`},
{title:"static и extern",content:`
<h3>static в функции</h3>
<p>Сохраняет значение между вызовами:</p>
<div class="code"><span class="kw">int</span> <span class="fn">nextId</span>(<span class="kw">void</span>) {
    <span class="kw">static</span> <span class="kw">int</span> id = <span class="num">0</span>;   <span class="cmt">// инициализируется один раз</span>
    <span class="kw">return</span> ++id;
}
<span class="fn">nextId</span>(); <span class="cmt">// 1</span>
<span class="fn">nextId</span>(); <span class="cmt">// 2</span>
<span class="fn">nextId</span>(); <span class="cmt">// 3</span></div>
<h3>static на уровне файла</h3>
<p>Ограничивает видимость <b>только текущим файлом</b>. Хорошо для приватных функций.</p>
<h3>extern</h3>
<p>Говорит компилятору: «эта переменная объявлена в другом файле». Используется в заголовках.</p>`}
],
keyPoints:[
"Локальные переменные живут только внутри своей функции/блока",
"Глобальные доступны всем функциям файла, но усложняют код",
"<code>static</code> внутри функции сохраняет значение между вызовами",
"<code>static</code> на уровне файла прячет переменную от других файлов",
"<code>extern</code> объявляет переменную, определённую в другом файле",
"Внутренний блок может «затенить» внешнюю переменную"
]
};
