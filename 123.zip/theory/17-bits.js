window.THEORY=window.THEORY||{};
window.THEORY[17]={
intro:"Битовые операции работают напрямую с битами целых чисел. Они нужны для упаковки данных, флагов, оптимизации, криптографии, графики, низкоуровневого программирования.",
sections:[
{title:"Операторы",content:`
<table>
 <tr><th>Оп.</th><th>Действие</th><th>Пример</th><th>Результат</th></tr>
 <tr><td><code>&amp;</code></td><td>AND — оба бита 1</td><td><code>0b1100 &amp; 0b1010</code></td><td><code>0b1000</code> = 8</td></tr>
 <tr><td><code>|</code></td><td>OR — хотя бы один 1</td><td><code>0b1100 | 0b1010</code></td><td><code>0b1110</code> = 14</td></tr>
 <tr><td><code>^</code></td><td>XOR — биты разные</td><td><code>0b1100 ^ 0b1010</code></td><td><code>0b0110</code> = 6</td></tr>
 <tr><td><code>~</code></td><td>NOT — инверсия</td><td><code>~0b1100</code></td><td><code>...0011</code></td></tr>
 <tr><td><code>&lt;&lt;</code></td><td>сдвиг влево</td><td><code>1 &lt;&lt; 3</code></td><td>8 (= 2³)</td></tr>
 <tr><td><code>&gt;&gt;</code></td><td>сдвиг вправо</td><td><code>16 &gt;&gt; 2</code></td><td>4 (= 16/2²)</td></tr>
</table>
<div class="box warn"><div class="box-ic">⚠️</div><div class="box-body">Не путайте: <code>&amp;</code> — битовое И, <code>&amp;&amp;</code> — логическое И. Разные операторы.</div></div>`},
{title:"Работа с битами",content:`
<div class="code"><span class="cmt">// Установить n-й бит в 1</span>
x |= (<span class="num">1</span> &lt;&lt; n);

<span class="cmt">// Очистить n-й бит (поставить в 0)</span>
x &amp;= ~(<span class="num">1</span> &lt;&lt; n);

<span class="cmt">// Переключить n-й бит</span>
x ^= (<span class="num">1</span> &lt;&lt; n);

<span class="cmt">// Проверить n-й бит</span>
<span class="kw">if</span> (x &amp; (<span class="num">1</span> &lt;&lt; n)) { <span class="cmt">/* установлен */</span> }

<span class="cmt">// Прочитать значение бита (0 или 1)</span>
<span class="kw">int</span> bit = (x &gt;&gt; n) &amp; <span class="num">1</span>;</div>
<h3>Флаги</h3>
<div class="code"><span class="pp">#define</span> READ  (<span class="num">1</span>&lt;&lt;<span class="num">0</span>)   <span class="cmt">// 0001</span>
<span class="pp">#define</span> WRITE (<span class="num">1</span>&lt;&lt;<span class="num">1</span>)   <span class="cmt">// 0010</span>
<span class="pp">#define</span> EXEC  (<span class="num">1</span>&lt;&lt;<span class="num">2</span>)   <span class="cmt">// 0100</span>

<span class="kw">int</span> perm = READ | WRITE;          <span class="cmt">// 0011</span>
<span class="kw">if</span> (perm &amp; READ) { ... }          <span class="cmt">// проверка</span>
perm &amp;= ~WRITE;                   <span class="cmt">// сбросить</span></div>`},
{title:"Полезные трюки",content:`
<ul>
 <li><b>Чётность:</b> <code>x &amp; 1</code> → 1 если нечётное.</li>
 <li><b>Умножение/деление на 2ⁿ:</b> <code>x &lt;&lt; n</code> / <code>x &gt;&gt; n</code>.</li>
 <li><b>Степень двойки:</b> <code>x &amp; (x-1) == 0</code> (для x &gt; 0).</li>
 <li><b>Сбросить младший установленный бит:</b> <code>x &amp; (x-1)</code>.</li>
 <li><b>Только младший установленный бит:</b> <code>x &amp; -x</code>.</li>
 <li><b>Обмен без temp:</b> <code>a ^= b; b ^= a; a ^= b;</code></li>
</ul>
<h3>Подсчёт единичных битов</h3>
<div class="code"><span class="kw">int</span> <span class="fn">popcount</span>(<span class="kw">unsigned</span> n) {
    <span class="kw">int</span> c = <span class="num">0</span>;
    <span class="kw">while</span> (n) { c += n &amp; <span class="num">1</span>; n &gt;&gt;= <span class="num">1</span>; }
    <span class="kw">return</span> c;
}
<span class="cmt">// Быстрее (Кernighan):</span>
<span class="kw">while</span> (n) { c++; n &amp;= n - <span class="num">1</span>; }</div>`}
],
keyPoints:[
"<code>&amp; | ^ ~</code> — битовые операторы (не путать с <code>&amp;&amp; ||</code>)",
"<code>&lt;&lt; n</code> = умножить на 2ⁿ, <code>&gt;&gt; n</code> = разделить",
"<code>x | (1&lt;&lt;n)</code> установить, <code>x &amp; ~(1&lt;&lt;n)</code> сбросить, <code>x ^ (1&lt;&lt;n)</code> переключить",
"Флаги — компактный способ хранить набор bool-значений",
"<code>x &amp; (x-1)</code> сбрасывает младший установленный бит",
"Битовые операции очень быстрые — используются в hot path"
]
};
