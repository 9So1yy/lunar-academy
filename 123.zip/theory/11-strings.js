window.THEORY=window.THEORY||{};
window.THEORY[11]={
intro:"В C нет встроенного типа «строка». Строка — это массив символов <code>char</code>, заканчивающийся нулевым символом <code>'\\0'</code>. Понимание этого факта — ключ к работе со строками в C.",
sections:[
{title:"Символы как числа",content:`
<p>Тип <code>char</code> — это 1 байт, который интерпретируется как символ по таблице <b>ASCII</b>. Внутри это обычное целое число.</p>
<div class="code"><span class="kw">char</span> c = <span class="str">'A'</span>;
<span class="fn">printf</span>(<span class="str">"%c\\n"</span>, c);   <span class="cmt">// A</span>
<span class="fn">printf</span>(<span class="str">"%d\\n"</span>, c);   <span class="cmt">// 65 — ASCII код</span>

<span class="kw">char</span> next = c + <span class="num">1</span>;  <span class="cmt">// 'B'</span></div>
<h3>Полезные диапазоны ASCII</h3>
<table>
 <tr><th>Символы</th><th>Коды</th></tr>
 <tr><td><code>0</code>…<code>9</code></td><td>48…57</td></tr>
 <tr><td><code>A</code>…<code>Z</code></td><td>65…90</td></tr>
 <tr><td><code>a</code>…<code>z</code></td><td>97…122</td></tr>
 <tr><td>пробел</td><td>32</td></tr>
 <tr><td><code>\\n</code></td><td>10</td></tr>
</table>
<p>Разница между прописной и строчной буквой ровно 32: <code>'a' - 'A' == 32</code>.</p>`},
{title:"Строки в C",content:`
<p>Строка — это массив <code>char</code> с <b>нуль-терминатором</b> <code>'\\0'</code>:</p>
<div class="code"><span class="kw">char</span> s1[] = <span class="str">"Hello"</span>;          <span class="cmt">// массив из 6 байт: H,e,l,l,o,\\0</span>
<span class="kw">char</span> s2[<span class="num">20</span>] = <span class="str">"World"</span>;       <span class="cmt">// массив из 20 байт</span>
<span class="kw">char</span>* s3 = <span class="str">"Static"</span>;          <span class="cmt">// указатель на литерал — менять нельзя!</span>
<span class="kw">char</span> s4[<span class="num">6</span>] = {<span class="str">'H'</span>,<span class="str">'i'</span>,<span class="str">'\\0'</span>}; <span class="cmt">// посимвольно</span></div>
<div class="box danger"><div class="box-ic">🚫</div><div class="box-body">Без <code>'\\0'</code> функции вроде <code>printf("%s", ...)</code> будут читать память за пределами массива, пока не наткнутся на ноль. Это UB.</div></div>
<h3>Чтение и вывод</h3>
<div class="code"><span class="kw">char</span> name[<span class="num">100</span>];
<span class="fn">scanf</span>(<span class="str">"%s"</span>, name);          <span class="cmt">// читает слово до пробела (без &amp;!)</span>
<span class="fn">fgets</span>(name, <span class="num">100</span>, stdin);   <span class="cmt">// безопаснее — со строкой и пробелами</span>
<span class="fn">printf</span>(<span class="str">"%s"</span>, name);</div>`},
{title:"ctype.h — проверки символов",content:`
<p>Заголовок <code>&lt;ctype.h&gt;</code> содержит удобные функции для проверки и преобразования символов:</p>
<table>
 <tr><th>Функция</th><th>Возвращает true если…</th></tr>
 <tr><td><code>isdigit(c)</code></td><td>цифра 0-9</td></tr>
 <tr><td><code>isalpha(c)</code></td><td>буква</td></tr>
 <tr><td><code>isalnum(c)</code></td><td>буква или цифра</td></tr>
 <tr><td><code>isspace(c)</code></td><td>пробел, таб, перенос</td></tr>
 <tr><td><code>isupper(c)</code></td><td>заглавная</td></tr>
 <tr><td><code>islower(c)</code></td><td>строчная</td></tr>
 <tr><td><code>toupper(c)</code></td><td>в верхний регистр</td></tr>
 <tr><td><code>tolower(c)</code></td><td>в нижний регистр</td></tr>
</table>
<div class="code"><span class="pp">#include</span> &lt;<span class="str">ctype.h</span>&gt;

<span class="kw">char</span> c = <span class="str">'a'</span>;
<span class="kw">if</span> (<span class="fn">isalpha</span>(c)) {
    c = <span class="fn">toupper</span>(c);    <span class="cmt">// 'A'</span>
}</div>`}
],
keyPoints:[
"<code>char</code> — это просто целое число, интерпретируемое как символ ASCII",
"Строка в C = массив char + завершающий <code>'\\0'</code>",
"Без нуль-терминатора строковые функции продолжат читать память — UB",
"<code>scanf(\"%s\", buf)</code> читает до пробела, размер не контролирует",
"Используйте <code>fgets</code> для безопасного чтения строк с пробелами",
"<code>ctype.h</code> даёт удобные проверки и преобразования символов"
]
};
