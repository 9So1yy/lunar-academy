window.THEORY=window.THEORY||{};
window.THEORY[10]={
intro:"До сих пор память выделялась автоматически на стеке. Динамическая память (куча) запрашивается во время выполнения через <code>malloc</code> и должна быть освобождена через <code>free</code>. Это позволяет работать с данными, размер которых неизвестен заранее.",
sections:[
{title:"Стек vs куча",content:`
<table>
 <tr><th></th><th>Стек</th><th>Куча</th></tr>
 <tr><td>Размер</td><td>Известен на компиляции</td><td>Любой, во время работы</td></tr>
 <tr><td>Управление</td><td>Авто (по выходу из блока)</td><td>Ручное (malloc/free)</td></tr>
 <tr><td>Скорость</td><td>Очень быстро</td><td>Медленнее</td></tr>
 <tr><td>Размер блока</td><td>~1-8 МБ</td><td>Ограничен RAM</td></tr>
</table>`},
{title:"malloc, calloc, realloc, free",content:`
<div class="code"><span class="pp">#include</span> &lt;<span class="str">stdlib.h</span>&gt;

<span class="kw">int</span>* arr = (<span class="kw">int</span>*)<span class="fn">malloc</span>(<span class="num">10</span> * <span class="kw">sizeof</span>(<span class="kw">int</span>));
<span class="kw">if</span> (arr == <span class="kw">NULL</span>) { <span class="cmt">/* нет памяти */</span> <span class="kw">return</span> <span class="num">1</span>; }

<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; <span class="num">10</span>; i++) arr[i] = i * i;

<span class="fn">free</span>(arr);      <span class="cmt">// освобождаем!</span>
arr = <span class="kw">NULL</span>;    <span class="cmt">// чтобы не использовать случайно</span></div>
<ul>
 <li><code>malloc(n)</code> — выделить n байт, содержимое мусорное</li>
 <li><code>calloc(k, n)</code> — выделить k×n байт, обнулённых</li>
 <li><code>realloc(p, n)</code> — изменить размер блока (может перенести в новое место!)</li>
 <li><code>free(p)</code> — освободить</li>
</ul>`},
{title:"Распространённые ошибки",content:`
<ul>
 <li><b>Утечка памяти</b> — malloc без free. Со временем съедает память программы.</li>
 <li><b>Double free</b> — повторный free того же указателя — UB.</li>
 <li><b>Use-after-free</b> — обращение к указателю после free.</li>
 <li><b>Забытая проверка на NULL</b> — malloc может не выделить память.</li>
</ul>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body"><b>Правило</b>: на каждый malloc должен быть ровно один free. Используйте инструменты типа valgrind для проверки.</div></div>`}
],
keyPoints:[
"Стек — автоматический, куча — ручное управление через malloc/free",
"Обязательно проверяйте malloc на NULL",
"На каждый malloc должен быть один free",
"<code>realloc</code> может вернуть новый адрес — используйте возврат",
"После <code>free()</code> присваивайте указателю NULL",
"Утечка памяти — невидимый, но опасный баг"
]
};
