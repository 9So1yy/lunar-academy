window.THEORY=window.THEORY||{};
window.THEORY[18]={
intro:"Препроцессор — программа, которая обрабатывает исходник <b>до</b> компиляции. Он подставляет файлы, раскрывает макросы, выбирает части кода. Все команды препроцессора начинаются с <code>#</code> и не заканчиваются точкой с запятой.",
sections:[
{title:"#include и #define",content:`
<h3>Подключение файлов</h3>
<div class="code"><span class="pp">#include</span> &lt;<span class="str">stdio.h</span>&gt;     <span class="cmt">// системный путь</span>
<span class="pp">#include</span> <span class="str">"my.h"</span>         <span class="cmt">// относительно текущего файла</span></div>
<p>Препроцессор просто <b>вставляет содержимое файла</b> на место директивы.</p>
<h3>Макроконстанты</h3>
<div class="code"><span class="pp">#define</span> PI <span class="num">3.14159</span>
<span class="pp">#define</span> MAX_SIZE <span class="num">100</span>
<span class="pp">#define</span> AUTHOR <span class="str">"Иван"</span>

<span class="fn">printf</span>(<span class="str">"%.2f x %d, by %s\\n"</span>, PI, MAX_SIZE, AUTHOR);</div>
<h3>Макрофункции</h3>
<div class="code"><span class="pp">#define</span> SQUARE(x) ((x)*(x))
<span class="pp">#define</span> MAX(a,b) ((a)&gt;(b)?(a):(b))

<span class="kw">int</span> r = <span class="fn">SQUARE</span>(<span class="num">3</span>);       <span class="cmt">// = 9</span>
<span class="kw">int</span> m = <span class="fn">MAX</span>(<span class="num">5</span>, <span class="num">8</span>);       <span class="cmt">// = 8</span></div>
<div class="box danger"><div class="box-ic">🚫</div><div class="box-body"><b>Скобки в макросах — обязательны!</b> Без них <code>SQUARE(2+3)</code> раскроется как <code>2+3*2+3 = 11</code>, а не 25. Скобки вокруг <i>каждого</i> аргумента и вокруг <i>всего</i> выражения.</div></div>`},
{title:"Условная компиляция",content:`
<p>Позволяет включать/исключать куски кода во время компиляции:</p>
<div class="code"><span class="pp">#define</span> DEBUG

<span class="pp">#ifdef</span> DEBUG
    <span class="fn">printf</span>(<span class="str">"x = %d\\n"</span>, x);
<span class="pp">#endif</span>

<span class="pp">#if</span> VERSION &gt;= <span class="num">2</span>
    <span class="cmt">// новая логика</span>
<span class="pp">#elif</span> VERSION == <span class="num">1</span>
    <span class="cmt">// старая логика</span>
<span class="pp">#else</span>
    <span class="pp">#error</span> <span class="str">"Unknown version"</span>
<span class="pp">#endif</span></code></div>
<h3>Header guards</h3>
<p>Защита от множественного включения одного заголовка:</p>
<div class="code"><span class="cmt">// my.h</span>
<span class="pp">#ifndef</span> MY_H
<span class="pp">#define</span> MY_H

<span class="cmt">// объявления...</span>

<span class="pp">#endif</span></div>
<p>Современная альтернатива (поддерживается всеми компиляторами): <code>#pragma once</code>.</p>`},
{title:"Предопределённые макросы",content:`
<table>
 <tr><th>Макрос</th><th>Значение</th></tr>
 <tr><td><code>__FILE__</code></td><td>имя текущего файла</td></tr>
 <tr><td><code>__LINE__</code></td><td>номер строки</td></tr>
 <tr><td><code>__DATE__</code></td><td>дата сборки</td></tr>
 <tr><td><code>__TIME__</code></td><td>время сборки</td></tr>
 <tr><td><code>__func__</code></td><td>имя функции (C99+)</td></tr>
 <tr><td><code>__STDC_VERSION__</code></td><td>версия стандарта C</td></tr>
</table>
<div class="code"><span class="pp">#define</span> LOG(msg) <span class="fn">printf</span>(<span class="str">"[%s:%d] %s\\n"</span>, __FILE__, __LINE__, msg)
<span class="fn">LOG</span>(<span class="str">"started"</span>);
<span class="cmt">// → [main.c:42] started</span></div>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body">Макросы — мощный, но опасный инструмент. Современный C-код предпочитает <code>const</code>, <code>inline</code>-функции и <code>enum</code> вместо <code>#define</code> где возможно.</div></div>`}
],
keyPoints:[
"Препроцессор работает <b>до</b> компиляции — просто текстовая замена",
"<code>#include</code> вставляет содержимое файла",
"<code>#define X V</code> создаёт макроконстанту",
"В макрофункциях обязательны <b>скобки</b> вокруг аргументов и результата",
"<code>#ifdef/#endif</code> для условной компиляции (debug, версии)",
"Header guards защищают от двойного включения",
"<code>__FILE__</code>, <code>__LINE__</code> полезны для логирования"
]
};
