window.THEORY=window.THEORY||{};
window.THEORY[6]={
intro:"Функции — это именованные блоки кода, которые можно вызывать многократно. Разбиение программы на функции делает её читаемой, переиспользуемой и тестируемой.",
sections:[
{title:"Определение и вызов",content:`
<p>Функция в C объявляется через её <b>сигнатуру</b>: тип возвращаемого значения, имя, параметры в скобках, тело в фигурных скобках.</p>
<div class="code"><span class="kw">int</span> <span class="fn">sum</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) {
    <span class="kw">return</span> a + b;
}

<span class="kw">int</span> <span class="fn">main</span>(<span class="kw">void</span>) {
    <span class="kw">int</span> r = <span class="fn">sum</span>(<span class="num">3</span>, <span class="num">5</span>);
    <span class="fn">printf</span>(<span class="str">"%d\\n"</span>, r);
    <span class="kw">return</span> <span class="num">0</span>;
}</div>
<ul>
 <li><code>int</code> — тип результата. <code>void</code> если функция ничего не возвращает.</li>
 <li><code>sum</code> — имя.</li>
 <li><code>(int a, int b)</code> — параметры. <code>(void)</code> если параметров нет.</li>
 <li><code>return</code> — возвращает значение и завершает функцию.</li>
</ul>`},
{title:"Прототипы",content:`
<p>Если функция определена ниже точки вызова, нужно сначала объявить её <b>прототип</b>:</p>
<div class="code"><span class="kw">int</span> <span class="fn">sum</span>(<span class="kw">int</span>, <span class="kw">int</span>);   <span class="cmt">// прототип</span>

<span class="kw">int</span> <span class="fn">main</span>(<span class="kw">void</span>) {
    <span class="fn">printf</span>(<span class="str">"%d"</span>, <span class="fn">sum</span>(<span class="num">2</span>, <span class="num">3</span>));
}

<span class="kw">int</span> <span class="fn">sum</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) { <span class="kw">return</span> a + b; }</div>
<p>Прототипы обычно выносят в заголовочные файлы (<code>.h</code>), а реализации — в <code>.c</code>.</p>`},
{title:"Передача параметров",content:`
<p>В C параметры передаются <b>по значению</b> — функция получает копию:</p>
<div class="code"><span class="kw">void</span> <span class="fn">increment</span>(<span class="kw">int</span> x) { x++; }   <span class="cmt">// не изменит вызывающую переменную</span>

<span class="kw">int</span> y = <span class="num">5</span>;
<span class="fn">increment</span>(y);
<span class="fn">printf</span>(<span class="str">"%d"</span>, y);   <span class="cmt">// всё ещё 5!</span></div>
<p>Чтобы функция могла изменить переменную, передавайте <b>указатель</b>:</p>
<div class="code"><span class="kw">void</span> <span class="fn">increment</span>(<span class="kw">int</span>* p) { (*p)++; }

<span class="fn">increment</span>(&amp;y);
<span class="fn">printf</span>(<span class="str">"%d"</span>, y);   <span class="cmt">// 6</span></div>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body">Подробно про указатели — в теме 9.</div></div>`},
{title:"Хорошие практики",content:`
<ul>
 <li><b>Одна функция — одна задача.</b> Если функция делает много — разделите.</li>
 <li><b>Длина 10-50 строк.</b> Больше — кандидат на разбиение.</li>
 <li><b>Имена-глаголы:</b> <code>calculate_average</code>, <code>print_menu</code>, <code>find_max</code>.</li>
 <li><b>Параметры: важные первыми</b>, потом «помощники» (буферы, размеры).</li>
 <li><b>Документируйте</b> что функция принимает, что возвращает, какие имеет побочные эффекты.</li>
</ul>
<div class="box warn"><div class="box-ic">⚠️</div><div class="box-body">Возврат указателя на локальную переменную — UB! Память освобождается при выходе из функции.</div></div>`}
],
keyPoints:[
"Функция — переиспользуемый блок кода с именем и параметрами",
"Параметры в C передаются по значению (копией)",
"Для изменения переменной снаружи нужен указатель",
"<code>void</code> означает «ничего не возвращает» или «нет параметров»",
"Прототипы позволяют использовать функцию до её определения",
"Одна функция — одна задача; имя — глагол"
]
};
