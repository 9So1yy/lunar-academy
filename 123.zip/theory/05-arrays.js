window.THEORY=window.THEORY||{};
window.THEORY[5]={
intro:"Массив — это последовательность однотипных элементов, расположенных в памяти подряд. Это самая фундаментальная коллекция в C, и почти все другие структуры данных строятся поверх неё. Понимание массивов открывает дорогу к указателям, строкам и алгоритмам.",
sections:[
{title:"Введение",content:`
<p>Когда вам нужно хранить много значений одного типа — например, оценки 30 студентов, температуры за неделю или пиксели изображения — нет смысла объявлять 30 переменных. Используется <b>массив</b>.</p>
<div class="code"><span class="cmt">// 30 отдельных переменных — ужас</span>
<span class="kw">int</span> grade1, grade2, grade3, ..., grade30;

<span class="cmt">// Массив на 30 элементов — красота</span>
<span class="kw">int</span> grades[<span class="num">30</span>];</div>
<p>Особенности массивов в C:</p>
<ul>
 <li><b>Однотипные элементы.</b> Все одного типа (нельзя смешивать int и float);</li>
 <li><b>Фиксированный размер.</b> Задаётся при объявлении и не может расти (исключение — VLA и malloc);</li>
 <li><b>Непрерывная память.</b> Элементы лежат подряд — это даёт быстрый доступ по индексу;</li>
 <li><b>Индексация с нуля.</b> Первый элемент — <code>arr[0]</code>, последний — <code>arr[N-1]</code>.</li>
</ul>`},
{title:"Объявление и инициализация",content:`
<h3>Простое объявление</h3>
<div class="code"><span class="kw">int</span> arr[<span class="num">5</span>];           <span class="cmt">// 5 int — содержимое неопределено!</span>
<span class="kw">double</span> temp[<span class="num">7</span>];       <span class="cmt">// 7 температур</span>
<span class="kw">char</span> name[<span class="num">100</span>];        <span class="cmt">// строка до 99 символов + \0</span></div>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body">Только что объявленный массив содержит <b>мусор</b> — то, что осталось в памяти. Перед чтением — инициализируйте!</div>
</div>
<h3>Инициализация при объявлении</h3>
<div class="code"><span class="kw">int</span> a[<span class="num">5</span>] = {<span class="num">10</span>, <span class="num">20</span>, <span class="num">30</span>, <span class="num">40</span>, <span class="num">50</span>};   <span class="cmt">// явно</span>
<span class="kw">int</span> b[] = {<span class="num">1</span>, <span class="num">2</span>, <span class="num">3</span>};                  <span class="cmt">// размер выводится: 3</span>
<span class="kw">int</span> c[<span class="num">10</span>] = {<span class="num">0</span>};                       <span class="cmt">// первый = 0, остальные = 0</span>
<span class="kw">int</span> d[<span class="num">5</span>] = {<span class="num">1</span>, <span class="num">2</span>};                     <span class="cmt">// {1, 2, 0, 0, 0}</span>
<span class="kw">char</span> word[] = <span class="str">"hello"</span>;                  <span class="cmt">// {'h','e','l','l','o','\0'}</span></div>
<h3>Доступ к элементам</h3>
<div class="code"><span class="kw">int</span> a[<span class="num">5</span>] = {<span class="num">10</span>, <span class="num">20</span>, <span class="num">30</span>, <span class="num">40</span>, <span class="num">50</span>};
<span class="fn">printf</span>(<span class="str">"%d\\n"</span>, a[<span class="num">0</span>]);    <span class="cmt">// 10 (первый)</span>
<span class="fn">printf</span>(<span class="str">"%d\\n"</span>, a[<span class="num">4</span>]);    <span class="cmt">// 50 (последний)</span>
a[<span class="num">2</span>] = <span class="num">999</span>;              <span class="cmt">// меняем третий элемент</span></div>
<h3>Размер массива</h3>
<p>Чтобы узнать количество элементов, используется приём с <code>sizeof</code>:</p>
<div class="code"><span class="kw">int</span> arr[<span class="num">10</span>];
<span class="kw">int</span> n = <span class="kw">sizeof</span>(arr) / <span class="kw">sizeof</span>(arr[<span class="num">0</span>]);
<span class="fn">printf</span>(<span class="str">"Размер: %d\\n"</span>, n);  <span class="cmt">// 10</span></div>
<div class="box warn">
 <div class="box-ic">⚠️</div>
 <div class="box-body">Этот приём работает только там, где массив объявлен. После передачи в функцию массив становится указателем, и <code>sizeof</code> вернёт размер указателя (4 или 8 байт), а не массива.</div>
</div>`},
{title:"Обход массива",content:`
<p>Самый частый паттерн — пройти по всем элементам с помощью <code>for</code>:</p>
<div class="code"><span class="kw">int</span> arr[<span class="num">5</span>] = {<span class="num">10</span>, <span class="num">20</span>, <span class="num">30</span>, <span class="num">40</span>, <span class="num">50</span>};

<span class="cmt">// Вывод всех элементов</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; <span class="num">5</span>; i++) {
    <span class="fn">printf</span>(<span class="str">"%d "</span>, arr[i]);
}</div>
<h3>Поиск</h3>
<div class="code"><span class="cmt">// Найти индекс первого вхождения</span>
<span class="kw">int</span> <span class="fn">findIndex</span>(<span class="kw">int</span>* arr, <span class="kw">int</span> n, <span class="kw">int</span> target) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++) {
        <span class="kw">if</span> (arr[i] == target) <span class="kw">return</span> i;
    }
    <span class="kw">return</span> <span class="num">-1</span>;
}</div>
<h3>Минимум/максимум/сумма</h3>
<div class="code"><span class="kw">int</span> max = arr[<span class="num">0</span>];
<span class="kw">int</span> sum = <span class="num">0</span>;
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++) {
    <span class="kw">if</span> (arr[i] &gt; max) max = arr[i];
    sum += arr[i];
}
<span class="kw">double</span> avg = (<span class="kw">double</span>)sum / n;</div>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body"><b>Выход за границу массива</b> — самая опасная ошибка в C. <code>arr[5]</code> для массива размера 5 — это UB. Программа может работать, упасть или испортить чужие данные. C <b>не проверяет границы</b>.</div>
</div>`},
{title:"Двумерные массивы",content:`
<p>Массив может быть многомерным — например, для матриц, таблиц, шахматных досок.</p>
<div class="code"><span class="kw">int</span> matrix[<span class="num">3</span>][<span class="num">4</span>];  <span class="cmt">// 3 строки, 4 столбца</span>

<span class="kw">int</span> grid[<span class="num">3</span>][<span class="num">3</span>] = {
    {<span class="num">1</span>, <span class="num">2</span>, <span class="num">3</span>},
    {<span class="num">4</span>, <span class="num">5</span>, <span class="num">6</span>},
    {<span class="num">7</span>, <span class="num">8</span>, <span class="num">9</span>}
};

<span class="fn">printf</span>(<span class="str">"%d"</span>, grid[<span class="num">1</span>][<span class="num">2</span>]);  <span class="cmt">// 6 (вторая строка, третий столбец)</span></div>
<h3>Обход матрицы</h3>
<div class="code"><span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; <span class="num">3</span>; i++) {
    <span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">0</span>; j &lt; <span class="num">3</span>; j++) {
        <span class="fn">printf</span>(<span class="str">"%4d "</span>, grid[i][j]);
    }
    <span class="fn">printf</span>(<span class="str">"\\n"</span>);
}</div>
<p>Двумерный массив в памяти — это просто одномерный, расположенный <b>построчно</b> (row-major). <code>grid[i][j]</code> по сути значит <code>grid[i*cols + j]</code>.</p>
<h3>Многомерные</h3>
<div class="code"><span class="kw">int</span> cube[<span class="num">3</span>][<span class="num">3</span>][<span class="num">3</span>];     <span class="cmt">// трёхмерный — 27 элементов</span>
<span class="kw">int</span> tensor[<span class="num">10</span>][<span class="num">10</span>][<span class="num">10</span>][<span class="num">10</span>]; <span class="cmt">// четырёхмерный — 10 000</span></div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body">Многомерные массивы быстро занимают много памяти. <code>int big[1000][1000]</code> — это уже 4 МБ. Если нужны большие или динамические — используйте <code>malloc</code> (тема 14).</div>
</div>`},
{title:"Массивы и функции",content:`
<p>Когда массив передаётся в функцию, передаётся <b>не копия</b>, а указатель на первый элемент. Это значит:</p>
<ul>
 <li>Функция может <b>изменять</b> элементы — изменения видны вызывающему;</li>
 <li>Размер массива <b>не передаётся</b> — нужно передавать отдельным параметром;</li>
 <li>Это эффективно — даже огромный массив передаётся за O(1).</li>
</ul>
<div class="code"><span class="kw">void</span> <span class="fn">printArray</span>(<span class="kw">int</span> arr[], <span class="kw">int</span> n) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++) {
        <span class="fn">printf</span>(<span class="str">"%d "</span>, arr[i]);
    }
}

<span class="kw">void</span> <span class="fn">doubleAll</span>(<span class="kw">int</span>* arr, <span class="kw">int</span> n) {  <span class="cmt">// эквивалентная форма</span>
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++) {
        arr[i] *= <span class="num">2</span>;          <span class="cmt">// изменения сохранятся!</span>
    }
}

<span class="kw">int</span> <span class="fn">main</span>(<span class="kw">void</span>) {
    <span class="kw">int</span> nums[<span class="num">5</span>] = {<span class="num">1</span>, <span class="num">2</span>, <span class="num">3</span>, <span class="num">4</span>, <span class="num">5</span>};
    <span class="fn">doubleAll</span>(nums, <span class="num">5</span>);
    <span class="fn">printArray</span>(nums, <span class="num">5</span>);   <span class="cmt">// 2 4 6 8 10</span>
}</div>
<h3>const для защиты</h3>
<p>Если функция не должна менять массив — пишите <code>const</code>:</p>
<div class="code"><span class="kw">int</span> <span class="fn">sum</span>(<span class="kw">const</span> <span class="kw">int</span>* arr, <span class="kw">int</span> n) {
    <span class="kw">int</span> total = <span class="num">0</span>;
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++) total += arr[i];
    <span class="cmt">// arr[i] = 0;  ← ошибка компиляции — это защита</span>
    <span class="kw">return</span> total;
}</div>
<h3>Двумерные в функциях</h3>
<p>Для двумерных нужно указать размер столбцов:</p>
<div class="code"><span class="kw">void</span> <span class="fn">printGrid</span>(<span class="kw">int</span> grid[][<span class="num">4</span>], <span class="kw">int</span> rows) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; rows; i++) {
        <span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">0</span>; j &lt; <span class="num">4</span>; j++) {
            <span class="fn">printf</span>(<span class="str">"%d "</span>, grid[i][j]);
        }
        <span class="fn">printf</span>(<span class="str">"\\n"</span>);
    }
}</div>`},
{title:"Частые ошибки",content:`
<ul>
 <li><b>Выход за границу.</b> <code>arr[N]</code> для массива размера N — UB. Индексы только 0..N-1.</li>
 <li><b>Off-by-one в цикле.</b> <code>for (i = 0; i &lt;= n; i++)</code> — на одну итерацию больше. Должно быть <code>i &lt; n</code>.</li>
 <li><b>Использование sizeof в функции.</b> Внутри функции <code>sizeof(arr)</code> вернёт размер указателя, а не массива. Передавайте размер параметром.</li>
 <li><b>Возврат локального массива из функции.</b> Память освобождается при возврате — UB.</li>
 <li><b>Сравнение через ==.</b> <code>arr1 == arr2</code> сравнивает <b>адреса</b>, не содержимое. Сравнивайте поэлементно.</li>
 <li><b>Копирование через =.</b> <code>arr2 = arr1</code> не работает. Используйте <code>memcpy()</code> или цикл.</li>
 <li><b>Неинициализированные элементы.</b> После <code>int a[10];</code> элементы — мусор. <code>int a[10] = {0};</code> обнуляет все.</li>
</ul>`},
{title:"Практические советы",content:`
<h3>Define для размеров</h3>
<p>Используйте <code>#define</code> или <code>const</code> для размера массива в одном месте:</p>
<div class="code"><span class="pp">#define</span> SIZE <span class="num">100</span>

<span class="kw">int</span> arr[SIZE];
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; SIZE; i++) {
    ...
}</div>
<p>Если потом нужно изменить размер — меняете в одной строке.</p>
<h3>Инициализируйте сразу</h3>
<div class="code"><span class="kw">int</span> arr[<span class="num">100</span>] = {<span class="num">0</span>};  <span class="cmt">// все нули — безопасно</span></div>
<h3>Когда массивов не хватает</h3>
<p>Массивы в C — мощные, но ограниченные:</p>
<ul>
 <li>Размер фиксирован — для динамики нужен <code>malloc</code> (тема 14);</li>
 <li>Нет встроенных методов как в Python — пишите функции сами;</li>
 <li>Для удаления элемента — сдвигайте остальные;</li>
 <li>Для строк есть <code>string.h</code> с готовыми функциями (темы 11–12).</li>
</ul>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body"><b>Совет.</b> Всегда передавайте функциям массив <b>вместе с размером</b>. Это золотое правило C-программирования: <code>void foo(int* arr, size_t n)</code>.</div>
</div>`}
],
keyPoints:[
"Массив — последовательность однотипных элементов в непрерывной памяти",
"Индексация с <b>нуля</b>: первый элемент — <code>arr[0]</code>, последний — <code>arr[N-1]</code>",
"C <b>не проверяет границы</b> — выход за пределы это UB",
"Размер массива фиксирован при объявлении (статически)",
"В функцию передаётся указатель — изменения видны вызывающему",
"<code>sizeof</code> внутри функции даст размер указателя, не массива",
"Многомерные массивы хранятся построчно (row-major)"
]
};
