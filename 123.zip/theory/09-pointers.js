window.THEORY=window.THEORY||{};
window.THEORY[9]={
intro:"Указатель — это переменная, хранящая <b>адрес</b> другой переменной в памяти. Самая мощная и самая опасная фича C. Через указатели работают массивы, строки, динамическая память и многое другое.",
sections:[
{title:"Основы",content:`
<div class="code"><span class="kw">int</span> x = <span class="num">42</span>;
<span class="kw">int</span>* p = &amp;x;          <span class="cmt">// p хранит адрес x</span>
<span class="fn">printf</span>(<span class="str">"%p\\n"</span>, p);    <span class="cmt">// печать адреса</span>
<span class="fn">printf</span>(<span class="str">"%d\\n"</span>, *p);   <span class="cmt">// разыменование: 42</span></div>
<table>
 <tr><td><code>&amp;</code></td><td>«адрес от» — получает адрес переменной</td></tr>
 <tr><td><code>*</code></td><td>«значение по» — даёт значение по адресу</td></tr>
</table>
<p>Указатель имеет тип. <code>int*</code> и <code>double*</code> — разные типы.</p>
<div class="code"><span class="kw">int</span>* p = <span class="kw">NULL</span>;       <span class="cmt">// «никуда не указывает»</span>
<span class="kw">if</span> (p != <span class="kw">NULL</span>) { ... }  <span class="cmt">// безопасная проверка</span></div>`},
{title:"Указатели и массивы",content:`
<p>Имя массива в выражениях «распадается» в указатель на первый элемент:</p>
<div class="code"><span class="kw">int</span> arr[<span class="num">3</span>] = {<span class="num">10</span>, <span class="num">20</span>, <span class="num">30</span>};
<span class="kw">int</span>* p = arr;             <span class="cmt">// == &amp;arr[0]</span>

<span class="fn">printf</span>(<span class="str">"%d"</span>, *(p + <span class="num">1</span>));    <span class="cmt">// 20</span>
<span class="fn">printf</span>(<span class="str">"%d"</span>, p[<span class="num">1</span>]);        <span class="cmt">// 20 — то же самое</span></div>
<p><b>Арифметика указателей</b>: <code>p + 1</code> сдвигает на <code>sizeof(*p)</code> байт. Для <code>int*</code> — на 4 байта.</p>`},
{title:"Указатели в функциях",content:`
<p>Чтобы функция могла менять переменную вызывающего, передайте указатель:</p>
<div class="code"><span class="kw">void</span> <span class="fn">swap</span>(<span class="kw">int</span>* a, <span class="kw">int</span>* b) {
    <span class="kw">int</span> t = *a; *a = *b; *b = t;
}

<span class="kw">int</span> x = <span class="num">1</span>, y = <span class="num">2</span>;
<span class="fn">swap</span>(&amp;x, &amp;y);
<span class="cmt">// теперь x = 2, y = 1</span></div>`},
{title:"Опасности",content:`
<ul>
 <li><b>Разыменование NULL</b> — программа упадёт.</li>
 <li><b>Неинициализированный указатель</b> — указывает на случайный адрес, UB.</li>
 <li><b>Висячий указатель</b> — указывает на освобождённую/несуществующую память.</li>
 <li><b>Выход за границы</b> — арифметика, выводящая за пределы массива.</li>
</ul>
<div class="box danger"><div class="box-ic">🚫</div><div class="box-body">Указатели — самая распространённая причина крашей в C. Всегда проверяйте на NULL, инициализируйте, не используйте после <code>free()</code>.</div></div>`}
],
keyPoints:[
"Указатель хранит <b>адрес</b> другой переменной",
"<code>&amp;x</code> — взять адрес, <code>*p</code> — получить значение по адресу",
"Имя массива в выражении превращается в указатель",
"<code>p[i]</code> эквивалентно <code>*(p + i)</code>",
"Чтобы функция меняла переменную — передавайте указатель",
"<code>NULL</code> = «никуда не указывает», всегда проверяйте",
"Указатели — главный источник UB в C"
]
};
