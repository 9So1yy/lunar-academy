window.THEORY=window.THEORY||{};
window.THEORY[15]={
intro:"Рекурсия — это когда функция вызывает саму себя. Многие задачи решаются естественнее всего рекурсивно: факториал, обход дерева, разбиение задачи на подзадачи. Но рекурсия требует осторожности — без правильной базы это бесконечный цикл.",
sections:[
{title:"Анатомия рекурсии",content:`
<p>Любая рекурсивная функция состоит из двух частей:</p>
<ol>
 <li><b>База</b> — условие, когда рекурсия останавливается;</li>
 <li><b>Шаг</b> — вызов функции с уменьшенным аргументом.</li>
</ol>
<div class="code"><span class="kw">long</span> <span class="fn">factorial</span>(<span class="kw">int</span> n) {
    <span class="kw">if</span> (n &lt;= <span class="num">1</span>) <span class="kw">return</span> <span class="num">1</span>;          <span class="cmt">// БАЗА</span>
    <span class="kw">return</span> n * <span class="fn">factorial</span>(n - <span class="num">1</span>);   <span class="cmt">// ШАГ — n уменьшается</span>
}

<span class="fn">factorial</span>(<span class="num">5</span>) → <span class="num">5</span> * <span class="fn">factorial</span>(<span class="num">4</span>)
            → <span class="num">5</span> * <span class="num">4</span> * <span class="fn">factorial</span>(<span class="num">3</span>)
            → <span class="num">5</span> * <span class="num">4</span> * <span class="num">3</span> * <span class="num">2</span> * <span class="num">1</span> = <span class="num">120</span></div>
<div class="box danger"><div class="box-ic">🚫</div><div class="box-body"><b>Без базы</b> функция вызывает себя бесконечно, заполняет стек и программа падает с <b>stack overflow</b>.</div></div>`},
{title:"Классические примеры",content:`
<h3>Фибоначчи</h3>
<div class="code"><span class="kw">int</span> <span class="fn">fib</span>(<span class="kw">int</span> n) {
    <span class="kw">if</span> (n &lt; <span class="num">2</span>) <span class="kw">return</span> n;
    <span class="kw">return</span> <span class="fn">fib</span>(n-<span class="num">1</span>) + <span class="fn">fib</span>(n-<span class="num">2</span>);
}</div>
<p>Простая рекурсия, но O(2ⁿ) — экспоненциально медленно из-за повторных вычислений. Решение: <b>мемоизация</b> или итерация.</p>
<h3>НОД (алгоритм Евклида)</h3>
<div class="code"><span class="kw">int</span> <span class="fn">gcd</span>(<span class="kw">int</span> a, <span class="kw">int</span> b) {
    <span class="kw">if</span> (b == <span class="num">0</span>) <span class="kw">return</span> a;
    <span class="kw">return</span> <span class="fn">gcd</span>(b, a % b);
}</div>
<h3>Степень за O(log n)</h3>
<div class="code"><span class="kw">double</span> <span class="fn">power</span>(<span class="kw">double</span> b, <span class="kw">int</span> e) {
    <span class="kw">if</span> (e == <span class="num">0</span>) <span class="kw">return</span> <span class="num">1</span>;
    <span class="kw">double</span> half = <span class="fn">power</span>(b, e/<span class="num">2</span>);
    <span class="kw">return</span> (e % <span class="num">2</span>) ? half * half * b : half * half;
}</div>`},
{title:"Когда стоит и не стоит",content:`
<h3>Рекурсия удобна для</h3>
<ul>
 <li>Деревьев и графов</li>
 <li>«Разделяй и властвуй» (merge sort, quick sort)</li>
 <li>Комбинаторики (перестановки, размещения)</li>
 <li>Парсеров и выражений</li>
</ul>
<h3>Минусы</h3>
<ul>
 <li><b>Стек ограничен.</b> Глубокая рекурсия → stack overflow.</li>
 <li><b>Накладные расходы.</b> Каждый вызов — это создание кадра стека.</li>
 <li><b>Повторные вычисления.</b> Простая <code>fib(50)</code> — миллиарды вызовов.</li>
</ul>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body"><b>Хвостовая рекурсия</b> (когда последнее действие функции — рекурсивный вызов) может быть оптимизирована компилятором в обычный цикл. Однако в C это не гарантируется.</div></div>`}
],
keyPoints:[
"Рекурсия = функция вызывает саму себя",
"Обязательны <b>база</b> (условие выхода) и <b>шаг</b> (уменьшение задачи)",
"Без базы — stack overflow",
"Простая <code>fib</code> экспоненциально медленна — нужна мемоизация",
"Рекурсия дороже цикла из-за вызовов функций",
"Естественна для деревьев, парсеров, «разделяй и властвуй»"
]
};
