window.THEORY=window.THEORY||{};
window.THEORY[16]={
intro:"Файловый ввод-вывод позволяет программе сохранять данные между запусками и работать с большими объёмами информации. В C это реализовано через указатель <code>FILE*</code> и набор функций в <code>&lt;stdio.h&gt;</code>.",
sections:[
{title:"Открытие и закрытие",content:`
<div class="code">FILE* f = <span class="fn">fopen</span>(<span class="str">"data.txt"</span>, <span class="str">"r"</span>);
<span class="kw">if</span> (f == <span class="kw">NULL</span>) {
    <span class="fn">perror</span>(<span class="str">"open"</span>);
    <span class="kw">return</span> <span class="num">1</span>;
}
<span class="cmt">// ... работа ...</span>
<span class="fn">fclose</span>(f);</div>
<h3>Режимы открытия</h3>
<table>
 <tr><th>Режим</th><th>Действие</th></tr>
 <tr><td><code>"r"</code></td><td>чтение (файл должен существовать)</td></tr>
 <tr><td><code>"w"</code></td><td>запись (создаёт или обрезает)</td></tr>
 <tr><td><code>"a"</code></td><td>дозапись в конец</td></tr>
 <tr><td><code>"r+"</code></td><td>чтение и запись</td></tr>
 <tr><td><code>"rb"</code>, <code>"wb"</code></td><td>бинарный режим</td></tr>
</table>
<div class="box warn"><div class="box-ic">⚠️</div><div class="box-body">Всегда проверяйте, что <code>fopen</code> вернул не <code>NULL</code>. Файл может отсутствовать, быть занят, не давать прав на чтение.</div></div>`},
{title:"Чтение и запись текста",content:`
<div class="code"><span class="cmt">// Чтение построчно</span>
<span class="kw">char</span> line[<span class="num">256</span>];
<span class="kw">while</span> (<span class="fn">fgets</span>(line, <span class="num">256</span>, f) != <span class="kw">NULL</span>) {
    <span class="fn">printf</span>(<span class="str">"%s"</span>, line);
}

<span class="cmt">// Чтение чисел</span>
<span class="kw">int</span> x;
<span class="kw">while</span> (<span class="fn">fscanf</span>(f, <span class="str">"%d"</span>, &amp;x) == <span class="num">1</span>) {
    <span class="fn">printf</span>(<span class="str">"%d "</span>, x);
}</div>
<div class="code"><span class="cmt">// Запись</span>
<span class="fn">fprintf</span>(f, <span class="str">"Имя: %s, возраст: %d\\n"</span>, name, age);
<span class="fn">fputs</span>(<span class="str">"Ещё строка\\n"</span>, f);
<span class="fn">fputc</span>(<span class="str">'A'</span>, f);</div>`},
{title:"Бинарные файлы и позиция",content:`
<p>Для бинарных данных (структуры, изображения, нечитаемые форматы) используются <code>fread</code> и <code>fwrite</code>:</p>
<div class="code"><span class="kw">struct</span> Point { <span class="kw">int</span> x, y; } p = {<span class="num">3</span>, <span class="num">4</span>};
<span class="fn">fwrite</span>(&amp;p, <span class="kw">sizeof</span>(p), <span class="num">1</span>, f);

<span class="kw">struct</span> Point r;
<span class="fn">fread</span>(&amp;r, <span class="kw">sizeof</span>(r), <span class="num">1</span>, f);</div>
<h3>Позиция в файле</h3>
<table>
 <tr><td><code>fseek(f, offset, SEEK_SET)</code></td><td>от начала</td></tr>
 <tr><td><code>fseek(f, offset, SEEK_CUR)</code></td><td>от текущей</td></tr>
 <tr><td><code>fseek(f, offset, SEEK_END)</code></td><td>от конца</td></tr>
 <tr><td><code>ftell(f)</code></td><td>текущая позиция</td></tr>
 <tr><td><code>rewind(f)</code></td><td>в начало</td></tr>
</table>
<h3>Стандартные потоки</h3>
<p><code>stdin</code>, <code>stdout</code>, <code>stderr</code> — это тоже <code>FILE*</code>. <code>printf("x")</code> ≡ <code>fprintf(stdout, "x")</code>.</p>`}
],
keyPoints:[
"Файлы открываются через <code>fopen</code>, закрываются через <code>fclose</code>",
"Всегда проверяйте результат <code>fopen</code> на NULL",
"Текстовые функции: <code>fgets</code>, <code>fputs</code>, <code>fprintf</code>, <code>fscanf</code>",
"Бинарные функции: <code>fread</code>, <code>fwrite</code>",
"<code>fseek</code>/<code>ftell</code> для произвольного доступа к позиции",
"<code>stdin</code>, <code>stdout</code>, <code>stderr</code> — стандартные потоки типа FILE*"
]
};
