window.THEORY=window.THEORY||{};
window.THEORY[13]={
intro:"Поиск элемента в коллекции — фундаментальная задача программирования. Два классических подхода: линейный (O(n)) — работает всегда, и бинарный (O(log n)) — требует отсортированный массив.",
sections:[
{title:"Линейный поиск",content:`
<p>Простейший алгоритм: перебираем элементы один за другим, пока не найдём нужный.</p>
<div class="code"><span class="kw">int</span> <span class="fn">linearSearch</span>(<span class="kw">int</span>* arr, <span class="kw">int</span> n, <span class="kw">int</span> target) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++) {
        <span class="kw">if</span> (arr[i] == target) <span class="kw">return</span> i;
    }
    <span class="kw">return</span> <span class="num">-1</span>;  <span class="cmt">// не найдено</span>
}</div>
<ul>
 <li><b>Сложность:</b> O(n) — в худшем случае проверяем все элементы.</li>
 <li><b>Когда применять:</b> массив маленький или неотсортированный.</li>
 <li><b>Возврат:</b> индекс найденного, иначе <code>-1</code> (соглашение).</li>
</ul>`},
{title:"Бинарный поиск",content:`
<p>Если массив <b>отсортирован</b> — можно искать за O(log n), деля диапазон пополам каждый раз.</p>
<div class="code"><span class="kw">int</span> <span class="fn">binSearch</span>(<span class="kw">int</span>* arr, <span class="kw">int</span> n, <span class="kw">int</span> target) {
    <span class="kw">int</span> lo = <span class="num">0</span>, hi = n - <span class="num">1</span>;
    <span class="kw">while</span> (lo &lt;= hi) {
        <span class="kw">int</span> mid = lo + (hi - lo) / <span class="num">2</span>;
        <span class="kw">if</span> (arr[mid] == target) <span class="kw">return</span> mid;
        <span class="kw">if</span> (arr[mid] &lt; target) lo = mid + <span class="num">1</span>;
        <span class="kw">else</span>                   hi = mid - <span class="num">1</span>;
    }
    <span class="kw">return</span> <span class="num">-1</span>;
}</div>
<div class="box tip"><div class="box-ic">💡</div><div class="box-body">Запись <code>mid = lo + (hi - lo) / 2</code> вместо <code>(lo + hi) / 2</code> защищает от переполнения int при больших lo и hi.</div></div>`},
{title:"Сравнение",content:`
<table>
 <tr><th>Параметр</th><th>Линейный</th><th>Бинарный</th></tr>
 <tr><td>Сложность</td><td>O(n)</td><td>O(log n)</td></tr>
 <tr><td>n = 1000</td><td>1000 шагов</td><td>~10 шагов</td></tr>
 <tr><td>n = 1 млн</td><td>1 000 000</td><td>~20</td></tr>
 <tr><td>Требует сортировки</td><td>нет</td><td>да</td></tr>
 <tr><td>Поиск нескольких</td><td>возможно</td><td>сложнее</td></tr>
</table>
<h3>Стандартная библиотека</h3>
<p>В <code>&lt;stdlib.h&gt;</code> есть готовая функция бинарного поиска <code>bsearch</code>:</p>
<div class="code"><span class="kw">int</span> key = <span class="num">42</span>;
<span class="kw">int</span>* found = <span class="fn">bsearch</span>(&amp;key, arr, n, <span class="kw">sizeof</span>(<span class="kw">int</span>), cmp);
<span class="kw">if</span> (found) ...</div>`}
],
keyPoints:[
"Линейный поиск работает всегда, но за O(n)",
"Бинарный поиск — O(log n), но требует отсортированный массив",
"Возвращайте <code>-1</code> для «не найдено» — стандартное соглашение",
"<code>mid = lo + (hi-lo)/2</code> — защита от переполнения",
"Для больших данных разница O(n) vs O(log n) огромна",
"В stdlib есть <code>bsearch</code> и <code>qsort</code>"
]
};
