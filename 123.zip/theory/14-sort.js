window.THEORY=window.THEORY||{};
window.THEORY[14]={
intro:"Сортировка — фундамент многих алгоритмов. Знание разных подходов и их характеристик помогает выбирать правильный инструмент. Базовые: bubble, selection, insertion (O(n²)). Продвинутые: merge, quick (O(n log n)).",
sections:[
{title:"Сортировка пузырьком (Bubble)",content:`
<p>Простой, но медленный. Идём по массиву, меняем соседей местами, если они в неправильном порядке. Повторяем, пока массив не отсортирован.</p>
<div class="code"><span class="kw">void</span> <span class="fn">bubbleSort</span>(<span class="kw">int</span>* a, <span class="kw">int</span> n) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n - <span class="num">1</span>; i++) {
        <span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">0</span>; j &lt; n - i - <span class="num">1</span>; j++) {
            <span class="kw">if</span> (a[j] &gt; a[j+<span class="num">1</span>]) {
                <span class="kw">int</span> t = a[j]; a[j] = a[j+<span class="num">1</span>]; a[j+<span class="num">1</span>] = t;
            }
        }
    }
}</div>
<p><b>Сложность:</b> O(n²). Используется редко из-за медленности, но полезен для обучения.</p>`},
{title:"Сортировка выбором (Selection)",content:`
<p>На каждой итерации находим минимальный из оставшихся и ставим в начало.</p>
<div class="code"><span class="kw">void</span> <span class="fn">selectionSort</span>(<span class="kw">int</span>* a, <span class="kw">int</span> n) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n - <span class="num">1</span>; i++) {
        <span class="kw">int</span> mi = i;
        <span class="kw">for</span> (<span class="kw">int</span> j = i + <span class="num">1</span>; j &lt; n; j++)
            <span class="kw">if</span> (a[j] &lt; a[mi]) mi = j;
        <span class="kw">if</span> (mi != i) {
            <span class="kw">int</span> t = a[i]; a[i] = a[mi]; a[mi] = t;
        }
    }
}</div>
<p>Тоже O(n²), но делает меньше обменов, чем bubble — может быть полезно когда swap дорогой.</p>`},
{title:"Сортировка вставкой (Insertion)",content:`
<p>Берём каждый элемент и вставляем в правильное место среди уже отсортированных (как при сортировке карт в руке).</p>
<div class="code"><span class="kw">void</span> <span class="fn">insertionSort</span>(<span class="kw">int</span>* a, <span class="kw">int</span> n) {
    <span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">1</span>; i &lt; n; i++) {
        <span class="kw">int</span> key = a[i], j = i - <span class="num">1</span>;
        <span class="kw">while</span> (j &gt;= <span class="num">0</span> &amp;&amp; a[j] &gt; key) {
            a[j+<span class="num">1</span>] = a[j];
            j--;
        }
        a[j+<span class="num">1</span>] = key;
    }
}</div>
<p>O(n²) в худшем, но O(n) на почти отсортированных массивах — отличный выбор для малых данных.</p>`},
{title:"Сравнение и qsort",content:`
<table>
 <tr><th>Алгоритм</th><th>Среднее</th><th>Худший</th><th>Память</th><th>Стабильность</th></tr>
 <tr><td>Bubble</td><td>O(n²)</td><td>O(n²)</td><td>O(1)</td><td>Да</td></tr>
 <tr><td>Selection</td><td>O(n²)</td><td>O(n²)</td><td>O(1)</td><td>Нет</td></tr>
 <tr><td>Insertion</td><td>O(n²)</td><td>O(n²)</td><td>O(1)</td><td>Да</td></tr>
 <tr><td>Merge</td><td>O(n log n)</td><td>O(n log n)</td><td>O(n)</td><td>Да</td></tr>
 <tr><td>Quick</td><td>O(n log n)</td><td>O(n²)</td><td>O(log n)</td><td>Нет</td></tr>
</table>
<h3>Готовая qsort</h3>
<div class="code"><span class="kw">int</span> <span class="fn">cmp</span>(<span class="kw">const</span> <span class="kw">void</span>* a, <span class="kw">const</span> <span class="kw">void</span>* b) {
    <span class="kw">return</span> *(<span class="kw">int</span>*)a - *(<span class="kw">int</span>*)b;
}
<span class="fn">qsort</span>(arr, n, <span class="kw">sizeof</span>(<span class="kw">int</span>), cmp);</div>
<p>В реальных проектах почти всегда используется <code>qsort</code> из <code>&lt;stdlib.h&gt;</code>.</p>`}
],
keyPoints:[
"Bubble/Selection/Insertion — O(n²), для малых массивов",
"Merge/Quick — O(n log n), стандарт для больших данных",
"Insertion очень быстр на почти отсортированных массивах",
"<b>Стабильная</b> сортировка сохраняет порядок равных элементов",
"<code>qsort</code> из stdlib работает с любым типом через void*",
"Свою сортировку пишут только в учебных целях"
]
};
