window.THEORY=window.THEORY||{};
window.THEORY[3]={
intro:"Условные конструкции позволяют программе принимать решения и выбирать разные пути исполнения. В C это <code>if</code>, <code>else</code>, <code>switch</code>, тернарный оператор. Без условий программа была бы просто линейной — а с ними становится «думающей».",
sections:[
{title:"Введение",content:`
<p>Любая программа сложнее «Hello, World» должна реагировать на данные. Если пользователь ввёл число больше 100 — одна логика, меньше — другая. За это отвечают <b>условные операторы</b>.</p>
<p>В C их несколько:</p>
<ul>
 <li><code>if</code> / <code>else</code> — основной механизм;</li>
 <li><code>else if</code> — цепочка проверок;</li>
 <li><code>switch</code> / <code>case</code> — множественный выбор по значению;</li>
 <li>тернарный оператор <code>?:</code> — короткая форма if/else.</li>
</ul>
<p>Все они работают на одном принципе: <b>0 — это «ложь», любое другое значение — «истина»</b>. В C нет отдельного типа <code>bool</code> до C99 — условие просто проверяет, не равно ли значение нулю.</p>
<div class="code"><span class="kw">int</span> x = <span class="num">5</span>;
<span class="kw">if</span> (x) {           <span class="cmt">// истинно (5 != 0)</span>
    <span class="fn">printf</span>(<span class="str">"x не ноль\\n"</span>);
}
<span class="kw">if</span> (!x) {          <span class="cmt">// ложно</span>
    <span class="fn">printf</span>(<span class="str">"x — ноль\\n"</span>);
}</div>`},
{title:"if / else if / else",content:`
<p>Базовая конструкция выбора. Условие проверяется, и если истинно — выполняется блок:</p>
<div class="code"><span class="kw">int</span> score = <span class="num">85</span>;

<span class="kw">if</span> (score &gt;= <span class="num">90</span>) {
    <span class="fn">printf</span>(<span class="str">"Отлично\\n"</span>);
} <span class="kw">else if</span> (score &gt;= <span class="num">75</span>) {
    <span class="fn">printf</span>(<span class="str">"Хорошо\\n"</span>);
} <span class="kw">else if</span> (score &gt;= <span class="num">60</span>) {
    <span class="fn">printf</span>(<span class="str">"Удовлетворительно\\n"</span>);
} <span class="kw">else</span> {
    <span class="fn">printf</span>(<span class="str">"Не сдано\\n"</span>);
}</div>
<p>Цепочка проверяется сверху вниз: первое истинное условие выполняется, остальные пропускаются.</p>
<h3>Фигурные скобки</h3>
<p>В C скобки <code>{}</code> можно опустить, если в ветке одно выражение:</p>
<div class="code"><span class="kw">if</span> (x &gt; <span class="num">0</span>) <span class="fn">printf</span>(<span class="str">"положительное\\n"</span>);
<span class="kw">else</span> <span class="fn">printf</span>(<span class="str">"неположительное\\n"</span>);</div>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body"><b>Опасная экономия.</b> Не опускайте скобки! Это источник реальных багов:
<div class="code"><span class="kw">if</span> (auth)
    <span class="fn">grantAccess</span>();
    <span class="fn">logEvent</span>();   <span class="cmt">// этот вызов ВСЕГДА выполняется!</span></div>
Даже если в ветке одна строка — пишите <code>{}</code>.</div>
</div>
<h3>Вложенные условия</h3>
<div class="code"><span class="kw">if</span> (age &gt;= <span class="num">18</span>) {
    <span class="kw">if</span> (hasLicense) {
        <span class="fn">printf</span>(<span class="str">"Может водить\\n"</span>);
    } <span class="kw">else</span> {
        <span class="fn">printf</span>(<span class="str">"Нужны права\\n"</span>);
    }
} <span class="kw">else</span> {
    <span class="fn">printf</span>(<span class="str">"Слишком молод\\n"</span>);
}</div>
<p>Эквивалентно через <code>&amp;&amp;</code>:</p>
<div class="code"><span class="kw">if</span> (age &gt;= <span class="num">18</span> &amp;&amp; hasLicense) ...</div>`},
{title:"Тернарный оператор",content:`
<p>Это единственный оператор в C с тремя операндами: <code>условие ? значение_если_истина : значение_если_ложь</code>.</p>
<div class="code"><span class="kw">int</span> max = (a &gt; b) ? a : b;
<span class="kw">int</span> abs_val = (n &lt; <span class="num">0</span>) ? -n : n;
<span class="kw">const</span> <span class="kw">char</span>* msg = (count == <span class="num">1</span>) ? <span class="str">"товар"</span> : <span class="str">"товаров"</span>;
<span class="fn">printf</span>(<span class="str">"%d %s\\n"</span>, count, msg);</div>
<p>Главное отличие от if/else — тернарный оператор это <b>выражение</b>: возвращает значение, которое можно сразу присвоить, передать в функцию, использовать в printf.</p>
<div class="code"><span class="cmt">// Прямо в printf:</span>
<span class="fn">printf</span>(<span class="str">"%s\\n"</span>, (x % <span class="num">2</span> == <span class="num">0</span>) ? <span class="str">"чётное"</span> : <span class="str">"нечётное"</span>);</div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body"><b>Когда использовать?</b> Когда оба варианта — короткие выражения одного типа. Если хоть один — длинный или с побочными эффектами — пишите обычный if/else.</div>
</div>`},
{title:"switch / case",content:`
<p>Когда нужно выбрать одну из многих веток по <b>конкретному значению</b> целочисленного выражения — удобнее <code>switch</code>:</p>
<div class="code"><span class="kw">int</span> day = <span class="num">3</span>;

<span class="kw">switch</span> (day) {
    <span class="kw">case</span> <span class="num">1</span>: <span class="fn">printf</span>(<span class="str">"Понедельник\\n"</span>); <span class="kw">break</span>;
    <span class="kw">case</span> <span class="num">2</span>: <span class="fn">printf</span>(<span class="str">"Вторник\\n"</span>);     <span class="kw">break</span>;
    <span class="kw">case</span> <span class="num">3</span>: <span class="fn">printf</span>(<span class="str">"Среда\\n"</span>);       <span class="kw">break</span>;
    <span class="kw">case</span> <span class="num">4</span>: <span class="fn">printf</span>(<span class="str">"Четверг\\n"</span>);     <span class="kw">break</span>;
    <span class="kw">case</span> <span class="num">5</span>: <span class="fn">printf</span>(<span class="str">"Пятница\\n"</span>);     <span class="kw">break</span>;
    <span class="kw">case</span> <span class="num">6</span>:
    <span class="kw">case</span> <span class="num">7</span>: <span class="fn">printf</span>(<span class="str">"Выходной\\n"</span>);    <span class="kw">break</span>;
    <span class="kw">default</span>: <span class="fn">printf</span>(<span class="str">"Неизвестно\\n"</span>);
}</div>
<h3>Особенности</h3>
<ul>
 <li>Работает <b>только с целыми</b> типами (<code>int</code>, <code>char</code>, <code>enum</code>) — не для строк или дробных;</li>
 <li><code>case</code> требует <b>константного выражения</b> — переменные нельзя;</li>
 <li><code>break</code> — обязательный «выход», иначе провалится в следующий case;</li>
 <li><code>default</code> — необязательная ветка «всё остальное».</li>
</ul>
<h3>Fall-through (провал)</h3>
<p>Без <code>break</code> исполнение продолжается в следующий case. Это иногда полезно:</p>
<div class="code"><span class="kw">switch</span> (month) {
    <span class="kw">case</span> <span class="num">12</span>:
    <span class="kw">case</span> <span class="num">1</span>:
    <span class="kw">case</span> <span class="num">2</span>:
        <span class="fn">printf</span>(<span class="str">"Зима\\n"</span>);
        <span class="kw">break</span>;
    <span class="kw">case</span> <span class="num">3</span>: <span class="kw">case</span> <span class="num">4</span>: <span class="kw">case</span> <span class="num">5</span>:
        <span class="fn">printf</span>(<span class="str">"Весна\\n"</span>);
        <span class="kw">break</span>;
    ...
}</div>
<div class="box warn">
 <div class="box-ic">⚠️</div>
 <div class="box-body"><b>Забытый break</b> — частая ошибка. Если fall-through сделан намеренно, добавьте комментарий <code>// fall through</code>, чтобы это было видно.</div>
</div>`},
{title:"Логические выражения",content:`
<p>Условия часто составляются из нескольких сравнений через <code>&amp;&amp;</code> (И), <code>||</code> (ИЛИ), <code>!</code> (НЕ):</p>
<div class="code"><span class="cmt">// Точка внутри квадрата [0..10] × [0..10]</span>
<span class="kw">if</span> (x &gt;= <span class="num">0</span> &amp;&amp; x &lt;= <span class="num">10</span> &amp;&amp; y &gt;= <span class="num">0</span> &amp;&amp; y &lt;= <span class="num">10</span>) {
    <span class="fn">printf</span>(<span class="str">"внутри\\n"</span>);
}

<span class="cmt">// Выходной день</span>
<span class="kw">if</span> (day == <span class="num">6</span> || day == <span class="num">7</span>) {
    <span class="fn">printf</span>(<span class="str">"отдыхаем\\n"</span>);
}

<span class="cmt">// Не пусто и не -1</span>
<span class="kw">if</span> (str &amp;&amp; *str != <span class="str">'\\0'</span>) {
    ...
}</div>
<h3>Закон де Моргана</h3>
<p>Эти выражения эквивалентны:</p>
<table>
 <tr><th>Длинно</th><th>Коротко</th></tr>
 <tr><td><code>!(a &amp;&amp; b)</code></td><td><code>!a || !b</code></td></tr>
 <tr><td><code>!(a || b)</code></td><td><code>!a &amp;&amp; !b</code></td></tr>
</table>
<p>Полезно для упрощения сложных условий.</p>
<h3>Сравнение float</h3>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body"><b>Никогда не сравнивайте дробные через <code>==</code>!</b> <code>0.1 + 0.2 != 0.3</code> в C (из-за IEEE 754).
<div class="code"><span class="cmt">// Плохо:</span>
<span class="kw">if</span> (x == <span class="num">0.3</span>) ...

<span class="cmt">// Хорошо:</span>
<span class="pp">#include</span> &lt;<span class="str">math.h</span>&gt;
<span class="kw">if</span> (<span class="fn">fabs</span>(x - <span class="num">0.3</span>) &lt; <span class="num">1e-9</span>) ...</div></div>
</div>`},
{title:"Частые ошибки",content:`
<ul>
 <li><b>= вместо ==</b> в условии: <code>if (x = 0)</code> всегда ложно и обнуляет x.</li>
 <li><b>Пропущенные скобки</b>: <code>if (x) a; b;</code> — <code>b</code> выполнится всегда.</li>
 <li><b>Лишняя точка с запятой</b>: <code>if (x);</code> — пустое тело, следующая строка выполнится всегда.</li>
 <li><b>Сравнение с константой слева</b>: <code>if (5 = x)</code> вызовет ошибку компиляции — это безопаснее, чем <code>if (x = 5)</code> (yoda-style).</li>
 <li><b>Dangling else</b>: <code>else</code> прилипает к ближайшему <code>if</code>. Спасают скобки.</li>
 <li><b>Забытый break в switch</b> — провал в следующий case.</li>
 <li><b>Сравнение float через ==</b> — почти всегда даёт ложь из-за погрешности.</li>
 <li><b>Перекрывающиеся условия</b>: <code>if (x &gt; 0) ... else if (x &gt; 10)</code> — второй case никогда не сработает!</li>
</ul>`},
{title:"Практические советы",content:`
<h3>Раннее возвращение</h3>
<p>Вместо вложенных if предпочитайте «ранний return» — это упрощает код:</p>
<div class="code"><span class="cmt">// Плохо — лестница</span>
<span class="kw">int</span> <span class="fn">process</span>(<span class="kw">int</span>* p) {
    <span class="kw">if</span> (p != <span class="kw">NULL</span>) {
        <span class="kw">if</span> (*p &gt; <span class="num">0</span>) {
            <span class="kw">if</span> (*p &lt; <span class="num">1000</span>) {
                <span class="kw">return</span> *p * <span class="num">2</span>;
            }
        }
    }
    <span class="kw">return</span> <span class="num">-1</span>;
}

<span class="cmt">// Лучше — плоско</span>
<span class="kw">int</span> <span class="fn">process</span>(<span class="kw">int</span>* p) {
    <span class="kw">if</span> (p == <span class="kw">NULL</span>) <span class="kw">return</span> <span class="num">-1</span>;
    <span class="kw">if</span> (*p &lt;= <span class="num">0</span>) <span class="kw">return</span> <span class="num">-1</span>;
    <span class="kw">if</span> (*p &gt;= <span class="num">1000</span>) <span class="kw">return</span> <span class="num">-1</span>;
    <span class="kw">return</span> *p * <span class="num">2</span>;
}</div>
<h3>switch вместо длинных if/else</h3>
<p>Если у вас 4+ ветки по одной переменной — <code>switch</code> читается лучше и компилятор может оптимизировать его в jump-таблицу.</p>
<h3>Порядок условий имеет значение</h3>
<p>В <code>&amp;&amp;</code> ставьте «дешёвые» и «отсеивающие» проверки слева:</p>
<div class="code"><span class="cmt">// Если p == NULL, *p не вычисляется</span>
<span class="kw">if</span> (p != <span class="kw">NULL</span> &amp;&amp; <span class="fn">strlen</span>(p) &gt; <span class="num">0</span>) ...</div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body">Длинные сложные условия — это признак, что пора вынести логику в функцию с говорящим именем: <code>if (is_valid_user(u))</code> вместо <code>if (u != NULL &amp;&amp; u-&gt;age &gt;= 18 &amp;&amp; u-&gt;active)</code>.</div>
</div>`}
],
keyPoints:[
"В C ноль — это «ложь», любое другое значение — «истина»",
"<code>=</code> присваивает, <code>==</code> сравнивает — путаница вызывает реальные баги",
"Всегда ставьте скобки <code>{}</code>, даже если в ветке одна строка",
"<code>switch</code> работает только с целыми типами и требует <code>break</code>",
"Тернарный <code>?:</code> возвращает значение, в отличие от if",
"<code>&amp;&amp;</code> и <code>||</code> ленивые — полезно для проверки указателей",
"Не сравнивайте дробные через <code>==</code> — используйте <code>fabs(a-b) &lt; eps</code>"
]
};
