window.THEORY=window.THEORY||{};
window.THEORY[2]={
intro:"Операторы — это символы, выполняющие операции над операндами. C богат на операторы: арифметические, логические, битовые, сравнения, присваивания. Понимание их работы и приоритета — фундамент любой программы.",
sections:[
{title:"Введение",content:`
<p>Программа на C — это, по сути, последовательность <b>выражений</b> и <b>операторов</b>. Выражение — это всё, что имеет значение: <code>2 + 3</code>, <code>x * y</code>, <code>a == b</code>, <code>printf("hi")</code>.</p>
<p>Операторы делятся на группы:</p>
<ul>
 <li><b>Арифметические</b>: <code>+ - * / %</code></li>
 <li><b>Сравнения</b>: <code>== != &lt; &gt; &lt;= &gt;=</code></li>
 <li><b>Логические</b>: <code>&amp;&amp; || !</code></li>
 <li><b>Битовые</b>: <code>&amp; | ^ ~ &lt;&lt; &gt;&gt;</code></li>
 <li><b>Присваивания</b>: <code>= += -= *= /= %=</code></li>
 <li><b>Инкремент/декремент</b>: <code>++ --</code></li>
 <li><b>Прочие</b>: <code>?:</code> (тернарный), <code>,</code> (запятая), <code>sizeof</code></li>
</ul>`},
{title:"Арифметические операторы",content:`
<table>
 <tr><th>Оператор</th><th>Действие</th><th>Пример</th><th>Результат</th></tr>
 <tr><td><code>+</code></td><td>Сложение</td><td><code>7 + 3</code></td><td><code>10</code></td></tr>
 <tr><td><code>-</code></td><td>Вычитание</td><td><code>7 - 3</code></td><td><code>4</code></td></tr>
 <tr><td><code>*</code></td><td>Умножение</td><td><code>7 * 3</code></td><td><code>21</code></td></tr>
 <tr><td><code>/</code></td><td>Деление</td><td><code>7 / 3</code></td><td><code>2</code> (для int)</td></tr>
 <tr><td><code>%</code></td><td>Остаток</td><td><code>7 % 3</code></td><td><code>1</code></td></tr>
</table>
<div class="box warn">
 <div class="box-ic">⚠️</div>
 <div class="box-body">Оператор <code>%</code> работает <b>только с целыми числами</b>. Для дробных используйте <code>fmod()</code> из <code>&lt;math.h&gt;</code>.</div>
</div>
<h3>Инкремент и декремент</h3>
<div class="code"><span class="kw">int</span> i = <span class="num">5</span>;
i++;       <span class="cmt">// i стало 6</span>
++i;       <span class="cmt">// i стало 7</span>
i--;       <span class="cmt">// i стало 6</span>

<span class="cmt">// Префикс vs постфикс:</span>
<span class="kw">int</span> a = <span class="num">5</span>;
<span class="kw">int</span> b = a++;  <span class="cmt">// b = 5, потом a = 6 (постфикс: сначала использовать)</span>
<span class="kw">int</span> c = ++a;  <span class="cmt">// сначала a = 7, потом c = 7 (префикс)</span></div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body">Когда результат не используется — <code>++a</code> и <code>a++</code> работают одинаково. Разница только в выражениях, где значение читается.</div>
</div>`},
{title:"Сравнения и логические",content:`
<h3>Операторы сравнения</h3>
<p>Возвращают <code>1</code>, если истинно, и <code>0</code>, если ложно (тип <code>int</code>):</p>
<table>
 <tr><td><code>==</code></td><td>равно</td><td><code>a == b</code></td></tr>
 <tr><td><code>!=</code></td><td>не равно</td><td><code>a != b</code></td></tr>
 <tr><td><code>&lt;</code> <code>&gt;</code></td><td>меньше / больше</td><td><code>a &lt; b</code></td></tr>
 <tr><td><code>&lt;=</code> <code>&gt;=</code></td><td>меньше/больше или равно</td><td><code>a &lt;= b</code></td></tr>
</table>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body"><b>Классическая ловушка:</b> <code>if (x = 5)</code> — это <b>присваивание</b>, а не сравнение. Условие всегда истинно (5), а в <code>x</code> запишется 5. Правильно: <code>if (x == 5)</code>. Компилятор обычно предупреждает.</div>
</div>
<h3>Логические операторы</h3>
<table>
 <tr><td><code>&amp;&amp;</code></td><td>логическое И</td><td>оба истинны</td></tr>
 <tr><td><code>||</code></td><td>логическое ИЛИ</td><td>хотя бы один истинен</td></tr>
 <tr><td><code>!</code></td><td>логическое НЕ</td><td>инверсия</td></tr>
</table>
<div class="code"><span class="kw">int</span> age = <span class="num">25</span>, hasLicense = <span class="num">1</span>;
<span class="kw">if</span> (age &gt;= <span class="num">18</span> &amp;&amp; hasLicense) {
    <span class="fn">printf</span>(<span class="str">"Можно водить\\n"</span>);
}
<span class="kw">if</span> (!hasLicense) {
    <span class="fn">printf</span>(<span class="str">"Нет прав\\n"</span>);
}</div>
<h3>Ленивое вычисление</h3>
<p>Операторы <code>&amp;&amp;</code> и <code>||</code> вычисляются <b>лениво</b>: если результат уже известен по левому операнду, правый не вычисляется.</p>
<div class="code"><span class="kw">if</span> (p != <span class="kw">NULL</span> &amp;&amp; *p &gt; <span class="num">0</span>) {       <span class="cmt">// безопасно</span>
    <span class="cmt">// если p == NULL, *p даже не проверяется</span>
}</div>`},
{title:"Битовые операторы",content:`
<p>Работают напрямую с битами целых чисел. Используются для упаковки данных, флагов, оптимизаций.</p>
<table>
 <tr><th>Оп.</th><th>Действие</th><th>Пример</th><th>Результат</th></tr>
 <tr><td><code>&amp;</code></td><td>битовое И</td><td><code>12 &amp; 10</code></td><td><code>8</code></td></tr>
 <tr><td><code>|</code></td><td>битовое ИЛИ</td><td><code>12 | 10</code></td><td><code>14</code></td></tr>
 <tr><td><code>^</code></td><td>битовое XOR</td><td><code>12 ^ 10</code></td><td><code>6</code></td></tr>
 <tr><td><code>~</code></td><td>битовое НЕ</td><td><code>~5</code></td><td><code>-6</code></td></tr>
 <tr><td><code>&lt;&lt;</code></td><td>сдвиг влево</td><td><code>1 &lt;&lt; 3</code></td><td><code>8</code></td></tr>
 <tr><td><code>&gt;&gt;</code></td><td>сдвиг вправо</td><td><code>16 &gt;&gt; 2</code></td><td><code>4</code></td></tr>
</table>
<h3>Битовые трюки</h3>
<div class="code"><span class="cmt">// Установить n-й бит</span>
x |= (<span class="num">1</span> &lt;&lt; n);

<span class="cmt">// Очистить n-й бит</span>
x &amp;= ~(<span class="num">1</span> &lt;&lt; n);

<span class="cmt">// Проверить n-й бит</span>
<span class="kw">if</span> (x &amp; (<span class="num">1</span> &lt;&lt; n)) { ... }

<span class="cmt">// Чётность</span>
<span class="kw">if</span> (x &amp; <span class="num">1</span>) <span class="cmt">// нечётное</span></div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body">Подробнее битовые операции рассмотрены в теме 17. Здесь нужно лишь различать <code>&amp;&amp;</code> (логическое И) и <code>&amp;</code> (битовое И) — это разные операторы!</div>
</div>`},
{title:"Присваивание и составные операторы",content:`
<p>Знак <code>=</code> в C — это оператор присваивания, а не «равенства».</p>
<div class="code"><span class="kw">int</span> x;
x = <span class="num">10</span>;       <span class="cmt">// присвоить 10</span>
x = x + <span class="num">5</span>;   <span class="cmt">// прибавить 5</span></div>
<p>Для частых операций «изменить и присвоить» есть короткие формы:</p>
<table>
 <tr><th>Сокращение</th><th>Полная форма</th></tr>
 <tr><td><code>x += 5</code></td><td><code>x = x + 5</code></td></tr>
 <tr><td><code>x -= 3</code></td><td><code>x = x - 3</code></td></tr>
 <tr><td><code>x *= 2</code></td><td><code>x = x * 2</code></td></tr>
 <tr><td><code>x /= 4</code></td><td><code>x = x / 4</code></td></tr>
 <tr><td><code>x %= 7</code></td><td><code>x = x % 7</code></td></tr>
 <tr><td><code>x &lt;&lt;= 1</code></td><td><code>x = x &lt;&lt; 1</code></td></tr>
 <tr><td><code>x &amp;= mask</code></td><td><code>x = x &amp; mask</code></td></tr>
</table>
<h3>Тернарный оператор</h3>
<p>Сокращённая форма if/else, возвращает значение:</p>
<div class="code"><span class="kw">int</span> max = (a &gt; b) ? a : b;
<span class="kw">int</span> abs_x = (x &lt; <span class="num">0</span>) ? -x : x;
<span class="fn">printf</span>(<span class="str">"%s\\n"</span>, (n % <span class="num">2</span> == <span class="num">0</span>) ? <span class="str">"чётное"</span> : <span class="str">"нечётное"</span>);</div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body">Не злоупотребляйте вложенными тернарниками: <code>a ? b ? c : d : e</code> читать тяжело. Используйте обычный if/else, если стало сложно.</div>
</div>`},
{title:"Приоритет операторов",content:`
<p>Что выведет <code>printf("%d", 2 + 3 * 4)</code>? Ответ: 14, потому что <code>*</code> имеет более высокий приоритет, чем <code>+</code> — он выполняется первым.</p>
<h3>Таблица приоритетов (от высокого к низкому)</h3>
<table>
 <tr><th>Уровень</th><th>Операторы</th><th>Ассоциативность</th></tr>
 <tr><td>1</td><td><code>()</code> <code>[]</code> <code>-&gt;</code> <code>.</code></td><td>→</td></tr>
 <tr><td>2</td><td><code>!</code> <code>~</code> <code>++</code> <code>--</code> унарные <code>+ - * &amp;</code> <code>sizeof</code></td><td>←</td></tr>
 <tr><td>3</td><td><code>*</code> <code>/</code> <code>%</code></td><td>→</td></tr>
 <tr><td>4</td><td><code>+</code> <code>-</code></td><td>→</td></tr>
 <tr><td>5</td><td><code>&lt;&lt;</code> <code>&gt;&gt;</code></td><td>→</td></tr>
 <tr><td>6</td><td><code>&lt;</code> <code>&lt;=</code> <code>&gt;</code> <code>&gt;=</code></td><td>→</td></tr>
 <tr><td>7</td><td><code>==</code> <code>!=</code></td><td>→</td></tr>
 <tr><td>8</td><td><code>&amp;</code></td><td>→</td></tr>
 <tr><td>9</td><td><code>^</code></td><td>→</td></tr>
 <tr><td>10</td><td><code>|</code></td><td>→</td></tr>
 <tr><td>11</td><td><code>&amp;&amp;</code></td><td>→</td></tr>
 <tr><td>12</td><td><code>||</code></td><td>→</td></tr>
 <tr><td>13</td><td><code>?:</code></td><td>←</td></tr>
 <tr><td>14</td><td><code>=</code> <code>+=</code> <code>-=</code> ...</td><td>←</td></tr>
 <tr><td>15</td><td><code>,</code></td><td>→</td></tr>
</table>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body"><b>Главный совет.</b> Не пытайтесь запомнить всю таблицу — ставьте скобки. <code>(a &amp; b) == 0</code> понятнее, чем <code>a &amp; b == 0</code> (которое из-за приоритета означает <code>a &amp; (b == 0)</code>!).</div>
</div>`},
{title:"Частые ошибки",content:`
<ul>
 <li><b><code>=</code> вместо <code>==</code>.</b> <code>if (x = 5)</code> — присваивание. Используйте <code>x == 5</code> или приём «yoda»: <code>if (5 == x)</code>.</li>
 <li><b><code>&amp;</code> вместо <code>&amp;&amp;</code>.</b> Битовое И отличается от логического И. <code>1 &amp; 2</code> = 0, но <code>1 &amp;&amp; 2</code> = 1.</li>
 <li><b>Целочисленное деление.</b> <code>5 / 2</code> = 2, не 2.5. Используйте <code>5.0 / 2</code>.</li>
 <li><b>Игнорирование приоритета.</b> <code>a + b &lt;&lt; 1</code> — это <code>(a + b) &lt;&lt; 1</code>, а не <code>a + (b &lt;&lt; 1)</code>!</li>
 <li><b>Переполнение.</b> <code>INT_MAX + 1</code> — UB. Для больших значений берите <code>long long</code>.</li>
 <li><b>Зависимость от порядка вычислений.</b> <code>i = i++ + ++i;</code> — UB, компилятор может вычислять в любом порядке.</li>
 <li><b>Сравнение signed и unsigned.</b> <code>-1 &lt; 1u</code> — даст false! Минус приводится к огромному unsigned.</li>
</ul>`}
],
keyPoints:[
"<code>==</code> сравнивает, <code>=</code> присваивает — это разные операторы",
"<code>/</code> для целых делит без остатка, для дробных — обычное деление",
"<code>%</code> работает только с целыми, для дробных — <code>fmod()</code>",
"<code>&amp;&amp; ||</code> ленивые: правый операнд может не вычисляться",
"<code>&amp; |</code> — битовые, <code>&amp;&amp; ||</code> — логические, не путайте",
"<code>++</code> и <code>--</code> в выражениях могут вызвать UB — не злоупотребляйте",
"Когда сомневаетесь в приоритете — ставьте скобки"
]
};
