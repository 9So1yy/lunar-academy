window.THEORY=window.THEORY||{};
window.THEORY[12]={
intro:"Заголовок <code>&lt;string.h&gt;</code> содержит набор функций для работы со строками: длина, копирование, сравнение, поиск. Знать их обязательно — но не менее важно понимать опасности переполнения буфера.",
sections:[
{title:"Основные функции string.h",content:`
<table>
 <tr><th>Функция</th><th>Что делает</th></tr>
 <tr><td><code>strlen(s)</code></td><td>длина строки (без <code>'\\0'</code>)</td></tr>
 <tr><td><code>strcpy(dst, src)</code></td><td>копирует src в dst</td></tr>
 <tr><td><code>strncpy(dst, src, n)</code></td><td>копирует максимум n байт</td></tr>
 <tr><td><code>strcat(dst, src)</code></td><td>добавляет src в конец dst</td></tr>
 <tr><td><code>strcmp(a, b)</code></td><td>0 если равны; &lt;0 или &gt;0</td></tr>
 <tr><td><code>strncmp(a, b, n)</code></td><td>сравнить первые n символов</td></tr>
 <tr><td><code>strchr(s, c)</code></td><td>указатель на первое <code>c</code></td></tr>
 <tr><td><code>strstr(s, sub)</code></td><td>указатель на первое вхождение подстроки</td></tr>
</table>
<div class="code"><span class="pp">#include</span> &lt;<span class="str">string.h</span>&gt;

<span class="kw">char</span> name[<span class="num">100</span>] = <span class="str">"Hello, "</span>;
<span class="fn">strcat</span>(name, <span class="str">"World!"</span>);
<span class="fn">printf</span>(<span class="str">"%zu: %s\\n"</span>, <span class="fn">strlen</span>(name), name);
<span class="cmt">// 13: Hello, World!</span></div>`},
{title:"Сравнение строк",content:`
<p><b>Не используйте</b> <code>==</code> для строк! Он сравнивает <i>адреса</i>, а не содержимое.</p>
<div class="code"><span class="kw">char</span> a[] = <span class="str">"hello"</span>;
<span class="kw">char</span> b[] = <span class="str">"hello"</span>;

<span class="kw">if</span> (a == b) ...                <span class="cmt">// ❌ всегда ложно (разные адреса)</span>
<span class="kw">if</span> (<span class="fn">strcmp</span>(a, b) == <span class="num">0</span>) ...    <span class="cmt">// ✅ правильно</span></div>
<p><code>strcmp</code> возвращает:</p>
<ul>
 <li><code>0</code> — строки равны</li>
 <li>отрицательное — первая «меньше» (лексикографически)</li>
 <li>положительное — первая «больше»</li>
</ul>`},
{title:"Опасности переполнения",content:`
<p><code>strcpy</code> и <code>strcat</code> не проверяют размер приёмника. Если он мал — переполнение буфера, UB.</p>
<div class="code"><span class="kw">char</span> buf[<span class="num">10</span>];
<span class="fn">strcpy</span>(buf, <span class="str">"This is way too long!"</span>);  <span class="cmt">// 💥 Buffer overflow!</span></div>
<div class="box danger"><div class="box-ic">🚫</div><div class="box-body">Переполнение буфера — главная причина уязвимостей в системах на C. Всегда используйте <b>безопасные версии</b>: <code>strncpy</code>, <code>strncat</code>, <code>snprintf</code>. Или проверяйте размеры вручную.</div></div>
<h3>Конвертация число ↔ строка</h3>
<table>
 <tr><td><code>atoi("123")</code></td><td>→ 123 (int)</td></tr>
 <tr><td><code>atof("3.14")</code></td><td>→ 3.14 (double)</td></tr>
 <tr><td><code>sprintf(buf, "%d", n)</code></td><td>число → строка</td></tr>
 <tr><td><code>sscanf(s, "%d", &amp;n)</code></td><td>строка → число</td></tr>
</table>`}
],
keyPoints:[
"<code>string.h</code> — основной заголовок для работы со строками",
"<code>strcmp</code>, не <code>==</code> — для сравнения содержимого",
"<code>strcpy</code> и <code>strcat</code> опасны без контроля размера",
"Безопасные версии: <code>strncpy</code>, <code>strncat</code>, <code>snprintf</code>",
"<code>strlen</code> не считает завершающий нуль",
"<code>atoi</code>/<code>atof</code> конвертируют строку в число"
]
};
