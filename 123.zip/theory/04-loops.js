window.THEORY=window.THEORY||{};
window.THEORY[4]={
intro:"Циклы позволяют выполнять блок кода многократно. Это одна из самых мощных конструкций программирования: без них невозможны обход массивов, поиск, накопление сумм, работа с пользовательским вводом. В C три вида циклов: <code>while</code>, <code>do-while</code> и <code>for</code>.",
sections:[
{title:"Введение",content:`
<p>Когда нужно выполнить действие <b>несколько раз</b> — циклы незаменимы. Представьте, что нужно вывести числа от 1 до 100. Без цикла это 100 строк <code>printf</code>; с циклом — три.</p>
<div class="code"><span class="cmt">// Без цикла — кошмар</span>
<span class="fn">printf</span>(<span class="str">"1\\n"</span>);
<span class="fn">printf</span>(<span class="str">"2\\n"</span>);
...
<span class="fn">printf</span>(<span class="str">"100\\n"</span>);

<span class="cmt">// С циклом — красиво</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">1</span>; i &lt;= <span class="num">100</span>; i++) {
    <span class="fn">printf</span>(<span class="str">"%d\\n"</span>, i);
}</div>
<p>Любой цикл состоит из:</p>
<ul>
 <li><b>Условие</b> — пока истинно, цикл повторяется;</li>
 <li><b>Тело</b> — блок кода, который повторяется;</li>
 <li><b>Изменение</b> — что-то должно менять условие, иначе цикл бесконечный.</li>
</ul>`},
{title:"while",content:`
<p>Самый простой цикл: «пока условие истинно — выполняй тело».</p>
<div class="code"><span class="kw">int</span> i = <span class="num">0</span>;
<span class="kw">while</span> (i &lt; <span class="num">5</span>) {
    <span class="fn">printf</span>(<span class="str">"%d "</span>, i);
    i++;
}
<span class="cmt">// Вывод: 0 1 2 3 4</span></div>
<p>Условие проверяется <b>до</b> выполнения тела. Если оно сразу ложно — тело не выполнится ни разу.</p>
<h3>Чтение до конца</h3>
<p>Классическое применение — чтение данных до маркера завершения:</p>
<div class="code"><span class="kw">int</span> n;
<span class="kw">while</span> (<span class="fn">scanf</span>(<span class="str">"%d"</span>, &amp;n) == <span class="num">1</span>) {
    <span class="fn">printf</span>(<span class="str">"Получили: %d\\n"</span>, n);
}
<span class="cmt">// Выходим, когда scanf вернёт 0 (не число) или EOF</span></div>
<h3>Условие — любое выражение</h3>
<div class="code"><span class="kw">while</span> (n &gt; <span class="num">1</span>) {
    <span class="kw">if</span> (n % <span class="num">2</span> == <span class="num">0</span>) n /= <span class="num">2</span>;
    <span class="kw">else</span>           n = <span class="num">3</span>*n + <span class="num">1</span>;
    <span class="fn">printf</span>(<span class="str">"%d "</span>, n);
}
<span class="cmt">// Гипотеза Коллатца</span></div>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body"><b>Бесконечный цикл</b>: если внутри тела ничего не меняет условие — программа зависает. <code>while (i &lt; 5) printf("hi");</code> — нет <code>i++</code>, цикл бесконечен.</div>
</div>`},
{title:"do-while",content:`
<p>То же самое, но условие проверяется <b>после</b> тела. Это значит, тело выполнится хотя бы один раз.</p>
<div class="code"><span class="kw">int</span> n;
<span class="kw">do</span> {
    <span class="fn">printf</span>(<span class="str">"Введите положительное число: "</span>);
    <span class="fn">scanf</span>(<span class="str">"%d"</span>, &amp;n);
} <span class="kw">while</span> (n &lt;= <span class="num">0</span>);

<span class="fn">printf</span>(<span class="str">"Спасибо: %d\\n"</span>, n);</div>
<p>Здесь мы должны хотя бы раз попросить ввод — и обычный <code>while</code> с этим не справится без дублирования кода.</p>
<h3>do-while vs while</h3>
<table>
 <tr><th></th><th>while</th><th>do-while</th></tr>
 <tr><td>Условие проверяется</td><td>До тела</td><td>После тела</td></tr>
 <tr><td>Минимум итераций</td><td>0</td><td>1</td></tr>
 <tr><td>Когда использовать</td><td>«Делать пока условие верно»</td><td>«Делать, потом проверить»</td></tr>
</table>
<div class="box warn">
 <div class="box-ic">⚠️</div>
 <div class="box-body">Не забудьте <b>точку с запятой</b> после <code>while(...)</code> в do-while! Это единственное место в C, где после скобок ставится <code>;</code>.</div>
</div>`},
{title:"for",content:`
<p>Самый мощный и компактный цикл. Объединяет инициализацию, условие и шаг в одной строке.</p>
<div class="code"><span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; <span class="num">10</span>; i++) {
    <span class="fn">printf</span>(<span class="str">"%d\\n"</span>, i);
}</div>
<p>Три части:</p>
<ol>
 <li><b>Инициализация</b> (<code>int i = 0</code>) — выполняется один раз перед циклом;</li>
 <li><b>Условие</b> (<code>i &lt; 10</code>) — проверяется перед каждой итерацией;</li>
 <li><b>Шаг</b> (<code>i++</code>) — выполняется после каждой итерации.</li>
</ol>
<p>Любую часть можно опустить, но <b>точки с запятой</b> обязательны:</p>
<div class="code"><span class="kw">for</span> (;;) {              <span class="cmt">// бесконечный цикл</span>
    ...
}

<span class="kw">int</span> i = <span class="num">0</span>;
<span class="kw">for</span> (; i &lt; <span class="num">10</span>; i++) {  <span class="cmt">// без инициализации</span>
    ...
}</div>
<h3>Шаг и направление</h3>
<div class="code"><span class="cmt">// От 10 до 1 (по убыванию)</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">10</span>; i &gt;= <span class="num">1</span>; i--) ...

<span class="cmt">// Чётные числа</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; <span class="num">20</span>; i += <span class="num">2</span>) ...

<span class="cmt">// Степени двойки</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">1</span>; i &lt; <span class="num">1000</span>; i *= <span class="num">2</span>) ...</div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body"><b>Когда какой?</b> Эмпирически:
 <ul>
  <li><code>for</code> — если знаете количество итераций (обход массива, диапазон);</li>
  <li><code>while</code> — если итерации зависят от внешних условий;</li>
  <li><code>do-while</code> — когда нужно «сделать, потом проверить».</li>
 </ul></div>
</div>`},
{title:"break и continue",content:`
<p>Иногда нужно прервать цикл досрочно или пропустить итерацию.</p>
<h3>break — досрочный выход</h3>
<div class="code"><span class="cmt">// Поиск элемента в массиве</span>
<span class="kw">int</span> found = <span class="num">-1</span>;
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n; i++) {
    <span class="kw">if</span> (arr[i] == target) {
        found = i;
        <span class="kw">break</span>;     <span class="cmt">// нашли — выходим</span>
    }
}</div>
<p><code>break</code> выходит из <b>самого внутреннего</b> цикла (или switch).</p>
<h3>continue — пропустить итерацию</h3>
<div class="code"><span class="cmt">// Печатать только чётные</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">1</span>; i &lt;= <span class="num">10</span>; i++) {
    <span class="kw">if</span> (i % <span class="num">2</span> != <span class="num">0</span>) <span class="kw">continue</span>;  <span class="cmt">// пропуск</span>
    <span class="fn">printf</span>(<span class="str">"%d "</span>, i);
}
<span class="cmt">// Вывод: 2 4 6 8 10</span></div>
<p><code>continue</code> переходит к следующей итерации, минуя оставшийся код тела.</p>
<div class="box warn">
 <div class="box-ic">⚠️</div>
 <div class="box-body">В <code>while</code> и <code>do-while</code> <code>continue</code> переходит к условию. В <code>for</code> — сначала выполняется <b>шаг</b>, потом условие. Если шаг забыт — будет бесконечный цикл.</div>
</div>`},
{title:"Вложенные циклы",content:`
<p>Циклы можно вкладывать друг в друга. Это нужно, например, для двумерных массивов, таблиц, паттернов.</p>
<div class="code"><span class="cmt">// Таблица умножения</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">1</span>; i &lt;= <span class="num">9</span>; i++) {
    <span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">1</span>; j &lt;= <span class="num">9</span>; j++) {
        <span class="fn">printf</span>(<span class="str">"%3d "</span>, i * j);
    }
    <span class="fn">printf</span>(<span class="str">"\\n"</span>);
}</div>
<h3>Сложность</h3>
<p>Вложенные циклы означают <b>умножение</b> числа итераций. Два цикла по N — это N² итераций. Это база для алгоритмов сортировки (bubble, selection, insertion — все O(N²)).</p>
<div class="code"><span class="cmt">// Сортировка пузырьком</span>
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n - <span class="num">1</span>; i++) {
    <span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">0</span>; j &lt; n - i - <span class="num">1</span>; j++) {
        <span class="kw">if</span> (arr[j] &gt; arr[j+<span class="num">1</span>]) {
            <span class="kw">int</span> t = arr[j];
            arr[j] = arr[j+<span class="num">1</span>];
            arr[j+<span class="num">1</span>] = t;
        }
    }
}</div>
<h3>Выход из вложенных циклов</h3>
<p><code>break</code> выходит только из одного цикла. Для нескольких уровней — используйте флаг или <code>goto</code>:</p>
<div class="code"><span class="kw">int</span> done = <span class="num">0</span>;
<span class="kw">for</span> (<span class="kw">int</span> i = <span class="num">0</span>; i &lt; n &amp;&amp; !done; i++) {
    <span class="kw">for</span> (<span class="kw">int</span> j = <span class="num">0</span>; j &lt; m; j++) {
        <span class="kw">if</span> (matrix[i][j] == target) {
            done = <span class="num">1</span>;
            <span class="kw">break</span>;
        }
    }
}</div>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body"><code>goto</code> обычно считается плохим стилем, но для выхода из глубоких циклов он <b>уместен</b>. Это один из немногих случаев, где goto оправдан.</div>
</div>`},
{title:"Частые ошибки",content:`
<ul>
 <li><b>Off-by-one.</b> <code>for (i = 0; i &lt;= n; i++)</code> с массивом размера n — выход за границу. Должно быть <code>i &lt; n</code>.</li>
 <li><b>Бесконечный цикл.</b> Забыли изменить переменную условия — программа зависает.</li>
 <li><b>Точка с запятой после for.</b> <code>for (i = 0; i &lt; n; i++);</code> — пустое тело, следующая строка выполнится только один раз.</li>
 <li><b>Изменение переменной цикла внутри.</b> <code>for (i = 0; i &lt; 10; i++) { i = 5; }</code> — обычно ошибка.</li>
 <li><b>Сравнение float в условии.</b> <code>for (f = 0.0; f != 1.0; f += 0.1)</code> — никогда не завершится! Используйте <code>&lt;</code>.</li>
 <li><b>continue в do-while</b> с неправильным шагом — приводит к бесконечному циклу.</li>
 <li><b>Объявление в for до C99.</b> <code>for (int i = ...)</code> требует флаг <code>-std=c99</code> и новее.</li>
</ul>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body"><b>Off-by-one</b> — настолько частая ошибка, что у неё есть мем. Всегда трижды проверяйте границы массивов. Привычка: «индексы массива размера N — от 0 до N-1 включительно».</div>
</div>`}
],
keyPoints:[
"<code>while</code> проверяет условие до тела, <code>do-while</code> — после",
"<code>for</code> объединяет инициализацию, условие и шаг в одной строке",
"<code>break</code> выходит из цикла, <code>continue</code> переходит к следующей итерации",
"<code>break</code> и <code>continue</code> действуют только на <b>самый внутренний</b> цикл",
"Любая часть <code>for(;;)</code> может быть опущена",
"Off-by-one — самая частая ошибка. Индексы 0..N-1, не 0..N",
"Не сравнивайте дробные в условии цикла — будут бесконечные циклы"
]
};
