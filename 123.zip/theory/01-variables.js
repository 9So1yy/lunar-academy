window.THEORY=window.THEORY||{};
window.THEORY[1]={
intro:"Переменные — это именованные ячейки памяти, в которых хранятся данные. C — статически типизированный язык: при объявлении переменной обязательно указывается её тип, и этот тип не может измениться в процессе работы программы.",
sections:[
{title:"Введение",content:`
<p>Любая программа работает с данными. Чтобы хранить их, нам нужны <b>переменные</b> — именованные участки памяти. В отличие от Python или JavaScript, в C каждая переменная имеет жёсткий <b>тип</b>, который определяет:</p>
<ul>
 <li>сколько <b>байт памяти</b> занимает значение;</li>
 <li>какие <b>операции</b> с ним разрешены;</li>
 <li>как <b>интерпретировать</b> биты — как целое, дробное число или символ.</li>
</ul>
<p>Это даёт C его легендарную скорость и контроль над железом, но требует осознанности от программиста.</p>
<div class="code"><span class="code-lbl">main.c</span>
<span class="pp">#include</span> &lt;<span class="str">stdio.h</span>&gt;

<span class="kw">int</span> <span class="fn">main</span>(<span class="kw">void</span>) {
    <span class="kw">int</span> age = <span class="num">25</span>;
    <span class="kw">float</span> height = <span class="num">1.75f</span>;
    <span class="kw">char</span> grade = <span class="str">'A'</span>;

    <span class="fn">printf</span>(<span class="str">"%d лет, рост %.2f, оценка %c\\n"</span>, age, height, grade);
    <span class="kw">return</span> <span class="num">0</span>;
}</div>
<p>В этом примере три переменные разных типов хранят возраст, рост и оценку.</p>`},
{title:"Базовые типы данных",content:`
<p>Стандарт C определяет несколько фундаментальных типов. Размеры могут немного отличаться на разных платформах, но для типичной 64-битной системы:</p>
<table>
 <tr><th>Тип</th><th>Размер</th><th>Диапазон</th><th>printf</th></tr>
 <tr><td><code>char</code></td><td>1 байт</td><td>−128 … 127</td><td><code>%c</code> / <code>%d</code></td></tr>
 <tr><td><code>unsigned char</code></td><td>1 байт</td><td>0 … 255</td><td><code>%u</code></td></tr>
 <tr><td><code>short</code></td><td>2 байта</td><td>±32 767</td><td><code>%hd</code></td></tr>
 <tr><td><code>int</code></td><td>4 байта</td><td>±2,1 миллиарда</td><td><code>%d</code></td></tr>
 <tr><td><code>unsigned int</code></td><td>4 байта</td><td>0 … 4,3 миллиарда</td><td><code>%u</code></td></tr>
 <tr><td><code>long</code></td><td>4 или 8 байт</td><td>±9·10¹⁸ (на 64-bit)</td><td><code>%ld</code></td></tr>
 <tr><td><code>long long</code></td><td>8 байт</td><td>±9·10¹⁸</td><td><code>%lld</code></td></tr>
 <tr><td><code>float</code></td><td>4 байта</td><td>~7 значащих цифр</td><td><code>%f</code></td></tr>
 <tr><td><code>double</code></td><td>8 байт</td><td>~15 значащих цифр</td><td><code>%lf</code> (scanf) / <code>%f</code> (printf)</td></tr>
</table>
<h3>Целые vs дробные</h3>
<p><b>Целые</b> (<code>int</code>, <code>long</code>...) хранят натуральные числа без дробной части. <b>Дробные</b> (<code>float</code>, <code>double</code>) используют формат IEEE 754 — это позволяет огромный диапазон, но с потерей точности.</p>
<h3>signed и unsigned</h3>
<p>По умолчанию <code>int</code> — это <code>signed int</code> (со знаком). Если нужны только положительные значения и удвоенный диапазон — используйте <code>unsigned</code>:</p>
<div class="code"><span class="kw">unsigned int</span> counter = <span class="num">4000000000</span>;  <span class="cmt">// 4 миллиарда — нормально</span>
<span class="kw">int</span> bad = <span class="num">4000000000</span>;            <span class="cmt">// переполнение! UB</span></div>`},
{title:"Объявление и инициализация",content:`
<p>Объявление переменной — это сообщение компилятору: «выдели память такого-то размера и зови её этим именем».</p>
<div class="code"><span class="kw">int</span> x;              <span class="cmt">// объявление без инициализации (мусор!)</span>
<span class="kw">int</span> y = <span class="num">10</span>;         <span class="cmt">// объявление + инициализация</span>
<span class="kw">int</span> a, b, c;        <span class="cmt">// несколько одного типа</span>
<span class="kw">int</span> p = <span class="num">1</span>, q = <span class="num">2</span>;   <span class="cmt">// и с инициализацией</span>
<span class="kw">const</span> <span class="kw">int</span> MAX = <span class="num">100</span>; <span class="cmt">// константа — менять нельзя</span></div>
<div class="box danger">
 <div class="box-ic">⚠️</div>
 <div class="box-body"><b>Не используйте неинициализированные переменные!</b> В C они содержат <i>любой мусор</i> — то, что осталось в памяти от прошлого использования. Это самый частый источник трудных багов.</div>
</div>
<h3>Правила имён</h3>
<ul>
 <li>Могут содержать буквы (a–z, A–Z), цифры и <code>_</code>;</li>
 <li>Не могут начинаться с цифры;</li>
 <li>C регистрозависимый: <code>count</code>, <code>Count</code>, <code>COUNT</code> — три разные переменные;</li>
 <li>Нельзя использовать ключевые слова (<code>int</code>, <code>if</code>, <code>return</code>, …) в качестве имён.</li>
</ul>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body"><b>Совет.</b> Используйте говорящие имена: <code>userAge</code> или <code>user_age</code> лучше, чем <code>x</code> или <code>a</code>. Это окупится при отладке через месяц.</div>
</div>`},
{title:"Спецификаторы printf",content:`
<p>Функция <code>printf</code> выводит значения в соответствии с «форматом». Знак <code>%</code> отмечает место подстановки, а буква после него — тип:</p>
<table>
 <tr><th>Спец.</th><th>Тип</th><th>Пример вывода</th></tr>
 <tr><td><code>%d</code> / <code>%i</code></td><td><code>int</code></td><td><code>42</code></td></tr>
 <tr><td><code>%u</code></td><td><code>unsigned int</code></td><td><code>4000000000</code></td></tr>
 <tr><td><code>%ld</code></td><td><code>long</code></td><td><code>1234567890</code></td></tr>
 <tr><td><code>%f</code></td><td><code>float/double</code></td><td><code>3.140000</code></td></tr>
 <tr><td><code>%.2f</code></td><td>дробное, 2 знака</td><td><code>3.14</code></td></tr>
 <tr><td><code>%e</code></td><td>научная нотация</td><td><code>3.14e+00</code></td></tr>
 <tr><td><code>%c</code></td><td><code>char</code></td><td><code>A</code></td></tr>
 <tr><td><code>%s</code></td><td>строка</td><td><code>hello</code></td></tr>
 <tr><td><code>%x</code></td><td>hex (нижний)</td><td><code>ff</code></td></tr>
 <tr><td><code>%X</code></td><td>hex (верхний)</td><td><code>FF</code></td></tr>
 <tr><td><code>%o</code></td><td>oct</td><td><code>377</code></td></tr>
 <tr><td><code>%p</code></td><td>указатель</td><td><code>0x7ffeef</code></td></tr>
 <tr><td><code>%%</code></td><td>символ %</td><td><code>%</code></td></tr>
</table>
<h3>Ширина и точность</h3>
<div class="code"><span class="fn">printf</span>(<span class="str">"|%5d|"</span>, <span class="num">42</span>);       <span class="cmt">// |   42|  — ширина 5</span>
<span class="fn">printf</span>(<span class="str">"|%-5d|"</span>, <span class="num">42</span>);      <span class="cmt">// |42   |  — слева</span>
<span class="fn">printf</span>(<span class="str">"|%05d|"</span>, <span class="num">42</span>);      <span class="cmt">// |00042| — нули</span>
<span class="fn">printf</span>(<span class="str">"%.3f"</span>, <span class="num">3.14159</span>);    <span class="cmt">// 3.142   — округление</span>
<span class="fn">printf</span>(<span class="str">"%8.2f"</span>, <span class="num">3.14</span>);      <span class="cmt">//     3.14 — ширина 8, 2 знака</span></div>
<h3>Управляющие последовательности</h3>
<table>
 <tr><td><code>\\n</code></td><td>новая строка</td></tr>
 <tr><td><code>\\t</code></td><td>табуляция</td></tr>
 <tr><td><code>\\\\</code></td><td>обратный слэш</td></tr>
 <tr><td><code>\\"</code></td><td>кавычка внутри строки</td></tr>
 <tr><td><code>\\0</code></td><td>нулевой символ (конец строки)</td></tr>
</table>`},
{title:"Приведение типов и sizeof",content:`
<h3>Оператор sizeof</h3>
<p>Возвращает размер типа или переменной в байтах:</p>
<div class="code"><span class="fn">printf</span>(<span class="str">"int = %zu байт\\n"</span>, <span class="kw">sizeof</span>(<span class="kw">int</span>));      <span class="cmt">// 4</span>
<span class="fn">printf</span>(<span class="str">"double = %zu байт\\n"</span>, <span class="kw">sizeof</span>(<span class="kw">double</span>));<span class="cmt">// 8</span>
<span class="kw">int</span> arr[<span class="num">10</span>];
<span class="fn">printf</span>(<span class="str">"arr = %zu байт\\n"</span>, <span class="kw">sizeof</span>(arr));        <span class="cmt">// 40</span></div>
<p>Спецификатор <code>%zu</code> предназначен именно для <code>size_t</code>, который возвращает <code>sizeof</code>.</p>
<h3>Неявное преобразование</h3>
<p>Когда смешиваются разные типы, C автоматически расширяет «меньший» до «большего» (например, <code>int</code> → <code>double</code>). Это называется <b>усреднение типов</b> (type promotion).</p>
<div class="code"><span class="kw">int</span> a = <span class="num">5</span>;
<span class="kw">double</span> b = <span class="num">2.0</span>;
<span class="kw">double</span> r = a + b;   <span class="cmt">// a сначала становится double, r = 7.0</span></div>
<h3>Явное приведение (cast)</h3>
<p>Иногда нужно явно сказать: «считай это значение другим типом». Это пишется в круглых скобках перед значением:</p>
<div class="code"><span class="kw">int</span> a = <span class="num">10</span>, b = <span class="num">3</span>;
<span class="kw">double</span> r1 = a / b;            <span class="cmt">// 3.0  — целочисленное деление!</span>
<span class="kw">double</span> r2 = (<span class="kw">double</span>)a / b;    <span class="cmt">// 3.333...</span>
<span class="kw">int</span> c = (<span class="kw">int</span>)<span class="num">3.7</span>;             <span class="cmt">// 3   — отбрасывание</span></div>
<div class="box warn">
 <div class="box-ic">⚠️</div>
 <div class="box-body"><b>Целочисленное деление</b> — частая ловушка. <code>7 / 2</code> в C даёт <code>3</code>, а не <code>3.5</code>. Чтобы получить дробный результат, хотя бы один операнд должен быть дробным: <code>7.0 / 2</code> или <code>(double)7 / 2</code>.</div>
</div>`},
{title:"Частые ошибки",content:`
<ul>
 <li><b>Неинициализированная переменная.</b> <code>int x; printf("%d", x);</code> — выведет случайный мусор. Всегда инициализируйте.</li>
 <li><b>Неверный спецификатор.</b> <code>printf("%d", 3.14)</code> даст бессмыслицу — нужен <code>%f</code>.</li>
 <li><b>Целочисленное деление.</b> <code>(double)(1/2)</code> — это <code>0.0</code>, а не <code>0.5</code>. Приводить нужно <b>до</b> деления.</li>
 <li><b>Переполнение.</b> <code>int x = 2147483647 + 1;</code> — UB (undefined behaviour). Для больших чисел используйте <code>long long</code>.</li>
 <li><b>Сравнение float через ==.</b> <code>0.1 + 0.2 != 0.3</code>. Сравнивайте через <code>fabs(a-b) &lt; 1e-9</code>.</li>
 <li><b>char для чисел &gt; 127.</b> Если нужны положительные значения 0–255, берите <code>unsigned char</code>.</li>
 <li><b>%lf в printf для double.</b> Достаточно <code>%f</code>; <code>%lf</code> обязателен только в <code>scanf</code>.</li>
</ul>
<div class="box danger">
 <div class="box-ic">🚫</div>
 <div class="box-body"><b>Undefined behaviour (UB)</b> — это когда стандарт C не гарантирует, что произойдёт. Программа может работать, упасть, испортить память или выдать неверный ответ. Избегайте UB любой ценой.</div>
</div>`},
{title:"Практические советы",content:`
<h3>Соглашения об именах</h3>
<p>В C-сообществе распространены два стиля:</p>
<ul>
 <li><b>snake_case</b> для переменных и функций: <code>user_name</code>, <code>get_total()</code>;</li>
 <li><b>UPPER_CASE</b> для констант и макросов: <code>MAX_SIZE</code>, <code>PI</code>;</li>
 <li><b>CamelCase</b> используется реже, в основном в коде, портированном из C++.</li>
</ul>
<p>Главное правило — единый стиль внутри проекта.</p>
<h3>Используйте const где можно</h3>
<div class="code"><span class="kw">const</span> <span class="kw">double</span> PI = <span class="num">3.14159265</span>;
<span class="kw">const</span> <span class="kw">int</span> MAX_USERS = <span class="num">1000</span>;</div>
<p><code>const</code> защищает от случайного изменения и позволяет компилятору оптимизировать код.</p>
<h3>Выбор типа — это решение</h3>
<ul>
 <li>Для счётчиков и индексов — <code>int</code> или <code>size_t</code>;</li>
 <li>Для денег и точных расчётов — <b>не</b> <code>float</code>, а целые в копейках;</li>
 <li>Для коэффициентов и физики — <code>double</code>, не <code>float</code> (точность важнее);</li>
 <li>Для байтов и буферов — <code>unsigned char</code>;</li>
 <li>Для true/false — <code>_Bool</code> (или <code>bool</code> из <code>&lt;stdbool.h&gt;</code>).</li>
</ul>
<div class="box tip">
 <div class="box-ic">💡</div>
 <div class="box-body"><b>Совет.</b> Объявляйте переменные как можно ближе к месту первого использования. Так код легче читать и сложнее наделать ошибок «забыл инициализировать».</div>
</div>`}
],
keyPoints:[
"Каждая переменная в C имеет фиксированный тип, который нельзя изменить",
"Базовые типы: char (1), short (2), int (4), long/double (8 байт)",
"Неинициализированная переменная содержит мусор — это источник багов",
"При смешивании типов происходит автоматическое расширение к большему",
"<code>7/2</code> = 3, а <code>7.0/2</code> = 3.5 — целочисленное деление коварно",
"<code>const</code> делает переменную неизменяемой и помогает оптимизатору",
"Используйте <code>%zu</code> для sizeof, <code>%f</code> для double, <code>%d</code> для int"
]
};
