$f = 'D:\PROGA_ALL\LUNAR-ACADEMy\app.html'
$c = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)

# 1. Add Next Topic button after reviewControl button in control result
$old1 = '<button class="btn ghost" onclick="reviewControl()" style="margin-left:8px">📋 Посмотреть ответы</button>
    </div>`;'
$new1 = '<button class="btn ghost" onclick="reviewControl()" style="margin-left:8px">📋 Посмотреть ответы</button>
     <button class="btn" onclick="goNextTopic()" style="margin-left:8px">→ Следующая тема</button>
    </div>`;'

if ($c.Contains($old1)) {
    $c = $c.Replace($old1, $new1)
    Write-Output "OK: Next topic button added"
} else {
    Write-Output "SKIP: Next topic button target not found"
}

# 2. Improve AI context with current task info
$old2 = 'const sys=`Ты — ИИ-наставник по C на платформе Lunar Academy. Текущая тема студента: "${t.title}". Отвечай по-русски, кратко, по делу. Используй markdown: \`код\`, **жирный**, \`\`\`c\\n...\\n\`\`\` для блоков кода.`;'
$new2 = 'const task=getCurrentTask();
  const taskCtx=task?` Текущее задание #${task.id}: "${task.title}".`:"";
  const sys=`Ты — ИИ-наставник по C на платформе Lunar Academy. Текущая тема студента: "${t.title}".${taskCtx} Отвечай по-русски, кратко, по делу. Используй markdown: \`код\`, **жирный**, \`\`\`c\\n...\\n\`\`\` для блоков кода.`;'

if ($c.Contains($old2)) {
    $c = $c.Replace($old2, $new2)
    Write-Output "OK: AI context improved"
} else {
    Write-Output "SKIP: AI context target not found"
}

[System.IO.File]::WriteAllText($f, $c, [System.Text.Encoding]::UTF8)
Write-Output "Done!"
