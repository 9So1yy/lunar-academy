import sys

f = r'D:\PROGA_ALL\LUNAR-ACADEMy\app.html'
with open(f, 'r', encoding='utf-8') as fh:
    lines = fh.readlines()

changes = 0

# Find the line with reviewControl button in the control result section
for i, line in enumerate(lines):
    if 'reviewControl()' in line and 'margin-left:8px' in line and 'btn ghost' in line:
        # Check if next line is </div>`;
        if i+1 < len(lines) and '</div>`' in lines[i+1]:
            # Insert new button before the closing
            indent = '     '
            new_btn = indent + '<button class="btn" onclick="goNextTopic()" style="margin-left:8px">\u2192 \u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0430\u044f \u0442\u0435\u043c\u0430</button>\n'
            lines.insert(i+1, new_btn)
            changes += 1
            print(f"OK: Next topic button added at line {i+2}")
            break

# Find and improve AI prompt context
for i, line in enumerate(lines):
    if "const sys=`\u0422\u044b \u2014 \u0418\u0418-\u043d\u0430\u0441\u0442\u0430\u0432\u043d\u0438\u043a" in line and "Lunar Academy" in line and "t.title" in line:
        # Check this is the aiSend function one (not analyzeCode or explainTopic)
        # Look back a few lines for 'aiSend' or 'aiAddMsg'
        context_lines = ''.join(lines[max(0,i-5):i])
        if 'thinking' in context_lines and 'aiAddMsg' in context_lines:
            old_line = lines[i]
            new_lines = '  const task=getCurrentTask();\n'
            new_lines += '  const taskCtx=task?` \u0422\u0435\u043a\u0443\u0449\u0435\u0435 \u0437\u0430\u0434\u0430\u043d\u0438\u0435 #${task.id}: "${task.title}".`:"";\n'
            new_lines += old_line.replace(
                '${t.title}". \u041e\u0442\u0432\u0435\u0447\u0430\u0439',
                '${t.title}".${taskCtx} \u041e\u0442\u0432\u0435\u0447\u0430\u0439'
            )
            lines[i] = new_lines
            changes += 1
            print(f"OK: AI context improved at line {i+1}")
            break

with open(f, 'w', encoding='utf-8') as fh:
    fh.writelines(lines)

print(f"\nTotal changes applied: {changes}")
