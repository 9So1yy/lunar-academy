window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[11]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Чему равно <code>sizeof(char)</code>?',options:['1','2','4','Зависит'],correct:0,explanation:'По стандарту char всегда 1 байт.'},
 {question:'ASCII-код символа \'A\':',options:['64','65','97','100'],correct:1,explanation:'A=65, B=66, ..., Z=90. Строчные сдвинуты на 32: a=97.'},
 {question:'ASCII-код \'0\':',options:['0','48','49','30'],correct:1,explanation:'Цифры идут с 48. \'0\'=48, \'1\'=49, ..., \'9\'=57.'},
 {question:'Чем заканчивается строка в C?',options:['<code>\\n</code>','<code>\\0</code>','<code>\\t</code>','Ничем'],correct:1,explanation:'Нуль-терминатор <code>\'\\0\'</code> (код 0) — обязательный признак конца строки.'},
 {question:'Сколько байт займёт <code>char s[] = "Hi";</code>?',options:['2','3','4','Зависит'],correct:1,explanation:'H, i, \\0 — три байта.'},
 {question:'Заголовок с isdigit, toupper и др.:',options:['<code>stdio.h</code>','<code>string.h</code>','<code>ctype.h</code>','<code>stdlib.h</code>'],correct:2,explanation:'<code>&lt;ctype.h&gt;</code> содержит функции для символов.'},
 {question:'<code>scanf("%s", buf)</code> читает:',options:['Всю строку','До пробела','Один символ','До перевода строки'],correct:1,explanation:'%s в scanf читает <b>слово</b> — до первого пробельного символа.'},
 {question:'Что безопаснее для чтения строки?',options:['<code>gets</code>','<code>scanf</code>','<code>fgets</code>','<code>scanf("%s")</code>'],correct:2,explanation:'<code>fgets(buf, size, stdin)</code> учитывает размер буфера. <code>gets</code> — удалён из стандарта.'},
 {question:'Разница между <code>\'A\'</code> и <code>"A"</code>:',options:['Нет','char vs строка из 2 байт (A + \\0)','Регистр','Размер'],correct:1,explanation:'<code>\'A\'</code> — char (1 байт). <code>"A"</code> — строка <code>{\'A\',\'\\0\'}</code>.'},
 {question:'<code>isupper(\'B\')</code> вернёт:',options:['0','Истинное (ненулевое)','1 всегда','Ошибка'],correct:1,explanation:'isupper возвращает ненулевое для заглавных. Может быть 1 или другое ненулевое.'},
 {question:'<code>toupper(\'h\')</code> вернёт:',options:['\'h\'','\'H\'','Ошибка','0'],correct:1,explanation:'Преобразует в заглавную. Не-буквы возвращает без изменений.'},
 {question:'Разница между прописной и строчной буквой в ASCII:',options:['16','32','64','100'],correct:1,explanation:'<code>\'a\' - \'A\' = 32</code>. Это разница для всех английских букв.'},
 {question:'<code>char* s = "hello"; s[0] = \'H\';</code> — это:',options:['OK','UB — литералы read-only','Ошибка компиляции','Печатает hello'],correct:1,explanation:'Строковые литералы лежат в read-only памяти — менять UB.'},
 {question:'Цифру \'7\' в число 7 можно так:',options:['<code>(int)\'7\'</code>','<code>\'7\' - \'0\'</code>','<code>atoi(\'7\')</code>','<code>7</code>'],correct:1,explanation:'<code>\'7\' - \'0\'</code> = 55 - 48 = 7. Стандартный приём.'},
 {question:'isalpha проверяет:',options:['Букву','Цифру','Пробел','Любой ASCII'],correct:0,explanation:'isalpha → истинно для букв (A-Z, a-z).'}
],
practical:[
 {title:'Цифра в число',points:20,description:'Считайте символ-цифру (\'0\'-\'9\'). Выведите его как число.',
  testCases:[{input:'7',output:'7',hidden:false},{input:'0',output:'0',hidden:true},{input:'9',output:'9',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    char c;\n    scanf(" %c", &c);\n    // c - \'0\'\n    return 0;\n}\n'},
 {title:'В строчный регистр',points:20,description:'Считайте заглавную букву (A-Z). Выведите её строчный вариант.',
  testCases:[{input:'A',output:'a',hidden:false},{input:'Z',output:'z',hidden:true},{input:'M',output:'m',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    char c;\n    scanf(" %c", &c);\n    // c + 32 или tolower\n    return 0;\n}\n'},
 {title:'Гласная или нет',points:20,description:'Считайте строчную букву. Выведите 1 если гласная (a,e,i,o,u), иначе 0.',
  testCases:[{input:'a',output:'1',hidden:false},{input:'b',output:'0',hidden:true},{input:'u',output:'1',hidden:true},{input:'x',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    char c;\n    scanf(" %c", &c);\n    // c==\'a\'||c==\'e\'||c==\'i\'||c==\'o\'||c==\'u\'\n    return 0;\n}\n'}
]
};
