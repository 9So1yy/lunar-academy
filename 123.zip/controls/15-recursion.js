window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[15]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Рекурсия — это:',options:['Цикл','Функция, вызывающая саму себя','Глобальная переменная','Структура'],correct:1,explanation:'Рекурсия — самовызов функции с уменьшенной задачей.'},
 {question:'Что обязательно для рекурсии?',options:['Цикл','База + шаг','Глобал','Указатель'],correct:1,explanation:'База — условие остановки. Шаг — вызов с уменьшенным аргументом.'},
 {question:'Без базы рекурсия:',options:['Работает','Stack overflow','Останавливается сама','Возвращает 0'],correct:1,explanation:'Бесконечная рекурсия заполняет стек — программа падает.'},
 {question:'fact(0) равно:',options:['0','1','undefined','Ошибка'],correct:1,explanation:'По определению 0! = 1. Это база рекурсии для факториала.'},
 {question:'fact(5):',options:['25','100','120','5'],correct:2,explanation:'5! = 5·4·3·2·1 = 120.'},
 {question:'Рекурсия fib без мемоизации:',options:['O(n)','O(log n)','O(2ⁿ)','O(n²)'],correct:2,explanation:'Каждый вызов делает 2 рекурсивных вызова — экспоненциально.'},
 {question:'fib(10):',options:['10','34','55','89'],correct:2,explanation:'Ряд: 0,1,1,2,3,5,8,13,21,34,<b>55</b>...'},
 {question:'Алгоритм Евклида (НОД):',options:['<code>a + b</code>','<code>gcd(b, a%b)</code> с базой b=0','Бинарный','Прямой перебор'],correct:1,explanation:'Классическая рекурсия: <code>gcd(a,b) = gcd(b, a%b)</code>, база — b==0 → a.'},
 {question:'НОД(12, 18):',options:['2','6','3','12'],correct:1,explanation:'12 = 2²·3, 18 = 2·3² → общий 2·3 = 6.'},
 {question:'Хвостовая рекурсия — это когда:',options:['Рекурсия в конце функции','Циклическая','С возвратом','Длинная'],correct:0,explanation:'Хвостовая = последнее действие функции — рекурсивный вызов. Компилятор может оптимизировать в цикл.'},
 {question:'Альтернатива рекурсии:',options:['Только goto','Итерация (цикл)','Указатели','Глобалы'],correct:1,explanation:'Любую рекурсию можно переписать итеративно (иногда с помощью стека).'},
 {question:'Глубина рекурсии ограничена:',options:['1000','Размером стека','int','Памятью'],correct:1,explanation:'Каждый вызов — кадр стека. Глубина около 10⁴-10⁶ обычно.'},
 {question:'Hanoi для n дисков делает:',options:['n','2n','2ⁿ-1','n!'],correct:2,explanation:'Минимум 2ⁿ-1 ходов. Чисто рекурсивная задача.'},
 {question:'Мемоизация — это:',options:['Запоминание результатов','Очистка памяти','Сжатие','Логирование'],correct:0,explanation:'Сохраняем результаты вычислений, не считаем дважды. Превращает fib в O(n).'},
 {question:'Когда лучше рекурсия?',options:['Всегда','Для деревьев и «разделяй и властвуй»','Для простых циклов','Никогда'],correct:1,explanation:'Естественна для рекурсивных структур и алгоритмов.'}
],
practical:[
 {title:'Факториал',points:20,description:'Считайте N (≤12). Выведите N!. Подумайте, как было бы рекурсивно.',
  testCases:[{input:'5',output:'120',hidden:false},{input:'1',output:'1',hidden:true},{input:'10',output:'3628800',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    long f = 1;\n    scanf("%d", &n);\n    // for или симуляция рекурсии\n    return 0;\n}\n'},
 {title:'Сумма цифр (рекурсивная идея)',points:20,description:'Считайте число. Выведите сумму его цифр. Рекурсивно: sum(n) = (n%10) + sum(n/10), база n==0.',
  testCases:[{input:'1234',output:'10',hidden:false},{input:'9',output:'9',hidden:true},{input:'999',output:'27',hidden:true},{input:'1000',output:'1',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n, s = 0;\n    scanf("%d", &n);\n    // while n>0: s += n%10; n/=10;\n    return 0;\n}\n'},
 {title:'НОД двух чисел',points:20,description:'Считайте 2 числа. Выведите их НОД (алгоритм Евклида).',
  testCases:[{input:'12 18',output:'6',hidden:false},{input:'100 75',output:'25',hidden:true},{input:'17 5',output:'1',hidden:true},{input:'8 8',output:'8',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // while b: t=a%b; a=b; b=t;\n    return 0;\n}\n'}
]
};
