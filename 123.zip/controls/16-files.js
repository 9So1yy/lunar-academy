window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[16]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Тип переменной файла:',options:['<code>file</code>','<code>FILE*</code>','<code>FILE</code>','<code>stream</code>'],correct:1,explanation:'<code>FILE*</code> — указатель на структуру FILE.'},
 {question:'Открыть файл:',options:['<code>open</code>','<code>fopen</code>','<code>file_open</code>','<code>new File</code>'],correct:1,explanation:'<code>fopen(имя, режим)</code> возвращает FILE* или NULL.'},
 {question:'Режим только для чтения:',options:['"r"','"w"','"a"','"x"'],correct:0,explanation:'"r" — read. Файл должен существовать.'},
 {question:'Режим "w" делает что с существующим файлом:',options:['Сохраняет','Обрезает (очищает)','Ошибка','Дозаписывает'],correct:1,explanation:'"w" обрезает или создаёт пустой. Чтобы дозаписать — используйте "a".'},
 {question:'Что вернёт fopen если не удалось?',options:['0','NULL','Случайное','Ошибка'],correct:1,explanation:'NULL — нет прав, нет файла, занят. Всегда проверяйте.'},
 {question:'Закрыть файл:',options:['<code>close</code>','<code>fclose</code>','<code>end</code>','<code>free</code>'],correct:1,explanation:'<code>fclose(f)</code> — сбрасывает буферы и освобождает.'},
 {question:'Чтение строки из файла:',options:['<code>getline</code>','<code>fgets</code>','<code>scanf</code>','<code>fputs</code>'],correct:1,explanation:'<code>fgets(buf, n, f)</code> читает до \\n или n-1 символов.'},
 {question:'Запись в файл с форматом:',options:['<code>printf</code>','<code>fprintf</code>','<code>fputs</code>','<code>fwrite</code>'],correct:1,explanation:'<code>fprintf(f, fmt, ...)</code> — printf, но в файл.'},
 {question:'Бинарная запись:',options:['<code>fwrite</code>','<code>fprintf</code>','<code>fputc</code>','<code>fputs</code>'],correct:0,explanation:'<code>fwrite</code> для произвольных байтов (структуры, изображения).'},
 {question:'Перемотать в начало файла:',options:['<code>rewind</code>','<code>reset</code>','<code>fseek(f, 0, SEEK_SET)</code>','И rewind, и fseek'],correct:3,explanation:'rewind — короче, fseek — общий.'},
 {question:'stdout — это:',options:['Строка','FILE* для вывода в консоль','Указатель','Функция'],correct:1,explanation:'stdin, stdout, stderr — стандартные FILE*. printf == fprintf(stdout, ...).'},
 {question:'Куда писать сообщения об ошибках?',options:['stdout','stderr','log','printf'],correct:1,explanation:'stderr — стандартный поток ошибок. Не буферизуется.'},
 {question:'Что делает <code>fflush(stdout)</code>?',options:['Очищает консоль','Сбрасывает буфер вывода','Закрывает','Перематывает'],correct:1,explanation:'Принудительно записывает буферизованный вывод. Иначе может задержаться.'},
 {question:'<code>feof(f)</code> проверяет:',options:['Размер','Достигнут ли конец файла','Открыт ли','Ошибку'],correct:1,explanation:'EOF — End Of File. После попытки прочитать за концом.'},
 {question:'<code>fseek(f, -1, SEEK_END)</code>:',options:['Один байт от начала','Один байт от конца','Ошибка','В начале'],correct:1,explanation:'SEEK_END — отсчёт от конца. -1 = последний байт.'}
],
practical:[
 {title:'fprintf в stdout',points:20,description:'Считайте число и выведите его в stdout через fprintf.',
  testCases:[{input:'42',output:'42',hidden:false},{input:'-5',output:'-5',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    fprintf(stdout, "%d", n);\n    return 0;\n}\n'},
 {title:'Подсчёт байт',points:20,description:'Считайте 3 числа — длины 3 строк. Выведите сумму (общее количество байт в файле).',
  testCases:[{input:'10 20 30',output:'60',hidden:false},{input:'0 0 0',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    // сумма\n    return 0;\n}\n'},
 {title:'Позиция fseek',points:20,description:'Имитация fseek(f, off, SEEK_SET). Считайте число off. Выведите его как новую позицию, или 0 если off &lt; 0.',
  testCases:[{input:'100',output:'100',hidden:false},{input:'-5',output:'0',hidden:true},{input:'0',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int off;\n    scanf("%d", &off);\n    // off < 0 ? 0 : off\n    return 0;\n}\n'}
]
};
