window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[18]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Препроцессор работает:',options:['Во время выполнения','До компиляции','Параллельно','После компиляции'],correct:1,explanation:'Препроцессор — отдельный этап перед компиляцией.'},
 {question:'Все директивы препроцессора начинаются с:',options:['<code>@</code>','<code>#</code>','<code>$</code>','<code>%</code>'],correct:1,explanation:'<code>#include</code>, <code>#define</code>, <code>#ifdef</code> и т.д.'},
 {question:'<code>#include &lt;stdio.h&gt;</code> ищет файл:',options:['Только в текущей папке','В системных путях','По имени','Везде'],correct:1,explanation:'Угловые скобки = системный путь. Кавычки = относительно файла.'},
 {question:'<code>#define PI 3.14</code> — это:',options:['Объявление переменной','Текстовая замена','Функция','Тип'],correct:1,explanation:'Препроцессор заменит все PI на 3.14 в коде до компиляции.'},
 {question:'Точка с запятой в конце #define:',options:['Обязательна','Не нужна (и обычно вредна)','Зависит','Всегда'],correct:1,explanation:'<code>#define X 5;</code> заменит X на <code>5;</code> — обычно ошибка.'},
 {question:'Что плохо в <code>#define SQR(x) x*x</code>?',options:['Нет скобок — приоритет может сломаться','Длинно','Тип','Ничего'],correct:0,explanation:'SQR(2+3) станет 2+3*2+3 = 11, не 25. Нужно <code>((x)*(x))</code>.'},
 {question:'Header guard защищает от:',options:['Багов','Двойного включения заголовка','Утечек','Переполнения'],correct:1,explanation:'<code>#ifndef X #define X ... #endif</code> или <code>#pragma once</code>.'},
 {question:'<code>#ifdef DEBUG</code> включает код если:',options:['Запущено в debug','DEBUG определён через #define','Всегда','Никогда'],correct:1,explanation:'Чисто текстовая проверка — определён ли символ.'},
 {question:'Макрос <code>__LINE__</code> даёт:',options:['Имя файла','Номер строки','Дату','Версию'],correct:1,explanation:'Полезен для отладочных сообщений.'},
 {question:'<code>__FILE__</code> — это:',options:['Имя файла-источника','Указатель','Размер','Время'],correct:0,explanation:'Имя текущего файла исходника, в котором встретился макрос.'},
 {question:'<code>#pragma once</code> — это:',options:['Стандарт','Расширение, поддерживаемое почти всеми','Запрещено','Только для C++'],correct:1,explanation:'Более простая альтернатива header guards. Не стандарт, но поддерживается везде.'},
 {question:'<code>#elif</code> — это:',options:['Конец','else if препроцессора','Включение','Ошибка'],correct:1,explanation:'Сокращение для <code>#else #if</code>.'},
 {question:'<code>#define MAX 100</code> — затем <code>MAX = 200;</code>:',options:['Меняет MAX','Ошибка: <code>100 = 200;</code> бессмысленно','Создаёт переменную','OK'],correct:1,explanation:'После замены получится <code>100 = 200;</code> — нельзя присваивать литералу.'},
 {question:'Современная альтернатива #define для констант:',options:['<code>const</code>','<code>static</code>','<code>extern</code>','<code>typedef</code>'],correct:0,explanation:'<code>const int X = 5;</code> типизировано, виден отладчику, безопаснее.'},
 {question:'Условная компиляция используется для:',options:['Отладки, разных платформ, версий','Только для оптимизации','Скорости','Безопасности'],correct:0,explanation:'Включение/исключение кода по флагам — для разных конфигураций сборки.'}
],
practical:[
 {title:'Макрос-константа',points:20,description:'Используйте <code>#define G 10</code>. Считайте число t (время в секундах) и выведите g·t² (свободное падение, упрощённо).',
  testCases:[{input:'2',output:'40',hidden:false},{input:'3',output:'90',hidden:true},{input:'1',output:'10',hidden:true}],
  initialCode:'#include <stdio.h>\n#define G 10\n\nint main(void) {\n    int t;\n    scanf("%d", &t);\n    // G * t * t\n    return 0;\n}\n'},
 {title:'Макро-функция CUBE',points:20,description:'Определите макрос <code>CUBE(x) ((x)*(x)*(x))</code>. Считайте число и выведите его куб.',
  testCases:[{input:'3',output:'27',hidden:false},{input:'5',output:'125',hidden:true},{input:'-2',output:'-8',hidden:true}],
  initialCode:'#include <stdio.h>\n#define CUBE(x) ((x)*(x)*(x))\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // CUBE(n)\n    return 0;\n}\n'},
 {title:'Условная',points:20,description:'Считайте число. Имитируйте <code>#define VERBOSE</code>: если число чётное — выведите 2·x, иначе x (как разная логика в разных версиях).',
  testCases:[{input:'4',output:'8',hidden:false},{input:'5',output:'5',hidden:true},{input:'10',output:'20',hidden:true},{input:'7',output:'7',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // тернарный: чётное → 2n, нет → n\n    return 0;\n}\n'}
]
};
