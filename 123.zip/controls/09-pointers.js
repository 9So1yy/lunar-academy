window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[9]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Указатель хранит:',options:['Значение','Адрес другой переменной','Тип','Имя'],correct:1,explanation:'Указатель — переменная, содержащая адрес другой переменной.'},
 {question:'Оператор «адрес от»:',options:['<code>*</code>','<code>&amp;</code>','<code>@</code>','<code>#</code>'],correct:1,explanation:'<code>&amp;x</code> — берёт адрес x. Возвращает указатель.'},
 {question:'Оператор «значение по адресу» (разыменование):',options:['<code>&amp;</code>','<code>*</code>','<code>-&gt;</code>','<code>.</code>'],correct:1,explanation:'<code>*p</code> — даёт значение по адресу, хранящемуся в p.'},
 {question:'Объявление: указатель на int —',options:['<code>int p*;</code>','<code>int *p;</code>','<code>*int p;</code>','<code>pointer&lt;int&gt; p;</code>'],correct:1,explanation:'<code>int *p;</code> или <code>int* p;</code> — оба верны.'},
 {question:'<code>NULL</code> — это:',options:['Ошибка','«Никуда не указывает»','0','Зависит'],correct:1,explanation:'NULL = специальное значение «нулевой указатель». Обычно макрос ((void*)0).'},
 {question:'Разыменование NULL — это:',options:['Возвращает 0','UB / crash','Разрешено','Игнорируется'],correct:1,explanation:'Доступ по нулевому адресу — UB. Обычно крах программы.'},
 {question:'Имя массива — это:',options:['Структура','Указатель на первый элемент','Число','Строка'],correct:1,explanation:'В выражениях имя массива превращается в <code>&amp;a[0]</code>.'},
 {question:'<code>p + 1</code> сдвигает на:',options:['1 байт','sizeof типа','4 байта всегда','Зависит от ОС'],correct:1,explanation:'Арифметика указателей — в единицах размера типа. Для <code>int*</code> +1 = +4 байта.'},
 {question:'Чтобы функция меняла переменную:',options:['Передать копию','Передать указатель','Глобальная','Невозможно'],correct:1,explanation:'Передайте адрес, разыменуйте внутри функции: <code>void f(int* p) { *p = 10; }</code>.'},
 {question:'<code>int** pp</code> — это:',options:['Ошибка','Указатель на указатель','Массив указателей','Двойное число'],correct:1,explanation:'Двойной указатель — указывает на указатель.'},
 {question:'<code>void*</code> — это:',options:['Ничего','Универсальный указатель','Ошибка','Функция'],correct:1,explanation:'Указатель на «что угодно». Перед использованием — приведение к нужному типу.'},
 {question:'Что общего у <code>p[i]</code> и <code>*(p+i)</code>?',options:['Ничего','Эквивалентны','Только для массивов','Только для int'],correct:1,explanation:'Это синонимы. <code>p[i]</code> = <code>*(p+i)</code> для любых указателей.'},
 {question:'Висячий указатель — это:',options:['NULL','Указывает на освобождённую память','Указывает в массив','Несуществующий тип'],correct:1,explanation:'После <code>free</code> указатель «висит» — память освобождена, но указатель ещё хранит адрес. Использование — UB.'},
 {question:'<code>const int* p</code> — нельзя:',options:['Менять p','Менять *p','Использовать p','Передавать в функцию'],correct:1,explanation:'<code>const int* p</code> = «p может указывать куда угодно, но *p менять нельзя».'},
 {question:'<code>int* const p</code> — нельзя:',options:['Менять *p','Менять p (на что указывает)','Использовать','Объявить'],correct:1,explanation:'<code>int* const p</code> = «значение по адресу можно менять, но сам указатель привязан».'}
],
practical:[
 {title:'Сумма через указатели',points:20,description:'Считайте 2 числа в переменные. Используя указатели, выведите их сумму.',
  testCases:[{input:'3 4',output:'7',hidden:false},{input:'10 20',output:'30',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    int *pa = &a, *pb = &b;\n    scanf("%d %d", pa, pb);\n    // выведите *pa + *pb\n    return 0;\n}\n'},
 {title:'Изменение через указатель',points:20,description:'Считайте число. Через указатель утройте его и выведите.',
  testCases:[{input:'5',output:'15',hidden:false},{input:'7',output:'21',hidden:true},{input:'0',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int x;\n    scanf("%d", &x);\n    int* p = &x;\n    // *p = *p * 3;\n    printf("%d", x);\n    return 0;\n}\n'},
 {title:'Min из двух',points:20,description:'Считайте 2 числа. Выведите минимум, обращаясь к ним только через указатели.',
  testCases:[{input:'3 5',output:'3',hidden:false},{input:'10 4',output:'4',hidden:true},{input:'7 7',output:'7',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    int *pa = &a, *pb = &b;\n    // *pa < *pb ? *pa : *pb\n    return 0;\n}\n'}
]
};
