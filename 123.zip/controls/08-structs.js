window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[8]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'<code>struct</code> — это:',options:['Массив','Группа полей разных типов','Указатель','Функция'],correct:1,explanation:'Структура объединяет несколько разнотипных полей в один пользовательский тип.'},
 {question:'Доступ к полю структуры:',options:['<code>s.field</code>','<code>s-&gt;field</code>','<code>s::field</code>','<code>s[field]</code>'],correct:0,explanation:'Через точку для объекта, через стрелку для указателя.'},
 {question:'Доступ к полю через указатель на структуру:',options:['<code>s.field</code>','<code>s-&gt;field</code>','<code>*s.field</code>','<code>&amp;s.field</code>'],correct:1,explanation:'<code>p-&gt;field</code> эквивалентно <code>(*p).field</code>.'},
 {question:'Размер union равен:',options:['Сумме полей','Размеру наибольшего поля','Зависит','Нулю'],correct:1,explanation:'В union все поля делят одну память — размер = max.'},
 {question:'<code>enum</code> — это набор:',options:['Строк','Целочисленных констант','Указателей','Функций'],correct:1,explanation:'Enum даёт имена целым числам: <code>enum Day {MON, TUE, ...}</code>.'},
 {question:'Что облегчает <code>typedef</code>?',options:['Запись имени типа','Скорость','Безопасность','Память'],correct:0,explanation:'<code>typedef</code> даёт типу короткое имя: вместо <code>struct Point</code> можно писать <code>Point</code>.'},
 {question:'Структуры передаются в функции:',options:['По значению — копируются','Всегда по ссылке','Невозможно','Только глобально'],correct:0,explanation:'По умолчанию копируются. Для больших структур передавайте указатель.'},
 {question:'<code>sizeof(struct)</code> может быть больше суммы полей из-за:',options:['Тегов','Выравнивания (padding)','Меток','Ошибки'],correct:1,explanation:'Компилятор выравнивает поля по границам для скорости — между ними padding.'},
 {question:'В union одновременно можно использовать:',options:['Все поля','Только одно','Два','Зависит'],correct:1,explanation:'Запись в одно поле «испортит» остальные — они делят память.'},
 {question:'По умолчанию первое значение enum:',options:['1','0','-1','Случайное'],correct:1,explanation:'Enum нумеруется с 0, если не задано иначе.'},
 {question:'Можно ли вложить struct в struct?',options:['Нет','Да','Только указатели','Зависит'],correct:1,explanation:'Структуры можно вкладывать любой глубины.'},
 {question:'Инициализация: <code>Point p = {3, 4};</code> — это:',options:['Массив','Список инициализаторов по порядку полей','Функция','Ошибка'],correct:1,explanation:'Список инициализаторов — поля в порядке объявления.'},
 {question:'Что значит <code>typedef struct Node { int v; struct Node* next; } Node;</code>?',options:['Ошибка','Самоссылка через указатель — можно делать связные списки','Бесконечная структура','Двойная декларация'],correct:1,explanation:'Через указатель структура может ссылаться на саму себя — основа связных списков.'},
 {question:'Сравнение двух структур через <code>==</code>:',options:['Поле за полем','Запрещено в C','Через memcmp','Адреса'],correct:1,explanation:'C не поддерживает прямое сравнение структур. Сравнивайте поля или через <code>memcmp</code>.'},
 {question:'enum в switch:',options:['Запрещён','Очень удобен','Только для чисел','Только для строк'],correct:1,explanation:'enum + switch — идеальная пара, ясный и компилятор предупредит о пропущенных case.'}
],
practical:[
 {title:'Координаты',points:20,description:'Считайте 2 числа x, y (поля точки). Выведите их сумму.',
  testCases:[{input:'3 4',output:'7',hidden:false},{input:'10 -5',output:'5',hidden:true}],
  initialCode:'#include <stdio.h>\n\nstruct Point { int x, y; };\n\nint main(void) {\n    struct Point p;\n    scanf("%d %d", &p.x, &p.y);\n    // выведите p.x + p.y\n    return 0;\n}\n'},
 {title:'Прямоугольник',points:20,description:'Структура с полями <code>w, h</code>. Считайте 2 числа. Выведите площадь.',
  testCases:[{input:'5 4',output:'20',hidden:false},{input:'10 10',output:'100',hidden:true}],
  initialCode:'#include <stdio.h>\n\nstruct Rect { int w, h; };\n\nint main(void) {\n    struct Rect r;\n    scanf("%d %d", &r.w, &r.h);\n    // площадь\n    return 0;\n}\n'},
 {title:'enum цвет',points:20,description:'Считайте число (0=red, 1=green, 2=blue). Выведите название цвета.',
  testCases:[{input:'0',output:'red',hidden:false},{input:'1',output:'green',hidden:true},{input:'2',output:'blue',hidden:true}],
  initialCode:'#include <stdio.h>\n\nenum Color { RED, GREEN, BLUE };\n\nint main(void) {\n    int c;\n    scanf("%d", &c);\n    // switch на c\n    return 0;\n}\n'}
]
};
