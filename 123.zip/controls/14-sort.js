window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[14]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Сложность bubble sort:',options:['O(1)','O(n)','O(n log n)','O(n²)'],correct:3,explanation:'Двойной цикл — n·n операций.'},
 {question:'Сложность merge sort:',options:['O(n)','O(n log n)','O(n²)','O(2ⁿ)'],correct:1,explanation:'Деление пополам log n раз, объединение O(n).'},
 {question:'qsort из stdlib обычно реализует:',options:['Bubble','Selection','Quick sort','Heap sort'],correct:2,explanation:'Quick sort (или его вариант) — самый быстрый в среднем O(n log n).'},
 {question:'Worst-case quick sort:',options:['O(n log n)','O(n²)','O(n)','O(2ⁿ)'],correct:1,explanation:'При плохом выборе опорного элемента — O(n²). Современные реализации используют хитрости.'},
 {question:'Insertion sort идеально подходит для:',options:['Случайных данных','Почти отсортированных','Реверсных','Огромных'],correct:1,explanation:'O(n) на почти отсортированных — лучшая из простых.'},
 {question:'Стабильная сортировка:',options:['Не меняет порядок равных элементов','Не падает','Самая быстрая','Без багов'],correct:0,explanation:'Стабильная сохраняет относительный порядок равных. Важно для составных ключей.'},
 {question:'Bubble sort стабильный?',options:['Да','Нет','Зависит','Только для int'],correct:0,explanation:'Если сравнивать строго &gt;, bubble стабильный.'},
 {question:'Quick sort стабильный?',options:['Да','Нет','Только в gcc','Зависит'],correct:1,explanation:'Стандартный quick sort нестабилен из-за обменов через большие расстояния.'},
 {question:'Какой алгоритм in-place (без доп памяти)?',options:['Merge','Quick','Counting','Radix'],correct:1,explanation:'Quick sort работает на месте, O(log n) стека. Merge требует O(n) памяти.'},
 {question:'Сравнивать элементы для qsort нужно через:',options:['Глобальную функцию','callback (указатель на функцию)','Макрос','Перегрузку'],correct:1,explanation:'qsort принимает указатель на функцию-компаратор.'},
 {question:'Если у вас 10 чисел — что использовать?',options:['Merge sort','Insertion sort или встроенный qsort','Bubble','Radix'],correct:1,explanation:'На малых данных insertion / qsort одинаково хороши. Сложные алгоритмы избыточны.'},
 {question:'O(n log n) — это нижняя граница для:',options:['Любой сортировки','Сортировок сравнением','Только quick','Только merge'],correct:1,explanation:'Доказано: сортировка через сравнения не быстрее n log n. Counting/Radix используют другую модель.'},
 {question:'Что вернуть в компараторе если a меньше b?',options:['0','Положительное','Отрицательное','Любое'],correct:2,explanation:'Стандарт: возврат &lt; 0 если a должно идти раньше b.'},
 {question:'Сортировка вставкой делает обменов:',options:['Много','Мало (только нужные)','n²','log n'],correct:1,explanation:'Insertion делает только необходимые сдвиги — почти оптимально по числу операций для почти-сортированных.'},
 {question:'Bogosort — это:',options:['Самый быстрый','Случайная перетасовка пока не отсортировано — O(n!)','Серьёзный алгоритм','Для строк'],correct:1,explanation:'Шуточный алгоритм. На 10 элементах может работать вечно.'}
],
practical:[
 {title:'Сорт 2 чисел',points:20,description:'Считайте 2 числа. Выведите их в порядке возрастания.',
  testCases:[{input:'5 3',output:'3 5',hidden:false},{input:'1 9',output:'1 9',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // тернарный\n    return 0;\n}\n'},
 {title:'Min/Max из 3',points:20,description:'Считайте 3 числа. Выведите min и max через пробел.',
  testCases:[{input:'5 3 7',output:'3 7',hidden:false},{input:'1 1 1',output:'1 1',hidden:true},{input:'-2 10 0',output:'-2 10',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b, c, mi, ma;\n    scanf("%d %d %d", &a, &b, &c);\n    // найдите min и max\n    return 0;\n}\n'},
 {title:'Компаратор',points:20,description:'Считайте 2 числа. Выведите как делал бы qsort-компаратор: положительное (a-b), которое говорит «a больше b».',
  testCases:[{input:'5 3',output:'2',hidden:false},{input:'2 7',output:'-5',hidden:true},{input:'4 4',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // a - b\n    return 0;\n}\n'}
]
};
