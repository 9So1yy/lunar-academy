window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[6]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Точка входа любой C-программы:',options:['<code>start()</code>','<code>main()</code>','<code>init()</code>','<code>__main__</code>'],correct:1,explanation:'C-программа стартует с <code>main()</code>. Возвращает int — код завершения.'},
 {question:'<code>void</code> в скобках означает:',options:['Любое число параметров','Нет параметров','Ошибка','Указатель'],correct:1,explanation:'<code>void</code> в параметрах = функция без аргументов.'},
 {question:'Возврат значения из функции:',options:['<code>break</code>','<code>exit</code>','<code>return</code>','<code>yield</code>'],correct:2,explanation:'<code>return</code> возвращает значение и завершает функцию.'},
 {question:'Параметры в C передаются:',options:['По ссылке','По значению (копия)','Как глобальные','По указателю всегда'],correct:1,explanation:'Всегда по значению. Чтобы изменять — передавайте указатель.'},
 {question:'Прототип функции — это:',options:['Реализация','Объявление без тела','Заглушка','Документация'],correct:1,explanation:'Прототип сообщает компилятору сигнатуру до определения тела.'},
 {question:'Что вернёт <code>void</code>-функция?',options:['0','NULL','Ничего','Случайное'],correct:2,explanation:'<code>void</code> = «нет возвращаемого значения». <code>return;</code> без значения.'},
 {question:'Функция вызывает сама себя — это:',options:['Цикл','Рекурсия','Перегрузка','Ошибка'],correct:1,explanation:'Рекурсия. Требует базы — условия выхода.'},
 {question:'Как изменить переменную вызывающего из функции?',options:['Глобальная','Передать указатель','Передать копию','Невозможно'],correct:1,explanation:'Через указатель: функция получает адрес, может разыменовать и менять.'},
 {question:'Куда возвращает <code>return 0;</code> в main?',options:['В OS — код успеха','В компилятор','Сам в себя','Ошибка'],correct:0,explanation:'OS получает код возврата программы. 0 = успех, иное = ошибка.'},
 {question:'Что плохо в возврате локального массива?',options:['Медленно','Память освободится после выхода — UB','Ошибка компиляции','Только для статических'],correct:1,explanation:'Стек локальной функции освобождается — указатель станет висячим.'},
 {question:'Где лучше хранить константы для функции?',options:['Глобально','Внутри функции','В заголовке','#define'],correct:1,explanation:'Локальные константы изолируют функцию. Глобалы усложняют тестирование.'},
 {question:'Сколько раз может быть вызвана функция?',options:['1','100','Неограниченно','Зависит от типа'],correct:2,explanation:'Любое количество раз, пока хватает стека.'},
 {question:'Хорошая длина функции:',options:['1-3 строки','10-50 строк','200+ строк','Любая'],correct:1,explanation:'10-50 — кандидат на «делает одно дело». Длинные функции — кандидат на разбиение.'},
 {question:'Имя функции должно быть:',options:['Существительное','Глагол','Прилагательное','Случайное'],correct:1,explanation:'Функция «делает» что-то — глагол: <code>calculate</code>, <code>print</code>, <code>find</code>.'},
 {question:'Что значит «функция чистая» (pure)?',options:['Без багов','Не имеет побочных эффектов и зависит только от аргументов','Возвращает 0','Простая'],correct:1,explanation:'Pure = детерминированна и не меняет внешнее состояние. Легко тестировать.'}
],
practical:[
 {title:'Удвоить',points:20,description:'Считайте число и выведите его удвоенное (имитация функции <code>int doubled(int x)</code>).',
  testCases:[{input:'5',output:'10',hidden:false},{input:'0',output:'0',hidden:true},{input:'-3',output:'-6',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int x;\n    scanf("%d", &x);\n    // x * 2\n    return 0;\n}\n'},
 {title:'Абсолютное значение',points:20,description:'Считайте число и выведите его модуль (имитация <code>int absv(int)</code>).',
  testCases:[{input:'-5',output:'5',hidden:false},{input:'7',output:'7',hidden:true},{input:'0',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int x;\n    scanf("%d", &x);\n    // x < 0 ? -x : x\n    return 0;\n}\n'},
 {title:'isPrime',points:20,description:'Считайте N. Выведите 1 если простое, 0 иначе. Имитация функции <code>int isPrime(int n)</code>.',
  testCases:[{input:'7',output:'1',hidden:false},{input:'9',output:'0',hidden:true},{input:'2',output:'1',hidden:true},{input:'1',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    int ok = (n > 1);\n    // цикл проверки делителей\n    return 0;\n}\n'}
]
};
