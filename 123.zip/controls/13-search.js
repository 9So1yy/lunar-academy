window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[13]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Линейный поиск — сложность:',options:['O(1)','O(log n)','O(n)','O(n²)'],correct:2,explanation:'Худший случай — проверить все n элементов.'},
 {question:'Бинарный поиск — сложность:',options:['O(1)','O(log n)','O(n)','O(n²)'],correct:1,explanation:'Каждая итерация делит диапазон пополам — log₂(n).'},
 {question:'Бинарный поиск требует:',options:['Большой массив','Отсортированный массив','Уникальные элементы','Указатели'],correct:1,explanation:'Без сортировки невозможно решить, в какую половину идти.'},
 {question:'Соглашение «не найдено»:',options:['0','-1','NULL','Ошибка'],correct:1,explanation:'Возврат -1 для индексов, NULL для указателей.'},
 {question:'Сколько итераций бинарного поиска для n=1000?',options:['1000','100','~10','5'],correct:2,explanation:'log₂(1000) ≈ 10. Поэтому бинарный супер быстрый.'},
 {question:'Сколько итераций линейного поиска для n=1000 (худший)?',options:['1','10','100','1000'],correct:3,explanation:'В худшем случае нужно перебрать все.'},
 {question:'<code>mid = (lo + hi) / 2</code> может:',options:['Всегда работать','Переполниться при больших lo, hi','Быть медленным','Округлить вверх'],correct:1,explanation:'Если lo+hi &gt; INT_MAX — переполнение. Безопаснее <code>lo + (hi-lo)/2</code>.'},
 {question:'<code>bsearch</code> из stdlib работает с:',options:['Только int','Любым типом через void*','Только строками','Только массивами'],correct:1,explanation:'<code>bsearch</code> универсальна — принимает callback-компаратор.'},
 {question:'Если массив маленький (n &lt; 20):',options:['Бинарный всегда лучше','Линейный может быть быстрее','Невозможно искать','Только хеш'],correct:1,explanation:'На малых данных накладные расходы бинарного перекрывают выигрыш.'},
 {question:'Хеш-таблица даёт поиск за:',options:['O(1) в среднем','O(n)','O(log n)','O(n²)'],correct:0,explanation:'Хеш-таблица — самый быстрый поиск, в среднем O(1).'},
 {question:'Поиск максимума требует:',options:['Сортировки','O(n) перебора','O(log n)','O(1)'],correct:1,explanation:'Один проход — сравнить с текущим максимумом.'},
 {question:'Можно ли бинарным искать в связном списке?',options:['Да, быстро','Нет — нужен произвольный доступ','Только в кольцевом','Только в двусвязном'],correct:1,explanation:'Бинарный требует O(1) доступа к середине. В списке O(n) — теряется смысл.'},
 {question:'Сложность поиска подстроки наивно:',options:['O(n)','O(n+m)','O(n·m)','O(log n)'],correct:2,explanation:'Для каждой позиции в строке n проверяем m символов. Алгоритм KMP даёт O(n+m).'},
 {question:'Если данные часто меняются:',options:['Только сортированный массив','Хеш-таблица или дерево','Бинарный поиск','Линейный'],correct:1,explanation:'Сортированный массив дорого обновлять. Дерево/хеш позволяют быстрые вставки.'},
 {question:'sentinel-поиск ускоряет:',options:['Бинарный','Линейный (убирает проверку i&lt;n)','Хеш','Ничего'],correct:1,explanation:'Поставив искомое в конец, можно убрать одну проверку — небольшое ускорение.'}
],
practical:[
 {title:'Поиск среди 4-х',points:20,description:'Считайте 5 чисел: a, b, c, d, key. Выведите позицию (1-4) где найден key, или 0.',
  testCases:[{input:'10 20 30 40 30',output:'3',hidden:false},{input:'5 5 5 5 5',output:'1',hidden:true},{input:'1 2 3 4 99',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b, c, d, key;\n    scanf("%d %d %d %d %d", &a, &b, &c, &d, &key);\n    // if-каскад\n    return 0;\n}\n'},
 {title:'Шаг бинарного поиска',points:20,description:'Дано: lo, hi, target. Выведите mid через формулу <code>lo + (hi-lo)/2</code>.',
  testCases:[{input:'0 100 50',output:'50',hidden:false},{input:'10 20 0',output:'15',hidden:true},{input:'0 999 0',output:'499',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int lo, hi, target;\n    scanf("%d %d %d", &lo, &hi, &target);\n    // lo + (hi-lo)/2\n    return 0;\n}\n'},
 {title:'Поиск макс',points:20,description:'Считайте 4 числа. Выведите максимальное.',
  testCases:[{input:'3 7 2 9',output:'9',hidden:false},{input:'1 1 1 1',output:'1',hidden:true},{input:'-5 -10 -3 -8',output:'-3',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b, c, d, m;\n    scanf("%d %d %d %d", &a, &b, &c, &d);\n    m = a;\n    // сравнить с b, c, d\n    return 0;\n}\n'}
]
};
