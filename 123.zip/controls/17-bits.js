window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[17]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'<code>5 & 3</code> равно:',options:['1','7','8','15'],correct:0,explanation:'5=101, 3=011, AND=001=1.'},
 {question:'<code>5 | 3</code> равно:',options:['1','7','8','15'],correct:1,explanation:'5=101, 3=011, OR=111=7.'},
 {question:'<code>5 ^ 3</code> равно:',options:['1','6','7','8'],correct:1,explanation:'XOR — биты разные: 101^011 = 110 = 6.'},
 {question:'<code>1 &lt;&lt; 4</code> равно:',options:['4','8','16','32'],correct:2,explanation:'Сдвиг влево на n = умножение на 2ⁿ. 1·2⁴ = 16.'},
 {question:'<code>16 &gt;&gt; 2</code> равно:',options:['2','4','8','14'],correct:1,explanation:'Сдвиг вправо = деление на 2ⁿ. 16/4 = 4.'},
 {question:'Битовое AND обозначается:',options:['<code>&amp;&amp;</code>','<code>&amp;</code>','<code>and</code>','<code>*</code>'],correct:1,explanation:'<code>&amp;</code> — побитовое. <code>&amp;&amp;</code> — логическое (разные!).'},
 {question:'Установить n-й бит:',options:['<code>x | (1 &lt;&lt; n)</code>','<code>x & (1 &lt;&lt; n)</code>','<code>x ^ (1 &lt;&lt; n)</code>','<code>x + n</code>'],correct:0,explanation:'OR с маской ставит этот бит в 1, остальные не трогает.'},
 {question:'Очистить n-й бит:',options:['<code>x | (1 &lt;&lt; n)</code>','<code>x &amp; ~(1 &lt;&lt; n)</code>','<code>x ^ (1 &lt;&lt; n)</code>','<code>x - n</code>'],correct:1,explanation:'AND с инвертированной маской сбрасывает только этот бит.'},
 {question:'Проверить чётность:',options:['<code>x &amp; 1</code>','<code>x | 1</code>','<code>x ^ 1</code>','<code>x + 1</code>'],correct:0,explanation:'Младший бит — это чётность. <code>x &amp; 1</code> == 0 если чётное.'},
 {question:'Степень двойки проверяется как:',options:['<code>x % 2 == 0</code>','<code>x &amp; (x-1) == 0</code> (для x&gt;0)','<code>x &gt;&gt; 1 == 0</code>','<code>x == 2</code>'],correct:1,explanation:'У степени 2 только один бит установлен. x&amp;(x-1) сбрасывает его → 0.'},
 {question:'Обмен XOR-ом:',options:['<code>a=b; b=a;</code>','<code>a^=b; b^=a; a^=b;</code>','<code>swap(a,b)</code>','Невозможно'],correct:1,explanation:'Три XOR обмена двух чисел без временной переменной.'},
 {question:'Подсчёт единичных битов в числе называется:',options:['popcount','count','total','bits'],correct:0,explanation:'popcount = population count. Современные CPU имеют отдельную инструкцию.'},
 {question:'<code>~0</code> для int равно:',options:['0','-1','INT_MAX','Зависит'],correct:1,explanation:'Все биты единицы — это -1 в дополнительном коде.'},
 {question:'Что значит <code>x &amp; (x-1)</code>?',options:['Удваивает','Сбрасывает младший установленный бит','Прибавляет','Ничего'],correct:1,explanation:'Полезный трюк: <code>10100 &amp; 10011 = 10000</code>. Используется в подсчёте битов.'},
 {question:'Битовые операции быстрее обычной арифметики?',options:['Никогда','Часто да — простые операции CPU','Только для float','Только в gcc'],correct:1,explanation:'Битовые — 1 такт. Часто компилятор сам заменяет деление на 2 сдвигом.'}
],
practical:[
 {title:'AND двух чисел',points:20,description:'Считайте 2 числа. Выведите их битовое AND.',
  testCases:[{input:'12 10',output:'8',hidden:false},{input:'7 3',output:'3',hidden:true},{input:'15 15',output:'15',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // a & b\n    return 0;\n}\n'},
 {title:'Удвоить через сдвиг',points:20,description:'Считайте число. Выведите его удвоенное через битовый сдвиг.',
  testCases:[{input:'5',output:'10',hidden:false},{input:'1',output:'2',hidden:true},{input:'100',output:'200',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int x;\n    scanf("%d", &x);\n    // x << 1\n    return 0;\n}\n'},
 {title:'Чётность',points:20,description:'Считайте число. Выведите 1 если нечётное (младший бит установлен), иначе 0.',
  testCases:[{input:'7',output:'1',hidden:false},{input:'8',output:'0',hidden:true},{input:'0',output:'0',hidden:true},{input:'15',output:'1',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int x;\n    scanf("%d", &x);\n    // x & 1\n    return 0;\n}\n'}
]
};
