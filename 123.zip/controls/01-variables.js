window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[1]={
timeLimit:1800,
passingScore:70,
theory:[
 {question:'В каком заголовочном файле объявлена функция <code>printf</code>?',options:['<code>stdio.h</code>','<code>stdlib.h</code>','<code>string.h</code>','<code>math.h</code>'],correct:0,explanation:'<code>printf</code>, <code>scanf</code>, <code>fopen</code> и другие функции ввода-вывода объявлены в <code>stdio.h</code> (Standard Input-Output).'},
 {question:'Какой размер обычно имеет тип <code>int</code> на 64-битной системе?',options:['1 байт','2 байта','4 байта','8 байт'],correct:2,explanation:'На большинстве современных систем (включая 64-битные Linux/Windows/macOS) <code>int</code> занимает 4 байта.'},
 {question:'Какой спецификатор используется в <code>printf</code> для <code>double</code>?',options:['<code>%d</code>','<code>%lf</code>','<code>%f</code>','<code>%s</code>'],correct:2,explanation:'В <code>printf</code> для <code>double</code> подходит <code>%f</code>. <code>%lf</code> обязателен только в <code>scanf</code>.'},
 {question:'Что выведет <code>printf("%d", 7 / 2);</code>?',options:['<code>3.5</code>','<code>3</code>','<code>4</code>','<code>3.0</code>'],correct:1,explanation:'Деление двух int — целочисленное. <code>7 / 2 = 3</code>, дробная часть отбрасывается.'},
 {question:'Что хранится в <code>x</code> после <code>int x;</code>?',options:['Ноль','NULL','Случайный мусор','Ошибка компиляции'],correct:2,explanation:'Неинициализированная локальная переменная содержит случайный мусор из памяти. Это частый источник багов.'},
 {question:'Какая инициализация заполнит весь массив нулями?',options:['<code>int a[10];</code>','<code>int a[10] = {};</code>','<code>int a[10] = {0};</code>','<code>int a[10] = 0;</code>'],correct:2,explanation:'<code>int a[10] = {0};</code> — первый элемент 0, остальные тоже 0. Без инициализации значения мусорные.'},
 {question:'Что вернёт <code>sizeof(char)</code>?',options:['<code>1</code>','<code>4</code>','<code>8</code>','Зависит от системы'],correct:0,explanation:'По стандарту C <code>sizeof(char)</code> всегда равен 1 байту, независимо от платформы.'},
 {question:'Какой тип лучше всего подходит для хранения возраста человека?',options:['<code>double</code>','<code>int</code>','<code>char</code>','<code>float</code>'],correct:1,explanation:'<code>int</code> — целые числа, точно подходит для возраста. <code>char</code> теоретически тоже хватит, но менее читаемо.'},
 {question:'Что делает <code>(int)3.7</code>?',options:['Округляет до 4','Округляет до 3','Отбрасывает дробную часть → 3','Ошибка компиляции'],correct:2,explanation:'Приведение к int <b>отбрасывает</b> дробную часть, а не округляет. <code>(int)3.7 == 3</code>, <code>(int)-3.7 == -3</code>.'},
 {question:'Какое значение получит x: <code>int x = 5 / 2 + 1.5;</code>?',options:['<code>3</code>','<code>3.5</code>','<code>4</code>','<code>4.5</code>'],correct:0,explanation:'<code>5/2</code> = 2 (целое деление), <code>2 + 1.5</code> = 3.5, но при присваивании в int дробная часть отбрасывается → <code>3</code>.'},
 {question:'Какое из этих имён переменной <b>недопустимо</b> в C?',options:['<code>_value</code>','<code>userName</code>','<code>2nd_place</code>','<code>x1</code>'],correct:2,explanation:'Имя переменной не может <b>начинаться с цифры</b>. <code>2nd_place</code> — синтаксическая ошибка.'},
 {question:'Что выведет <code>printf("%c", 65);</code>?',options:['<code>65</code>','<code>A</code>','<code>%c</code>','Ошибка'],correct:1,explanation:'Спецификатор <code>%c</code> интерпретирует число как ASCII-код. 65 = <code>A</code>.'},
 {question:'Зачем нужно ключевое слово <code>const</code>?',options:['Ускоряет программу','Запрещает изменять переменную','Создаёт глобальную переменную','Резервирует память'],correct:1,explanation:'<code>const</code> делает переменную <b>неизменяемой</b> после инициализации. Попытка изменить — ошибка компиляции.'},
 {question:'Что покажет <code>printf("%.2f", 3.14159);</code>?',options:['<code>3.14</code>','<code>3.142</code>','<code>3.14159</code>','<code>3.15</code>'],correct:0,explanation:'<code>%.2f</code> — 2 знака после запятой с округлением. <code>3.14159 → 3.14</code>.'},
 {question:'Какой диапазон у <code>unsigned char</code>?',options:['−128 … 127','0 … 255','0 … 65535','−32768 … 32767'],correct:1,explanation:'<code>unsigned char</code> — это 1 байт без знака, диапазон <b>0…255</b>. Со знаком — <code>−128…127</code>.'}
],
practical:[
 {
  title:'Конвертер дюймов в сантиметры',points:20,
  description:'Считайте количество дюймов (целое) и выведите длину в см с <b>2 знаками</b> после запятой. 1 дюйм = 2.54 см.',
  testCases:[
   {input:'10',output:'25.40',hidden:false},
   {input:'1',output:'2.54',hidden:true},
   {input:'100',output:'254.00',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int inches;\n    scanf("%d", &inches);\n    // ваш код\n    return 0;\n}\n'
 },
 {
  title:'Сумма цифр двузначного числа',points:20,
  description:'Считайте двузначное число (10–99) и выведите сумму его цифр.',
  testCases:[
   {input:'42',output:'6',hidden:false},
   {input:'99',output:'18',hidden:true},
   {input:'10',output:'1',hidden:true},
   {input:'55',output:'10',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // подсказка: десятки = n/10, единицы = n%10\n    return 0;\n}\n'
 },
 {
  title:'Объём цилиндра',points:20,
  description:'Считайте радиус и высоту (целые). Выведите объём цилиндра V = π·r²·h с <b>2 знаками</b> после запятой. Возьмите π = 3.14159.',
  testCases:[
   {input:'2 5',output:'62.83',hidden:false},
   {input:'1 1',output:'3.14',hidden:true},
   {input:'3 10',output:'282.74',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int r, h;\n    scanf("%d %d", &r, &h);\n    // ваш код\n    return 0;\n}\n'
 }
]
};
