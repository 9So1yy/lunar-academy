window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[5]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'С какого индекса начинаются массивы в C?',options:['0','1','-1','Зависит'],correct:0,explanation:'Индексация всегда с 0. Первый элемент — <code>a[0]</code>, последний — <code>a[N-1]</code>.'},
 {question:'Что выведет <code>int a[5]; a[5];</code>?',options:['0','Случайное значение или crash (UB)','Ошибка компиляции','Последний элемент'],correct:1,explanation:'Выход за границу — UB. C не проверяет индексы.'},
 {question:'Сколько элементов в <code>int a[10] = {0};</code>?',options:['1','10','11','Зависит'],correct:1,explanation:'Размер фиксирован — 10. <code>{0}</code> инициализирует все нулями.'},
 {question:'Имя массива в выражении — это:',options:['Число','Указатель на первый элемент','Структура','Строка'],correct:1,explanation:'Имя массива «распадается» в указатель на <code>&amp;a[0]</code>.'},
 {question:'Чему равно <code>sizeof(arr)</code> для <code>int arr[20];</code>?',options:['4','8','20','80'],correct:3,explanation:'20 элементов × 4 байта (int) = 80 байт. Только в области, где массив объявлен.'},
 {question:'В функции <code>void f(int arr[]) sizeof(arr)</code> вернёт:',options:['Размер всего массива','sizeof(указателя) — 4 или 8','Количество элементов','0'],correct:1,explanation:'Внутри функции массив — это указатель, sizeof вернёт размер указателя.'},
 {question:'Можно ли скопировать массив через <code>a = b;</code>?',options:['Да','Нет — это ошибка компиляции','Да, копируется первый элемент','Только для int'],correct:1,explanation:'Массивы нельзя присваивать. Нужно копировать поэлементно или <code>memcpy</code>.'},
 {question:'Как объявить массив на 5 double?',options:['<code>double[5] a;</code>','<code>double a[5];</code>','<code>array&lt;double&gt; a(5);</code>','<code>double a(5);</code>'],correct:1,explanation:'Синтаксис: <code>тип имя[размер];</code>.'},
 {question:'В двумерном <code>m[3][4]</code> элементов всего:',options:['3','4','7','12'],correct:3,explanation:'3 строки × 4 столбца = 12 элементов.'},
 {question:'Двумерный массив в памяти располагается:',options:['Случайно','По строкам (row-major)','По столбцам','По диагонали'],correct:1,explanation:'C хранит массивы по строкам — все элементы строки 0, затем строки 1 и т.д.'},
 {question:'Что инициализирует <code>int a[5] = {1, 2};</code>?',options:['{1, 2, мусор, мусор, мусор}','{1, 2, 0, 0, 0}','{1, 2}','Ошибка'],correct:1,explanation:'Заданные значения, остальные — нули.'},
 {question:'Доступ к 3-му элементу массива <code>a</code>:',options:['<code>a[3]</code>','<code>a[2]</code>','<code>a[1]</code>','<code>a(3)</code>'],correct:1,explanation:'Индексация с 0: третий элемент — индекс 2.'},
 {question:'Сравнение двух массивов через <code>a == b</code>:',options:['Сравнит содержимое','Сравнит адреса (всегда разные)','Ошибка','Сравнит размеры'],correct:1,explanation:'<code>==</code> сравнивает адреса. Для содержимого нужно цикл или <code>memcmp</code>.'},
 {question:'Что объявит <code>int a[];</code> в локальной области?',options:['Массив 0 элементов','Ошибка компиляции','Бесконечный массив','Указатель'],correct:1,explanation:'Размер обязателен (кроме случая с инициализацией <code>int a[] = {1,2,3};</code>).'},
 {question:'Узнать количество элементов:',options:['<code>sizeof(a)</code>','<code>length(a)</code>','<code>sizeof(a)/sizeof(a[0])</code>','<code>a.length</code>'],correct:2,explanation:'Делим общий размер на размер одного элемента — стандартный приём.'}
],
practical:[
 {title:'Сумма N чисел',points:20,description:'Считайте N, затем N чисел. Выведите их сумму.',
  testCases:[{input:'5 1 2 3 4 5',output:'15',hidden:false},{input:'3 10 20 30',output:'60',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    int sum = 0, x;\n    // цикл scanf+sum\n    return 0;\n}\n'},
 {title:'Минимум',points:20,description:'Считайте N, затем N чисел. Выведите минимум.',
  testCases:[{input:'5 3 7 1 8 2',output:'1',hidden:false},{input:'3 -5 -10 -3',output:'-10',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n, x, min;\n    scanf("%d", &n);\n    scanf("%d", &min);\n    // считайте остальные и сравнивайте\n    return 0;\n}\n'},
 {title:'Среднее',points:20,description:'Считайте N, затем N чисел. Выведите среднее с <b>1 знаком</b>.',
  testCases:[{input:'3 2 4 6',output:'4.0',hidden:false},{input:'2 1 2',output:'1.5',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    int sum = 0, x;\n    // сумма / n.0\n    return 0;\n}\n'}
]
};
