window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[10]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Где живёт динамическая память?',options:['Стек','Куча','Регистры','Глобальные'],correct:1,explanation:'Куча (heap) — область памяти, управляемая программистом через malloc/free.'},
 {question:'<code>malloc</code> возвращает:',options:['void*','int*','char*','Структуру'],correct:0,explanation:'malloc возвращает <code>void*</code> — приводят к нужному типу.'},
 {question:'Что вернёт malloc если памяти нет?',options:['0','NULL','Ошибка','Случайное'],correct:1,explanation:'NULL — обязательно проверяйте перед использованием.'},
 {question:'<code>malloc</code> инициализирует память?',options:['Нулями','Единицами','Не инициализирует — мусор','NULL-ами'],correct:2,explanation:'Содержимое после malloc — мусор. Для нулей используйте calloc.'},
 {question:'<code>calloc(k, n)</code> отличается тем что:',options:['Быстрее','Выделяет k×n и обнуляет','Только для массивов','Использует стек'],correct:1,explanation:'calloc выделяет k элементов по n байт и обнуляет.'},
 {question:'<code>realloc</code> может:',options:['Только сжать','Только расширить','И то, и другое — может переместить блок','Ничего'],correct:2,explanation:'realloc меняет размер блока. Может вернуть новый адрес — старый недействителен!'},
 {question:'Утечка памяти — это:',options:['Ошибка чтения','malloc без free','Переполнение буфера','Использование NULL'],correct:1,explanation:'Если не освободить — память остаётся занятой. Программа со временем съест всю RAM.'},
 {question:'Double free — это:',options:['Хорошо','Вызов free дважды для одного указателя — UB','Освобождение двух блоков','Половина блока'],correct:1,explanation:'Повторный free — UB, может вызвать крах или повреждение кучи.'},
 {question:'Use-after-free — это:',options:['Нормально','Использование указателя после free — UB','Сохранение','Перезапись'],correct:1,explanation:'После free память может быть переиспользована другим malloc — обращение к указателю UB.'},
 {question:'Лучшая практика после free:',options:['Ничего','Установить указатель в NULL','Вызвать ещё раз','Скопировать'],correct:1,explanation:'<code>p = NULL;</code> после free защищает от случайного use-after-free.'},
 {question:'Размер блока в байтах: <code>malloc(10 * sizeof(int))</code> — это:',options:['10','40','100','Зависит'],correct:1,explanation:'10 × 4 (sizeof(int)) = 40 байт на типичной системе.'},
 {question:'Стек vs куча — что быстрее выделить?',options:['Стек','Куча','Одинаково','Зависит от размера'],correct:0,explanation:'Стек выделяется почти бесплатно (1 операция со SP). Куча — поиск свободного блока.'},
 {question:'Стек ограничен размером:',options:['Бесконечен','~1-8 МБ обычно','Размером оперативки','Зависит от компилятора'],correct:1,explanation:'Стек ограничен — большие данные надо в кучу.'},
 {question:'<code>free(NULL)</code> — это:',options:['Crash','Ничего (безопасно)','Удаляет всё','UB'],correct:1,explanation:'По стандарту free(NULL) — это no-op. Можно вызывать без проверки.'},
 {question:'Заголовок для malloc/free:',options:['stdio.h','stdlib.h','string.h','malloc.h'],correct:1,explanation:'<code>&lt;stdlib.h&gt;</code> — стандартный заголовок для malloc, calloc, realloc, free.'}
],
practical:[
 {title:'Выделить и записать',points:20,description:'Считайте число. Через malloc выделите 1 int, запишите в него число, выведите и освободите.',
  testCases:[{input:'42',output:'42',hidden:false},{input:'-7',output:'-7',hidden:true},{input:'0',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n#include <stdlib.h>\n\nint main(void) {\n    int x;\n    scanf("%d", &x);\n    int* p = malloc(sizeof(int));\n    *p = x;\n    printf("%d", *p);\n    free(p);\n    return 0;\n}\n'},
 {title:'Размер блока',points:20,description:'Считайте N. Выведите количество байт, которое потребует malloc на N int (на типичной системе int = 4 байта).',
  testCases:[{input:'10',output:'40',hidden:false},{input:'1',output:'4',hidden:true},{input:'100',output:'400',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // n * 4\n    return 0;\n}\n'},
 {title:'Сумма N через "кучу"',points:20,description:'Считайте N, затем N чисел. Выведите сумму (как если бы вы выделили массив через malloc).',
  testCases:[{input:'3 1 2 3',output:'6',hidden:false},{input:'5 10 20 30 40 50',output:'150',hidden:true}],
  initialCode:'#include <stdio.h>\n#include <stdlib.h>\n\nint main(void) {\n    int n, x, sum = 0;\n    scanf("%d", &n);\n    // цикл: scanf + sum\n    return 0;\n}\n'}
]
};
