window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[3]={
timeLimit:1800,
passingScore:70,
theory:[
 {question:'Что выполнится при <code>if (0) printf("A"); else printf("B");</code>?',options:['Выведется <code>A</code>','Выведется <code>B</code>','Ошибка','Ничего'],correct:1,explanation:'В C <code>0</code> — это «ложь». Условие ложное, выполняется ветка else: <b>B</b>.'},
 {question:'Что эквивалентно <code>if (x)</code>?',options:['<code>if (x == 0)</code>','<code>if (x != 0)</code>','<code>if (x == 1)</code>','<code>if (x &gt; 0)</code>'],correct:1,explanation:'<code>if (x)</code> истинно, если x не равен нулю. Это эквивалентно <code>if (x != 0)</code>.'},
 {question:'Что выведет код?<br><code>int x = 10; if (x &gt; 0) printf("pos"); else if (x &gt; 5) printf("big");</code>',options:['<code>pos</code>','<code>big</code>','<code>posbig</code>','Ничего'],correct:0,explanation:'Первое условие истинно (10 &gt; 0), выполняется первая ветка. Остальные пропускаются.'},
 {question:'В <code>switch</code> что произойдёт без <code>break</code>?',options:['Ошибка компиляции','Выполнение прервётся','Fall-through — выполнится следующий case','Бесконечный цикл'],correct:2,explanation:'Без break выполнение «провалится» в следующий case. Иногда это нужно специально, но обычно — ошибка.'},
 {question:'Какие типы можно использовать в <code>switch</code>?',options:['Любые','Только целые (int, char, enum)','Только int','int и float'],correct:1,explanation:'<code>switch</code> работает только с целочисленными типами: <code>int</code>, <code>char</code>, <code>enum</code>. Float и string — нельзя.'},
 {question:'Что вернёт тернарный <code>(5 &gt; 3) ? 1 : 0</code>?',options:['<code>0</code>','<code>1</code>','<code>true</code>','Ошибка'],correct:1,explanation:'5 &gt; 3 истинно, тернарный возвращает первый операнд после <code>?</code> — <b>1</b>.'},
 {question:'Какой результат?<br><code>int a = 5; printf("%d", a &gt; 0 &amp;&amp; a &lt; 10);</code>',options:['<code>0</code>','<code>1</code>','<code>5</code>','<code>10</code>'],correct:1,explanation:'5 &gt; 0 истинно И 5 &lt; 10 истинно. <code>&amp;&amp;</code> возвращает <b>1</b>.'},
 {question:'Что произойдёт при <code>if (x = 0) ...</code>?',options:['Сравнение x с 0','Присваивание x = 0, условие всегда ложно','Ошибка компиляции','Условие всегда истинно'],correct:1,explanation:'<code>=</code> присваивает 0, результат выражения 0 (ложь). Это <b>опасная опечатка</b>. Правильно: <code>x == 0</code>.'},
 {question:'Можно ли сравнить <code>double</code> через <code>==</code>?',options:['Да, всегда','Нет, никогда','Можно, но ненадёжно из-за погрешности','Только если оба значения целые'],correct:2,explanation:'Технически можно, но <code>0.1 + 0.2 != 0.3</code> в C из-за IEEE 754. Сравнивайте через <code>fabs(a-b) &lt; 1e-9</code>.'},
 {question:'К какому <code>if</code> относится <code>else</code> здесь?<br><code>if (a) if (b) x; else y;</code>',options:['К внешнему <code>if (a)</code>','К внутреннему <code>if (b)</code>','К обоим','Ошибка — двусмысленность'],correct:1,explanation:'Правило <b>«else прилипает к ближайшему if»</b>. Здесь else относится к <code>if (b)</code>.'},
 {question:'Что нужно после <code>case</code> в <code>switch</code>?',options:['Константное выражение','Переменная','Любое выражение','Строка'],correct:0,explanation:'<code>case</code> требует константного выражения времени компиляции (число, char, enum). Переменные нельзя.'},
 {question:'Что выведет?<br><code>int x = 7; switch (x) { case 7: printf("A"); case 8: printf("B"); }</code>',options:['<code>A</code>','<code>B</code>','<code>AB</code>','Ошибка'],correct:2,explanation:'Сработает case 7, потом fall-through в case 8 (нет break!). Выведет <b>AB</b>.'},
 {question:'Какое условие проверяет, что <code>x</code> в диапазоне [1, 10]?',options:['<code>x &gt; 1 || x &lt; 10</code>','<code>1 &lt; x &lt; 10</code>','<code>x &gt;= 1 &amp;&amp; x &lt;= 10</code>','<code>x = 1..10</code>'],correct:2,explanation:'В C нет «цепочки сравнений» как в Python. Нужно два сравнения через <code>&amp;&amp;</code>: <code>x &gt;= 1 &amp;&amp; x &lt;= 10</code>.'},
 {question:'Что выведет <code>printf("%d", 5 == 5);</code>?',options:['<code>0</code>','<code>1</code>','<code>5</code>','<code>true</code>'],correct:1,explanation:'Результат сравнения в C — это <code>int</code>: 0 (ложь) или <b>1</b> (истина). Отдельного типа bool в классическом C нет.'},
 {question:'Какое выражение НЕ эквивалентно <code>!(a &amp;&amp; b)</code>?',options:['<code>!a || !b</code>','<code>(!a) || (!b)</code>','<code>!a &amp;&amp; !b</code>','По де Моргану: <code>!a || !b</code>'],correct:2,explanation:'Закон де Моргана: <code>!(a &amp;&amp; b)</code> = <code>!a || !b</code>. Вариант с <code>&amp;&amp;</code> неверен.'}
],
practical:[
 {
  title:'Большее из трёх',points:20,
  description:'Считайте три целых числа и выведите наибольшее.',
  testCases:[
   {input:'5 9 3',output:'9',hidden:false},
   {input:'1 1 1',output:'1',hidden:true},
   {input:'-5 -10 -3',output:'-3',hidden:true},
   {input:'100 50 200',output:'200',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b, c;\n    scanf("%d %d %d", &a, &b, &c);\n    // используйте if/else или тернарный\n    return 0;\n}\n'
 },
 {
  title:'Оценка по баллам',points:20,
  description:'Считайте балл (0–100). Выведите оценку: <code>excellent</code> (≥90), <code>good</code> (≥75), <code>ok</code> (≥60), <code>fail</code> (&lt;60).',
  testCases:[
   {input:'95',output:'excellent',hidden:false},
   {input:'80',output:'good',hidden:true},
   {input:'65',output:'ok',hidden:true},
   {input:'45',output:'fail',hidden:true},
   {input:'60',output:'ok',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int s;\n    scanf("%d", &s);\n    // if / else if / else\n    return 0;\n}\n'
 },
 {
  title:'День недели',points:20,
  description:'Считайте число (1–7). Выведите название дня: 1=<code>Mon</code>, 2=<code>Tue</code>, 3=<code>Wed</code>, 4=<code>Thu</code>, 5=<code>Fri</code>, 6=<code>Sat</code>, 7=<code>Sun</code>. Иначе <code>Invalid</code>. Используйте switch.',
  testCases:[
   {input:'1',output:'Mon',hidden:false},
   {input:'5',output:'Fri',hidden:true},
   {input:'7',output:'Sun',hidden:true},
   {input:'0',output:'Invalid',hidden:true},
   {input:'8',output:'Invalid',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int d;\n    scanf("%d", &d);\n    switch (d) {\n        // case 1: printf("Mon"); break;\n        // ...\n    }\n    return 0;\n}\n'
 }
]
};
