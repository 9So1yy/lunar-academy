window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[12]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Заголовок строковых функций:',options:['<code>stdio.h</code>','<code>string.h</code>','<code>ctype.h</code>','<code>stdlib.h</code>'],correct:1,explanation:'<code>&lt;string.h&gt;</code> — strlen, strcpy, strcat, strcmp и др.'},
 {question:'<code>strlen("hello")</code> вернёт:',options:['4','5','6','Зависит'],correct:1,explanation:'5 — длина без учёта \\0.'},
 {question:'Сравнение строк через <code>==</code>:',options:['Работает','Сравнивает адреса (UB на семантическое сравнение)','Запрещено','Зависит'],correct:1,explanation:'<code>==</code> сравнит указатели/адреса, а не содержимое.'},
 {question:'Правильное сравнение строк:',options:['<code>strcmp</code>','<code>==</code>','<code>equals</code>','<code>compare</code>'],correct:0,explanation:'<code>strcmp(a, b) == 0</code> — строки равны.'},
 {question:'<code>strcmp</code> возвращает 0 если:',options:['Первая короче','Строки равны','Первая длиннее','Ошибка'],correct:1,explanation:'0 = равны. Отрицательное/положительное — лексикографический порядок.'},
 {question:'Что опасно в <code>strcpy</code>?',options:['Не проверяет размер приёмника','Медленно','Только для ASCII','Возвращает NULL'],correct:0,explanation:'Переполнение буфера если приёмник меньше источника.'},
 {question:'Безопасная альтернатива strcpy:',options:['strcpy2','strncpy','copy','memcpy'],correct:1,explanation:'<code>strncpy(dst, src, n)</code> — копирует не более n байт.'},
 {question:'<code>strcat</code> делает:',options:['Копирует','Присоединяет к концу','Сравнивает','Длина'],correct:1,explanation:'Дописывает src в конец dst (начиная с \\0 dst).'},
 {question:'<code>atoi("42")</code> вернёт:',options:['"42"','42','0','Ошибка'],correct:1,explanation:'Преобразует строку в int. Если не парсится — 0.'},
 {question:'<code>sprintf(buf, "%d", n)</code>:',options:['Печатает','Записывает число в строку','Ошибка','Читает'],correct:1,explanation:'sprintf пишет результат в строку, а не на экран.'},
 {question:'Переполнение буфера в C:',options:['Безопасно','Главная причина уязвимостей','Только для float','Невозможно'],correct:1,explanation:'Buffer overflow — классический источник уязвимостей в C.'},
 {question:'<code>strchr(s, c)</code> возвращает:',options:['Bool','Указатель на первое c в s или NULL','Индекс','Длину'],correct:1,explanation:'<code>strchr</code> ищет символ и возвращает указатель или NULL.'},
 {question:'<code>strstr(s, sub)</code> ищет:',options:['Символ','Подстроку','Длину','NULL'],correct:1,explanation:'Возвращает указатель на первое вхождение подстроки или NULL.'},
 {question:'<code>strlen</code> сложность:',options:['O(1)','O(n)','O(log n)','O(n²)'],correct:1,explanation:'Считает символы до \\0 — линейно.'},
 {question:'Безопасный printf в буфер:',options:['sprintf','snprintf','printf','fprintf'],correct:1,explanation:'<code>snprintf(buf, size, fmt, ...)</code> — учитывает размер.'}
],
practical:[
 {title:'Длина числа',points:20,description:'Считайте натуральное число (1-10^9). Выведите количество его цифр (как <code>strlen</code> числа в виде строки).',
  testCases:[{input:'42',output:'2',hidden:false},{input:'100',output:'3',hidden:true},{input:'7',output:'1',hidden:true},{input:'999999999',output:'9',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n, count = 0;\n    scanf("%d", &n);\n    // count цифр через while n>0 n/=10\n    return 0;\n}\n'},
 {title:'Сравнение чисел',points:20,description:'Считайте 2 числа. Выведите -1/0/1 как делает strcmp при сравнении.',
  testCases:[{input:'3 5',output:'-1',hidden:false},{input:'5 5',output:'0',hidden:true},{input:'7 2',output:'1',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // тернарный: -1/0/1\n    return 0;\n}\n'},
 {title:'Конкатенация чисел',points:20,description:'Считайте 2 двузначных числа (10-99). Выведите 4-значное число — конкатенацию (например 12 и 34 → 1234).',
  testCases:[{input:'12 34',output:'1234',hidden:false},{input:'10 99',output:'1099',hidden:true},{input:'99 99',output:'9999',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // a*100 + b\n    return 0;\n}\n'}
]
};
