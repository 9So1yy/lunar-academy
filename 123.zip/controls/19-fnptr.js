window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[19]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Указатель на функцию объявляется как:',options:['<code>int *f(int)</code>','<code>int (*f)(int)</code>','<code>int f*(int)</code>','<code>*int f(int)</code>'],correct:1,explanation:'Скобки вокруг <code>*f</code> — иначе это функция, возвращающая указатель.'},
 {question:'Имя функции в C — это:',options:['Строка','Указатель на код','Число','Структура'],correct:1,explanation:'Имя функции в выражениях даёт указатель на её код.'},
 {question:'Вызов через указатель:',options:['<code>p()</code>','<code>(*p)()</code>','И то, и другое','Невозможно'],correct:2,explanation:'<code>p(args)</code> и <code>(*p)(args)</code> — равноценны.'},
 {question:'Callback — это:',options:['Глобальная','Функция, передаваемая как параметр','Возврат','Имя'],correct:1,explanation:'Библиотека вызывает переданную функцию в нужный момент.'},
 {question:'qsort использует callback для:',options:['Скорости','Сравнения элементов','Памяти','Логирования'],correct:1,explanation:'qsort универсальна — компаратор задаётся пользователем.'},
 {question:'Сигнатура компаратора qsort:',options:['<code>int(int,int)</code>','<code>int(const void*, const void*)</code>','<code>void()</code>','<code>bool(int)</code>'],correct:1,explanation:'qsort работает с произвольным типом — void* для универсальности.'},
 {question:'Массив указателей на функции:',options:['Невозможен','Полезен для диспетчерных таблиц','Только для int','Запрещён'],correct:1,explanation:'Можно индексировать по int и получать разную функцию — замена большому switch.'},
 {question:'Указатель на функцию занимает:',options:['1 байт','sizeof(void*)','100 байт','Зависит'],correct:1,explanation:'Размер указателя — 4 или 8 байт на типичной системе.'},
 {question:'<code>void (*p)(int)</code> — что это?',options:['Указатель на функцию int→void','int','Массив','Функция'],correct:0,explanation:'Указатель на функцию, принимающую int и не возвращающую ничего.'},
 {question:'<code>typedef</code> для указателя на функцию:',options:['Невозможно','<code>typedef int (*Cmp)(int,int);</code>','Только в C++','Через struct'],correct:1,explanation:'Очень полезно для упрощения сложных типов.'},
 {question:'Можно ли сравнить указатели на функции через <code>==</code>?',options:['Нет','Да — сравниваются адреса','Только в gcc','Через cmp'],correct:1,explanation:'Два <code>==</code> вернёт истинно, если оба указывают на одну функцию.'},
 {question:'Преимущество диспетчерной таблицы над switch:',options:['Короче','O(1) выбор, легко расширять','Безопаснее','Ничего'],correct:1,explanation:'Switch — O(log n) или O(n). Массив указателей — O(1).'},
 {question:'Полиморфизм в C через:',options:['Невозможен','Struct + указатели на функции','Шаблоны','goto'],correct:1,explanation:'Структура с указателями на «методы» — основа OOP-стиля в C.'},
 {question:'<code>int (*ops[4])(int,int)</code> — это:',options:['Функция','Массив указателей на функции','Указатель на массив','Ошибка'],correct:1,explanation:'Объявление массива из 4 указателей на функции (int,int)→int.'},
 {question:'NULL для указателя на функцию:',options:['Нельзя','Можно — проверьте перед вызовом','Только NULL_FN','Запрещено'],correct:1,explanation:'Указатель на функцию можно установить в NULL. Перед вызовом проверьте.'}
],
practical:[
 {title:'Выбор операции',points:20,description:'Считайте 3 числа: op, a, b. Если op==1: a+b, op==2: a-b, op==3: a*b. (Имитация массива указателей на функции.)',
  testCases:[{input:'1 3 4',output:'7',hidden:false},{input:'2 10 3',output:'7',hidden:true},{input:'3 5 6',output:'30',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int op, a, b;\n    scanf("%d %d %d", &op, &a, &b);\n    // switch\n    return 0;\n}\n'},
 {title:'Имитация qsort-компаратора',points:20,description:'Считайте 2 числа. Выведите a-b (как стандартный компаратор для int).',
  testCases:[{input:'5 3',output:'2',hidden:false},{input:'1 10',output:'-9',hidden:true},{input:'7 7',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // a - b\n    return 0;\n}\n'},
 {title:'Применить квадрат',points:20,description:'Считайте число. Выведите его квадрат. (Аналог <code>apply(x, square)</code>.)',
  testCases:[{input:'5',output:'25',hidden:false},{input:'-3',output:'9',hidden:true},{input:'10',output:'100',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int x;\n    scanf("%d", &x);\n    // x * x\n    return 0;\n}\n'}
]
};
