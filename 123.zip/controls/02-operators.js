window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[2]={
timeLimit:1800,
passingScore:70,
theory:[
 {question:'Что вернёт <code>17 % 5</code>?',options:['<code>2</code>','<code>3</code>','<code>3.4</code>','<code>0</code>'],correct:0,explanation:'Оператор <code>%</code> возвращает остаток от деления. 17 = 3·5 + 2, остаток <b>2</b>.'},
 {question:'Чему равно <code>10 / 4</code> в C, если оба операнда — int?',options:['<code>2.5</code>','<code>2</code>','<code>3</code>','<code>2.50</code>'],correct:1,explanation:'Целочисленное деление обрезает результат. <code>10/4 = 2</code>. Чтобы получить 2.5 — нужно <code>10.0/4</code>.'},
 {question:'Какой оператор сравнивает на равенство?',options:['<code>=</code>','<code>==</code>','<code>===</code>','<code>equals</code>'],correct:1,explanation:'<code>==</code> — сравнение. <code>=</code> — присваивание. Путаница между ними — классическая ошибка.'},
 {question:'Что выведет программа?<br><code>int x = 5; printf("%d", x++);</code>',options:['<code>4</code>','<code>5</code>','<code>6</code>','Ошибка'],correct:1,explanation:'<code>x++</code> — постфикс: сначала <i>используется</i> значение (5), потом увеличивается. После printf x будет 6.'},
 {question:'Что выведет <code>printf("%d", ++x);</code> если до этого <code>x = 5</code>?',options:['<code>4</code>','<code>5</code>','<code>6</code>','Ошибка'],correct:2,explanation:'<code>++x</code> — префикс: сначала увеличивается (6), потом используется. printf выведет 6.'},
 {question:'Какой результат у <code>3 + 4 * 2</code>?',options:['<code>14</code>','<code>11</code>','<code>10</code>','<code>7</code>'],correct:1,explanation:'<code>*</code> имеет более высокий приоритет, чем <code>+</code>. Сначала 4·2 = 8, затем 3+8 = <b>11</b>.'},
 {question:'Что вернёт <code>12 & 10</code>? (битовое И)',options:['<code>14</code>','<code>22</code>','<code>8</code>','<code>2</code>'],correct:2,explanation:'12 = 1100, 10 = 1010. AND по битам: 1000 = <b>8</b>.'},
 {question:'Чем отличаются <code>&amp;</code> и <code>&amp;&amp;</code>?',options:['Одно и то же','&amp; — битовое, &amp;&amp; — логическое','&amp;&amp; быстрее','&amp; работает только с char'],correct:1,explanation:'<code>&amp;</code> — побитовое И, работает с битами числа. <code>&amp;&amp;</code> — логическое И, возвращает 0 или 1.'},
 {question:'Что эквивалентно <code>x *= 3</code>?',options:['<code>x = x * 3</code>','<code>x == x * 3</code>','<code>x * 3</code>','<code>x = 3</code>'],correct:0,explanation:'Составной оператор присваивания: <code>x *= 3</code> ⇔ <code>x = x * 3</code>.'},
 {question:'Тернарный оператор имеет вид:',options:['<code>условие ? а : b</code>','<code>if(условие) ? а : b</code>','<code>а ?: b</code>','<code>условие ? а ; b</code>'],correct:0,explanation:'Тернарный: <code>условие ? значение_если_истина : значение_если_ложь</code>. Единственный оператор C с тремя операндами.'},
 {question:'Чему равно <code>!0</code>?',options:['<code>0</code>','<code>1</code>','<code>-1</code>','Ошибка'],correct:1,explanation:'Логическое НЕ: <code>!0 = 1</code>, <code>!любое_ненулевое = 0</code>.'},
 {question:'Что вернёт <code>1 &lt;&lt; 3</code>?',options:['<code>3</code>','<code>4</code>','<code>8</code>','<code>16</code>'],correct:2,explanation:'Сдвиг влево на 3 = умножение на 2³. <code>1 &lt;&lt; 3 = 8</code>.'},
 {question:'Сколько раз будет вычислено <code>printf("hi")</code> в <code>1 || printf("hi")</code>?',options:['Ноль','Один','Два','Бесконечно'],correct:0,explanation:'Ленивое вычисление <code>||</code>: левый операнд истинен (1), правый не вычисляется. printf не вызовется.'},
 {question:'Какая ошибка в <code>if (x = 5)</code>?',options:['Нет ошибки','Опечатка: должно быть <code>x == 5</code>','Нужна точка с запятой','Ошибка типа'],correct:1,explanation:'<code>=</code> — присваивание. Условие всегда истинно (5), а в <code>x</code> записывается 5. Правильно: <code>x == 5</code>.'},
 {question:'Что выведет <code>printf("%d", 5 == 5 &amp;&amp; 3 &gt; 2);</code>?',options:['<code>0</code>','<code>1</code>','<code>5</code>','<code>true</code>'],correct:1,explanation:'Оба сравнения истинны, <code>&amp;&amp;</code> возвращает <b>1</b>. В C логические результаты — это int (0 или 1).'}
],
practical:[
 {
  title:'Квадрат и куб',points:20,
  description:'Считайте число и выведите его квадрат и куб через пробел.',
  testCases:[
   {input:'3',output:'9 27',hidden:false},
   {input:'5',output:'25 125',hidden:true},
   {input:'1',output:'1 1',hidden:true},
   {input:'10',output:'100 1000',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // ваш код\n    return 0;\n}\n'
 },
 {
  title:'Минимум и максимум',points:20,
  description:'Считайте два числа и выведите минимум и максимум через пробел. Используйте тернарный оператор.',
  testCases:[
   {input:'7 3',output:'3 7',hidden:false},
   {input:'5 5',output:'5 5',hidden:true},
   {input:'-10 10',output:'-10 10',hidden:true},
   {input:'100 50',output:'50 100',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    // подсказка: a < b ? a : b\n    return 0;\n}\n'
 },
 {
  title:'Чётность и знак',points:20,
  description:'Считайте число. Выведите два числа через пробел: 1 если число чётное, иначе 0; и знак: <code>1</code> положительное, <code>-1</code> отрицательное, <code>0</code> ноль.',
  testCases:[
   {input:'6',output:'1 1',hidden:false},
   {input:'-5',output:'0 -1',hidden:true},
   {input:'0',output:'1 0',hidden:true},
   {input:'-8',output:'1 -1',hidden:true}
  ],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    // используйте тернарный оператор\n    return 0;\n}\n'
 }
]
};
