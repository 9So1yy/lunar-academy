window.CONTROLS=window.CONTROLS||{};
window.CONTROLS[4]={
timeLimit:1800,passingScore:70,
theory:[
 {question:'Сколько раз выполнится <code>for(int i=0;i&lt;10;i++)</code>?',options:['9','10','11','бесконечно'],correct:1,explanation:'От 0 до 9 включительно — это 10 итераций.'},
 {question:'Какой цикл проверяет условие <b>после</b> тела?',options:['<code>for</code>','<code>while</code>','<code>do-while</code>','<code>repeat</code>'],correct:2,explanation:'<code>do-while</code> сначала выполняет тело, потом проверяет условие. Минимум 1 итерация.'},
 {question:'Что делает <code>break</code>?',options:['Пропускает итерацию','Выходит из цикла','Перезапускает цикл','Удаляет переменную'],correct:1,explanation:'<code>break</code> досрочно выходит из самого внутреннего цикла или switch.'},
 {question:'Что делает <code>continue</code>?',options:['Выходит из цикла','Переходит к следующей итерации','Завершает программу','Ничего'],correct:1,explanation:'<code>continue</code> переходит к следующей итерации, пропуская оставшееся тело.'},
 {question:'Что выведет <code>for(int i=5;i&gt;0;i--) printf("%d",i);</code>?',options:['12345','54321','01234','43210'],correct:1,explanation:'От 5 до 1 по убыванию.'},
 {question:'Бесконечный цикл — это:',options:['<code>for(;;);</code>','<code>while(0);</code>','<code>do{}while(0);</code>','<code>for(int i;;);</code>'],correct:0,explanation:'<code>for(;;)</code> — нет условия, всегда true. <code>while(0)</code> — никогда не выполнится.'},
 {question:'Что произойдёт: <code>for(int i=0;i&lt;5;i++);</code>?',options:['Ошибка','Тело пустое — ничего полезного','Бесконечный цикл','Цикл выполнится 5 раз'],correct:1,explanation:'Точка с запятой делает тело пустым. Это <b>частая ошибка</b>.'},
 {question:'<code>break</code> внутри вложенных циклов выйдет:',options:['Из всех','Из внешнего','Из внутреннего','Из программы'],correct:2,explanation:'<code>break</code> выходит только из <b>самого внутреннего</b> цикла.'},
 {question:'Какой инвариант off-by-one правильный для массива размера N?',options:['<code>i&lt;=N</code>','<code>i&lt;N</code>','<code>i&gt;N</code>','<code>i!=0</code>'],correct:1,explanation:'Индексы 0..N-1, поэтому <code>i &lt; N</code>. <code>&lt;=</code> приведёт к выходу за границы.'},
 {question:'Что значит <code>i += 2</code>?',options:['<code>i = 2</code>','<code>i = i + 2</code>','<code>i + 2</code>','Сравнить i и 2'],correct:1,explanation:'Составной оператор: <code>i = i + 2</code>. Эквивалентно увеличению на 2.'},
 {question:'<code>while(scanf("%d",&amp;n)==1)</code> завершится, когда:',options:['n=0','scanf вернёт 0 или EOF','Истечёт время','Никогда'],correct:1,explanation:'<code>scanf</code> возвращает количество успешно прочитанных. Если 0 или EOF — цикл завершится.'},
 {question:'<code>for(int i=0;i&lt;3;i++) for(int j=0;j&lt;3;j++)</code> всего итераций:',options:['3','6','9','27'],correct:2,explanation:'Вложенные циклы перемножают итерации: 3×3 = 9.'},
 {question:'Что НЕ обязательно в for?',options:['Точки с запятой','Инициализация','Условие','Скобки'],correct:1,explanation:'Любую из трёх частей <code>for(;;)</code> можно опустить, но точки с запятой — обязательны.'},
 {question:'Сравнение <code>for(double f=0.0;f!=1.0;f+=0.1)</code>:',options:['Выполнится 10 раз','Может быть бесконечным','Ошибка','Выполнится 1 раз'],correct:1,explanation:'Из-за погрешности float, <code>f</code> может никогда не стать ровно 1.0. Сравнивайте через <code>&lt;</code>.'},
 {question:'Какой цикл лучше для «попроси ввод, пока не дадут положительное»?',options:['<code>for</code>','<code>while</code>','<code>do-while</code>','goto'],correct:2,explanation:'<code>do-while</code> — нужно хотя бы раз спросить, потом проверить. Логика «делать, потом проверить».'}
],
practical:[
 {title:'Произведение 1..N',points:20,description:'Считайте N (≤10). Выведите произведение чисел от 1 до N (т.е. N!).',
  testCases:[{input:'5',output:'120',hidden:false},{input:'3',output:'6',hidden:true},{input:'1',output:'1',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    long p = 1;\n    // цикл for\n    return 0;\n}\n'},
 {title:'Считаем чётные',points:20,description:'Считайте N. Выведите количество чётных чисел в диапазоне [1, N].',
  testCases:[{input:'10',output:'5',hidden:false},{input:'7',output:'3',hidden:true},{input:'1',output:'0',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int n;\n    scanf("%d", &n);\n    int cnt = 0;\n    // цикл и проверка %2==0\n    return 0;\n}\n'},
 {title:'Степень N',points:20,description:'Считайте base и exp (целые, exp≥0). Выведите base^exp через цикл.',
  testCases:[{input:'2 5',output:'32',hidden:false},{input:'3 3',output:'27',hidden:true},{input:'5 0',output:'1',hidden:true}],
  initialCode:'#include <stdio.h>\n\nint main(void) {\n    int b, e;\n    scanf("%d %d", &b, &e);\n    long r = 1;\n    // цикл умножения\n    return 0;\n}\n'}
]
};
